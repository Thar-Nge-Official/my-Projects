{{-- resources/views/theses/completed.blade.php --}}

@extends('layouts.app')

@section('title', 'Completed Theses')

@section('content')
<div class="container-fluid">
    <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">
                <i class="fas fa-award text-success me-2"></i>Completed Theses
            </h2>
            <p class="text-muted mb-0">Browse approved theses from all users for reference and study.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="{{ route('theses.index') }}" class="btn btn-outline-secondary btn-lg rounded-pill px-4 shadow-sm">
                <i class="fas fa-arrow-left me-2"></i>My Theses
            </a>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm">
            <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm">
            <i class="fas fa-exclamation-circle me-2"></i> {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body">
            <form method="GET" action="{{ route('theses.completed') }}" class="row g-2 align-items-center">
                <div class="col-12 col-lg">
                    <div class="search-field">
                        <i class="fas fa-search text-primary"></i>
                        <input type="search"
                               name="search"
                               value="{{ $search }}"
                               class="form-control form-control-lg"
                               placeholder="Search by title, student, supervisor, category, roll no, or keyword"
                               aria-label="Search completed theses">
                    </div>
                </div>
                <div class="col-12 col-lg-auto d-flex gap-2">
                    <button type="submit" class="btn btn-primary btn-lg rounded-pill px-4 shadow-sm flex-fill">
                        <i class="fas fa-search me-2"></i>Search
                    </button>
                    @if($search !== '')
                        <a href="{{ route('theses.completed') }}" class="btn btn-outline-secondary btn-lg rounded-pill px-4 flex-fill">
                            <i class="fas fa-times me-2"></i>Clear
                        </a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4 py-3" style="width: 50px;">#</th>
                            <th class="py-3">Thesis Title</th>
                            <th class="py-3">Student</th>
                            <th class="py-3">Category</th>
                            <th class="py-3">Supervisor</th>
                            <th class="py-3 text-center">Status</th>
                            <th class="py-3 text-center">Approved On</th>
                            <th class="py-3 pe-4 text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($theses as $thesis)
                            <tr>
                                <td class="ps-4 fw-semibold text-muted">{{ $loop->iteration }}</td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="thesis-icon me-3">
                                            <i class="fas fa-file-pdf text-danger" style="font-size: 20px;"></i>
                                        </div>
                                        <div>
                                            <div class="fw-semibold">{{ Str::limit($thesis->title, 40) }}</div>
                                            <small class="text-muted">ID: #{{ $thesis->id }}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 30px; height: 30px;">
                                            <span class="text-primary fw-semibold" style="font-size: 12px;">
                                                {{ strtoupper(substr($thesis->student->firstname ?? 'N/A', 0, 1)) }}
                                            </span>
                                        </div>
                                        <div>
                                            <span class="fw-semibold">{{ $thesis->student->firstname ?? 'N/A' }} {{ $thesis->student->lastname ?? '' }}</span>
                                            <br>
                                            <small class="text-muted">Roll: {{ $thesis->student->roll_no ?? 'N/A' }}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark px-3 py-2 rounded-pill">
                                        {{ $thesis->category->name ?? 'N/A' }}
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm bg-success bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 30px; height: 30px;">
                                            <span class="text-success fw-semibold" style="font-size: 12px;">
                                                {{ strtoupper(substr($thesis->supervisor->firstname ?? 'N/A', 0, 1)) }}
                                            </span>
                                        </div>
                                        <div>
                                            <span>{{ $thesis->supervisor->firstname ?? 'N/A' }} {{ $thesis->supervisor->lastname ?? '' }}</span>
                                            @if($thesis->supervisor && $thesis->supervisor->rank)
                                                <br>
                                                <small class="text-muted">{{ $thesis->supervisor->rank }}</small>
                                            @endif
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-{{ $thesis->status_color }} px-3 py-2 rounded-pill">
                                        {{ $thesis->status_label }}
                                    </span>
                                </td>
                                <td class="text-center text-muted">
                                    {{ $thesis->submission_date ? $thesis->submission_date->format('d/m/Y') : $thesis->created_at->format('d/m/Y') }}
                                </td>
                                <td class="pe-4 text-end">
                                    <a href="{{ route('theses.show', $thesis) }}" 
                                       class="btn btn-sm btn-outline-info rounded-circle" 
                                       title="View Thesis" 
                                       style="width: 32px; height: 32px; padding: 0;">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center py-5">
                                    <div class="empty-state">
                                        <i class="fas fa-award text-muted" style="font-size: 64px;"></i>
                                        <h5 class="mt-3 text-muted">
                                            {{ $search !== '' ? 'No matching completed theses found' : 'No completed theses found' }}
                                        </h5>
                                        <p class="text-muted mb-0">
                                            {{ $search !== '' ? 'Try another title, student, supervisor, category, roll no, or keyword.' : 'Approved theses will appear here once they are finalized and ready for reference.' }}
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if($theses->hasPages())
            <div class="card-footer bg-white border-top-0 px-4 py-3">
                <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center">
                    <div class="text-muted small mb-2 mb-sm-0">
                        <i class="fas fa-info-circle me-1"></i>
                        Showing <strong>{{ $theses->firstItem() }}</strong> to <strong>{{ $theses->lastItem() }}</strong>
                        of <strong>{{ $theses->total() }}</strong> approved theses
                    </div>
                    <div>
                        {{ $theses->links('pagination::bootstrap-5') }}
                    </div>
                </div>
            </div>
        @endif
    </div>
</div>

<style>
    .thesis-icon {
        width: 36px;
        height: 36px;
        background: rgba(25, 135, 84, 0.1);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .avatar-sm {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: 600;
        flex-shrink: 0;
    }

    .search-field {
        position: relative;
    }

    .search-field i {
        position: absolute;
        top: 50%;
        left: 18px;
        transform: translateY(-50%);
        z-index: 2;
    }

    .search-field .form-control {
        border-radius: 999px;
        padding-left: 48px;
        border-color: #e2e8f0;
        background: #f8fafc;
    }

    .search-field .form-control:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.12);
        background: #fff;
    }

    .table > :not(caption) > * > * {
        border-bottom-color: #f0f0f0;
    }

    .table tbody tr {
        transition: all 0.2s ease;
    }

    .table tbody tr:hover {
        background-color: rgba(25, 135, 84, 0.05);
        transform: scale(1.01);
        box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
    }

    .btn-outline-info:hover {
        transform: scale(1.1);
    }

    .badge {
        font-weight: 500;
        letter-spacing: 0.3px;
    }

    .empty-state {
        padding: 40px 20px;
    }

    .card {
        border-radius: 16px !important;
        overflow: hidden;
    }

    .card-footer {
        border-radius: 0 0 16px 16px !important;
    }

    @media (max-width: 768px) {
        .table tbody tr {
            transform: none !important;
        }
        .table tbody tr:hover {
            transform: none !important;
            box-shadow: none !important;
        }

        .table thead th {
            font-size: 12px;
            padding: 8px 4px !important;
        }

        .table tbody td {
            font-size: 13px;
            padding: 8px 4px !important;
        }

        .thesis-icon {
            width: 28px;
            height: 28px;
        }

        .avatar-sm {
            width: 24px;
            height: 24px;
            font-size: 10px;
        }
    }
</style>
@endsection
