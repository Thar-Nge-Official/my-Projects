{{-- resources/views/theses/show.blade.php --}}

@extends('layouts.app')

@section('title', $thesis->title)

@section('content')
<div class="container-fluid">
    <!-- ============================================ -->
    <!-- PAGE HEADER -->
    <!-- ============================================ -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex flex-wrap flex-md-nowrap justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <a href="{{ route('theses.index') }}" class="btn btn-light btn-sm rounded-circle shadow-sm" style="width: 42px; height: 42px; padding: 0;">
                        <i class="fas fa-arrow-left text-primary"></i>
                    </a>
                    <div>
                        <h3 class="fw-bold mb-0 text-dark">{{ $thesis->title }}</h3>
                        <div class="d-flex flex-wrap align-items-center gap-2 mt-1">
                            <span class="badge bg-{{ $thesis->status_color }} px-3 py-2 rounded-pill">
                                <i class="fas fa-circle me-1" style="font-size: 8px;"></i>
                                {{ $thesis->status_label }}
                            </span>
                            <span class="text-muted">•</span>
                            <span class="text-muted small">ID: #{{ $thesis->id }}</span>
                            <span class="text-muted">•</span>
                            <span class="text-muted small">
                                <i class="far fa-calendar-alt me-1"></i>
                                {{ $thesis->created_at->format('d M, Y') }}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="mt-2 mt-md-0">
                    @if($thesis->status == 'proposal_approved')
                        <span class="badge bg-success bg-gradient px-4 py-2 rounded-pill shadow-sm">
                            <i class="fas fa-check-circle me-1"></i> Ready for Submission
                        </span>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- MAIN CONTENT -->
    <!-- ============================================ -->
    <div class="row g-4">
        <!-- ============================================ -->
        <!-- LEFT COLUMN - THESIS DETAILS -->
        <!-- ============================================ -->
        <div class="col-lg-8">
            <!-- ============================================ -->
            <!-- PROGRESS TIMELINE -->
            <!-- ============================================ -->
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <div class="bg-primary bg-opacity-10 p-2 rounded-3">
                            <i class="fas fa-chart-simple text-primary"></i>
                        </div>
                        <h6 class="fw-bold mb-0">Progress Timeline</h6>
                    </div>
                    
                    <div class="timeline-wrapper position-relative">
                        <div class="d-flex justify-content-between position-relative">
                            <!-- Step 1: Proposal -->
                            <div class="text-center" style="flex: 1;">
                                <div class="step-icon {{ ($thesis->proposal_submitted_at || $thesis->proposal_approved_at) ? 'completed' : ($thesis->status == 'proposal_draft' ? 'active' : 'pending') }}">
                                    <i class="fas fa-file-alt"></i>
                                </div>
                                <div class="step-label mt-2">
                                    <span class="fw-semibold d-block">Proposal</span>
                                    <small class="text-muted">
                                        @if($thesis->proposal_submitted_at)
                                            {{ $thesis->proposal_submitted_at->format('d/m/Y') }}
                                        @elseif($thesis->proposal_approved_at)
                                            {{ $thesis->proposal_approved_at->format('d/m/Y') }}
                                        @else
                                            Pending
                                        @endif
                                    </small>
                                </div>
                            </div>
                            
                            <!-- Step 2: Approved -->
                            <div class="text-center" style="flex: 1;">
                                <div class="step-icon {{ $thesis->proposal_approved_at ? 'completed' : ($thesis->status == 'proposal_submitted' ? 'active' : 'pending') }}">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <div class="step-label mt-2">
                                    <span class="fw-semibold d-block">Approved</span>
                                    <small class="text-muted">
                                        {{ $thesis->proposal_approved_at ? $thesis->proposal_approved_at->format('d/m/Y') : 'Pending' }}
                                    </small>
                                </div>
                            </div>
                            
                            <!-- Step 3: Submitted -->
                            <div class="text-center" style="flex: 1;">
                                <div class="step-icon {{ $thesis->submission_date ? 'completed' : ($thesis->status == 'proposal_approved' ? 'active' : 'pending') }}">
                                    <i class="fas fa-paper-plane"></i>
                                </div>
                                <div class="step-label mt-2">
                                    <span class="fw-semibold d-block">Submitted</span>
                                    <small class="text-muted">
                                        {{ $thesis->submission_date ? $thesis->submission_date->format('d/m/Y') : 'Pending' }}
                                    </small>
                                </div>
                            </div>
                            
                            <!-- Step 4: Final -->
                            <div class="text-center" style="flex: 1;">
                                <div class="step-icon {{ $thesis->status == 'approved' ? 'completed' : 'pending' }}">
                                    <i class="fas fa-trophy"></i>
                                </div>
                                <div class="step-label mt-2">
                                    <span class="fw-semibold d-block">Final</span>
                                    <small class="text-muted">Completed</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Progress Line -->
                        <div class="progress-line">
                            <div class="progress-fill" style="width: {{ $thesis->status == 'approved' ? '100' : ($thesis->submission_date ? '75' : ($thesis->proposal_approved_at ? '50' : ($thesis->proposal_submitted_at ? '25' : '0'))) }}%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ============================================ -->
            <!-- THESIS DETAILS CARD -->
            <!-- ============================================ -->
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <div class="bg-info bg-opacity-10 p-2 rounded-3">
                            <i class="fas fa-info-circle text-info"></i>
                        </div>
                        <h6 class="fw-bold mb-0">Thesis Information</h6>
                    </div>
                    
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-primary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-user-graduate text-primary"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Student</label>
                                    <p class="fw-semibold mb-0">{{ $thesis->student->firstname ?? 'N/A' }} {{ $thesis->student->lastname ?? '' }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-success bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-chalkboard-user text-success"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Supervisor</label>
                                    <p class="fw-semibold mb-0">
                                        @if($thesis->supervisor)
                                            {{ $thesis->supervisor->firstname ?? 'N/A' }} {{ $thesis->supervisor->lastname ?? '' }}
                                            @if($thesis->supervisor->rank)
                                                <span class="badge bg-secondary bg-opacity-10 text-secondary ms-1">{{ $thesis->supervisor->rank }}</span>
                                            @endif
                                        @else
                                            <span class="text-warning">
                                                <i class="fas fa-clock me-1"></i> Not Assigned Yet
                                            </span>
                                            <br>
                                            <small class="text-muted">Admin will assign a supervisor</small>
                                        @endif
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-warning bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-tags text-warning"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Category</label>
                                    <p class="fw-semibold mb-0">{{ $thesis->category->name ?? 'N/A' }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-danger bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-code text-danger"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Thesis Type</label>
                                    <p class="fw-semibold mb-0">{{ $thesis->thesis_type ?? 'N/A' }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-purple bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-calendar-days text-purple"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Academic Year</label>
                                    <p class="fw-semibold mb-0">{{ $thesis->from_year ?? 'N/A' }} - {{ $thesis->to_year ?? 'N/A' }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-secondary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-clock text-secondary"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Submission Date</label>
                                    <p class="fw-semibold mb-0">{{ $thesis->submission_date ? $thesis->submission_date->format('d/m/Y') : 'Not submitted' }}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    @if($thesis->proposal_rejection_reason)
                        <div class="alert alert-danger border-0 rounded-3 mt-4">
                            <div class="d-flex align-items-center gap-2">
                                <i class="fas fa-circle-exclamation"></i>
                                <div>
                                    <strong>Rejection Reason:</strong>
                                    <span>{{ $thesis->proposal_rejection_reason }}</span>
                                </div>
                            </div>
                        </div>
                    @endif

                    <!-- Keywords -->
                    <div class="mt-4">
                        <label class="text-muted small text-uppercase fw-semibold d-block mb-2">Keywords</label>
                        <div class="d-flex flex-wrap gap-2">
                            @foreach(explode(',', $thesis->keywords) as $keyword)
                                <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill">
                                    #{{ trim($keyword) }}
                                </span>
                            @endforeach
                        </div>
                    </div>

                    <!-- Abstract -->
                    <div class="mt-4">
                        <label class="text-muted small text-uppercase fw-semibold d-block mb-2">Abstract</label>
                        <div class="abstract-box p-4 bg-light rounded-3">
                            <p class="mb-0" style="line-height: 1.8;">{{ $thesis->abstract }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ============================================ -->
            <!-- CERTIFICATE SECTION (For Approved Thesis) -->
            <!-- ============================================ -->
            @if($thesis->status == 'approved' && isset($certificate) && isset($canViewCertificate) && $canViewCertificate)
                <div class="card border-0 shadow-sm rounded-4 mb-4 border border-success">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div class="bg-success bg-opacity-10 p-3 rounded-3">
                                <i class="fas fa-certificate text-success" style="font-size: 28px;"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-0 text-success">🎉 Thesis Approved!</h5>
                                <p class="text-muted small mb-0">Congratulations! Your thesis has been approved.</p>
                            </div>
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <a href="{{ route('certificates.show', $certificate) }}" class="btn btn-primary rounded-pill px-4">
                                <i class="fas fa-certificate me-2"></i> View Certificate
                            </a>
                        </div>
                    </div>
                </div>
            @endif

            <!-- ============================================ -->
            <!-- CHAPTERS SECTION -->
            <!-- ============================================ -->
            @if($thesis->status == 'proposal_approved' || $thesis->status == 'in_progress' || $thesis->status == 'submitted' || $thesis->status == 'under_review' || $thesis->status == 'supervisor_approved' || $thesis->status == 'approved' || $thesis->status == 'revision')
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-primary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-book text-primary"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Chapters</h6>
                                <span class="badge bg-light text-dark rounded-pill">{{ isset($chapters) ? $chapters->count() : 0 }}</span>
                            </div>
                            @if(($thesis->status == 'proposal_approved' || $thesis->status == 'in_progress' || $thesis->status == 'revision') && Auth::user()->isStudent() && $thesis->student_id == Auth::id())
                                <a href="{{ route('chapters.create', $thesis) }}" class="btn btn-primary btn-sm rounded-pill px-4">
                                    <i class="fas fa-plus me-1"></i> Add Chapter
                                </a>
                            @endif
                        </div>
                        
                        @if(isset($chapters) && $chapters->count() > 0)
                            <div class="chapters-list">
                                @foreach($chapters as $chapter)
                                    <div class="chapter-item d-flex justify-content-between align-items-center p-3 bg-light rounded-3 mb-2">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="chapter-number rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; font-weight: 700;">
                                                {{ $chapter->chapter_number }}
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-semibold">
                                                    <a href="{{ route('chapters.show', $chapter) }}" class="text-dark text-decoration-none">
                                                        {{ $chapter->chapter_title }}
                                                    </a>
                                                </h6>
                                                <small class="text-muted">
                                                    <i class="far fa-clock me-1"></i>
                                                    {{ $chapter->created_at->format('d/m/Y') }}
                                                    @if($chapter->word_count)
                                                        • <i class="fas fa-file-word me-1"></i>{{ $chapter->word_count }} words
                                                    @endif
                                                </small>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="badge bg-{{ $chapter->status_color }} rounded-pill px-3 py-2">
                                                {{ $chapter->status_label }}
                                            </span>
                                            <a href="{{ route('chapters.show', $chapter) }}" class="btn btn-outline-primary btn-sm rounded-circle" style="width: 34px; height: 34px; padding: 0;">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            @if(($thesis->status == 'revision' || $chapter->status == 'draft') && Auth::user()->isStudent() && $thesis->student_id == Auth::id())
                                                <a href="{{ route('chapters.edit', $chapter) }}" class="btn btn-outline-warning btn-sm rounded-circle" style="width: 34px; height: 34px; padding: 0;" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            @endif
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="text-center py-5">
                                <div class="bg-light p-4 rounded-3">
                                    <i class="fas fa-book-open text-muted" style="font-size: 48px;"></i>
                                    <p class="text-muted mt-2 mb-0">No chapters added yet.</p>
                                    @if(($thesis->status == 'proposal_approved' || $thesis->status == 'in_progress' || $thesis->status == 'revision') && Auth::user()->isStudent() && $thesis->student_id == Auth::id())
                                        <a href="{{ route('chapters.create', $thesis) }}" class="btn btn-primary btn-sm rounded-pill mt-3">
                                            <i class="fas fa-plus me-1"></i> Add First Chapter
                                        </a>
                                    @endif
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            @endif
        </div>

        <!-- ============================================ -->
        <!-- RIGHT COLUMN - SIDEBAR -->
        <!-- ============================================ -->
        <div class="col-lg-4">
            <!-- ============================================ -->
            <!-- STUDENT ACTIONS -->
            <!-- ============================================ -->
            @if(Auth::user()->isStudent() && $thesis->student_id == Auth::id())
                @if($thesis->status == 'proposal_draft' || $thesis->status == 'proposal_rejected')
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center gap-2 mb-3">
                                <div class="bg-warning bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-pen-to-square text-warning"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Proposal Actions</h6>
                            </div>
                            <div class="d-grid gap-2">
                                <a href="{{ route('theses.edit', $thesis) }}" class="btn btn-outline-primary rounded-pill py-2">
                                    <i class="fas fa-edit me-2"></i>Edit Proposal
                                </a>
                                @if($thesis->hasSupervisorAssigned())
                                    <form action="{{ route('theses.submit-proposal', $thesis) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-success rounded-pill py-2 w-100" onclick="return confirm('Are you sure you want to submit this proposal for approval?')">
                                            <i class="fas fa-paper-plane me-2"></i>Submit for Approval
                                        </button>
                                    </form>
                                @else
                                    <button class="btn btn-secondary rounded-pill py-2 w-100" disabled>
                                        <i class="fas fa-clock me-2"></i>Waiting for Supervisor
                                    </button>
                                    <small class="text-muted text-center">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Admin will assign a supervisor to your thesis
                                    </small>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif

                @if($thesis->status == 'proposal_approved' || $thesis->status == 'in_progress')
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center gap-2 mb-3">
                                <div class="bg-success bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-tasks text-success"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Thesis Actions</h6>
                            </div>
                            <div class="d-grid gap-2">
                                <a href="{{ route('chapters.create', $thesis) }}" class="btn btn-outline-primary rounded-pill py-2">
                                    <i class="fas fa-plus me-2"></i>Add Chapter
                                </a>
                                @if($thesis->chapters()->count() > 0)
                                    <form action="{{ route('theses.submit-thesis', $thesis) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-success rounded-pill py-2 w-100" onclick="return confirm('Are you sure you want to submit the full thesis for review?')">
                                            <i class="fas fa-paper-plane me-2"></i>Submit Thesis
                                        </button>
                                    </form>
                                @else
                                    <button class="btn btn-secondary rounded-pill py-2 w-100" disabled>
                                        <i class="fas fa-info-circle me-2"></i>Add chapters first
                                    </button>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif

                @if($thesis->status == 'revision')
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center gap-2 mb-3">
                                <div class="bg-danger bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-pen-fancy text-danger"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Revision Required</h6>
                            </div>
                            <div class="alert alert-danger border-0 rounded-3 mb-3">
                                <i class="fas fa-info-circle me-1"></i>
                                Please check the feedback below and revise your thesis.
                            </div>
                            <div class="d-grid gap-2">
                                <a href="{{ route('chapters.create', $thesis) }}" class="btn btn-outline-primary rounded-pill py-2">
                                    <i class="fas fa-plus me-2"></i>Add Chapter
                                </a>
                                @if($thesis->chapters()->count() > 0)
                                    <form action="{{ route('theses.submit-thesis', $thesis) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-success rounded-pill py-2 w-100" onclick="return confirm('Are you sure you want to resubmit the thesis for review?')">
                                            <i class="fas fa-paper-plane me-2"></i>Resubmit Thesis
                                        </button>
                                    </form>
                                @else
                                    <button class="btn btn-secondary rounded-pill py-2 w-100" disabled>
                                        <i class="fas fa-info-circle me-2"></i>Add chapters first
                                    </button>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif
            @endif

            <!-- ============================================ -->
            <!-- SUPERVISOR REVIEW - LEVEL 1 -->
            <!-- ============================================ -->
            @if(Auth::user()->isSupervisor() && $thesis->supervisor_id == Auth::id())
                @if($thesis->status == 'submitted' || $thesis->status == 'under_review')
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-header bg-transparent border-0 p-4 pb-0">
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-warning bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-user-check text-warning"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Supervisor Review (Level 1)</h6>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <!-- Supervisor Approve -->
                            <form action="{{ route('theses.supervisor-review', $thesis) }}" method="POST" class="mb-3">
                                @csrf
                                <input type="hidden" name="action" value="approve">
                                <div class="mb-2">
                                    <textarea name="feedback" class="form-control form-control-sm rounded-3" placeholder="Approval feedback..." rows="2" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-success rounded-pill py-2 w-100" onclick="return confirm('Approve this thesis? It will be sent to admin for final review.')">
                                    <i class="fas fa-check me-2"></i>Approve & Send to Admin
                                </button>
                                <small class="text-muted d-block mt-1 text-center">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Thesis will be sent to admin for final approval
                                </small>
                            </form>
                            
                            <!-- Supervisor Reject -->
                            <form action="{{ route('theses.supervisor-review', $thesis) }}" method="POST">
                                @csrf
                                <input type="hidden" name="action" value="revision">
                                <div class="mb-2">
                                    <textarea name="feedback" class="form-control form-control-sm rounded-3" placeholder="Revision feedback..." rows="2" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-warning rounded-pill py-2 w-100" onclick="return confirm('Request revision? Chapters will be reset to draft.')">
                                    <i class="fas fa-pen me-2"></i>Request Revision
                                </button>
                                <small class="text-muted d-block mt-1 text-center">
                                    <i class="fas fa-info-circle me-1"></i>
                                    All chapters will be reset to draft for student to edit
                                </small>
                            </form>
                        </div>
                    </div>
                @endif
            @endif

            <!-- ============================================ -->
            <!-- ADMIN REVIEW - LEVEL 2 (FINAL) -->
            <!-- ============================================ -->
            @if(Auth::user()->isAdmin())
                @if($thesis->status == 'supervisor_approved')
                    @php
                        $chapterCount = $chapters->count();
                        $notAdminApprovedChapters = $chapters
                            ->whereNotIn('status', ['admin_approved', 'approved'])
                            ->count();
                        $canFinalApproveThesis = $chapterCount > 0 && $notAdminApprovedChapters === 0;
                    @endphp
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-header bg-transparent border-0 p-4 pb-0">
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-primary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-user-shield text-primary"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Admin Review (Level 2 - Final)</h6>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <!-- Admin Approve -->
                            @if($canFinalApproveThesis)
                                <form action="{{ route('theses.admin-review', $thesis) }}" method="POST" class="mb-3">
                                    @csrf
                                    <input type="hidden" name="action" value="approve">
                                    <div class="mb-2">
                                        <textarea name="feedback" class="form-control form-control-sm rounded-3" placeholder="Final approval feedback..." rows="2" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-success rounded-pill py-2 w-100" onclick="return confirm('Final approve this thesis?')">
                                        <i class="fas fa-check me-2"></i>Final Approve
                                    </button>
                                    <small class="text-muted d-block mt-1 text-center">
                                        <i class="fas fa-info-circle me-1"></i>
                                        All chapters are admin-approved. This is the final approval step.
                                    </small>
                                </form>
                            @else
                                <div class="alert alert-warning border-0 rounded-3 mb-3">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    Final approval is locked until every chapter is approved by admin.
                                    @if($chapterCount === 0)
                                        No chapters have been added yet.
                                    @else
                                        {{ $notAdminApprovedChapters }} chapter(s) still need admin approval.
                                    @endif
                                </div>
                                <button type="button" class="btn btn-secondary rounded-pill py-2 w-100 mb-3" disabled>
                                    <i class="fas fa-lock me-2"></i>Approve Chapters First
                                </button>
                            @endif
                            
                            <!-- Admin Reject -->
                            <form action="{{ route('theses.admin-review', $thesis) }}" method="POST">
                                @csrf
                                <input type="hidden" name="action" value="revision">
                                <div class="mb-2">
                                    <textarea name="feedback" class="form-control form-control-sm rounded-3" placeholder="Revision feedback..." rows="2" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-danger rounded-pill py-2 w-100" onclick="return confirm('Reject this thesis? Student will need to revise.')">
                                    <i class="fas fa-times me-2"></i>Reject & Request Revision
                                </button>
                                <small class="text-muted d-block mt-1 text-center">
                                    <i class="fas fa-info-circle me-1"></i>
                                    All chapters will be reset to draft for student to edit
                                </small>
                            </form>
                        </div>
                    </div>
                @endif

                <!-- ============================================ -->
                <!-- ADMIN: PROPOSAL REVIEW -->
                <!-- ============================================ -->
                @if($thesis->status == 'proposal_submitted')
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center gap-2 mb-3">
                                <div class="bg-warning bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-check-circle text-warning"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Review Proposal</h6>
                            </div>
                            <div class="d-grid gap-2">
                                <form action="{{ route('theses.approve-proposal', $thesis) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn-success rounded-pill py-2 w-100" onclick="return confirm('Approve this proposal?')">
                                        <i class="fas fa-check me-2"></i>Approve Proposal
                                    </button>
                                </form>
                                <form action="{{ route('theses.reject-proposal', $thesis) }}" method="POST">
                                    @csrf
                                    <div class="mb-2">
                                        <textarea name="rejection_reason" class="form-control form-control-sm rounded-3" placeholder="Rejection reason..." rows="2" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-danger rounded-pill py-2 w-100" onclick="return confirm('Reject this proposal?')">
                                        <i class="fas fa-times me-2"></i>Reject Proposal
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                @endif

                <!-- ============================================ -->
                <!-- ADMIN: ASSIGN SUPERVISOR -->
                <!-- ============================================ -->
                @if(!$thesis->hasSupervisorAssigned())
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center gap-2 mb-3">
                                <div class="bg-primary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-user-tie text-primary"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Assign Supervisor</h6>
                            </div>
                            <form action="{{ route('admin.assign-supervisor', $thesis->id) }}" method="POST">
                                @csrf
                                <div class="mb-3">
                                    <label class="form-label">Select Supervisor</label>
                                    <select name="supervisor_id" class="form-select" required>
                                        <option value="">Choose a supervisor...</option>
                                        @if(isset($supervisors) && $supervisors->count() > 0)
                                            @foreach($supervisors as $supervisor)
                                                <option value="{{ $supervisor->id }}">
                                                    {{ $supervisor->firstname }} {{ $supervisor->lastname }}
                                                    @if($supervisor->rank) ({{ $supervisor->rank }}) @endif
                                                </option>
                                            @endforeach
                                        @else
                                            <option value="" disabled>No supervisors available</option>
                                        @endif
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary w-100" {{ isset($supervisors) && $supervisors->count() > 0 ? '' : 'disabled' }}>
                                    <i class="fas fa-user-check me-2"></i> Assign Supervisor
                                </button>
                            </form>
                        </div>
                    </div>
                @else
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center gap-2 mb-3">
                                <div class="bg-success bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-check-circle text-success"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Supervisor Assigned</h6>
                            </div>
                            <div class="alert alert-success border-0 rounded-3 mb-0">
                                <i class="fas fa-user-check me-2"></i>
                                <strong>{{ $thesis->supervisor->firstname ?? 'N/A' }} {{ $thesis->supervisor->lastname ?? '' }}</strong>
                                @if($thesis->supervisor && $thesis->supervisor->rank)
                                    <span class="badge bg-success text-white ms-1">{{ $thesis->supervisor->rank }}</span>
                                @endif
                                <br>
                                <small class="text-muted">
                                    Assigned on: {{ $thesis->supervisor_assigned_at ? $thesis->supervisor_assigned_at->format('d/m/Y H:i') : 'N/A' }}
                                </small>
                            </div>
                        </div>
                    </div>
                @endif

                <!-- ============================================ -->
                <!-- DANGER ZONE - ADMIN -->
                <!-- ============================================ -->
                <div class="card border-0 shadow-sm rounded-4 mb-4 border border-danger">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-2 mb-3">
                            <div class="bg-danger bg-opacity-10 p-2 rounded-3">
                                <i class="fas fa-triangle-exclamation text-danger"></i>
                            </div>
                            <h6 class="fw-bold mb-0 text-danger">Danger Zone</h6>
                        </div>
                        <p class="text-muted small mb-3">Delete this thesis permanently. This action cannot be undone.</p>
                        <form action="{{ route('theses.destroy', $thesis) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-outline-danger rounded-pill py-2 w-100" onclick="return confirm('Are you sure you want to delete this thesis? This action cannot be undone.')">
                                <i class="fas fa-trash me-2"></i>Delete Thesis
                            </button>
                        </form>
                    </div>
                </div>
            @endif

            <!-- ============================================ -->
            <!-- FEEDBACK BUTTON -->
            <!-- ============================================ -->
            @if(isset($feedbacks) && $feedbacks->count() > 0)
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4 d-flex flex-column gap-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-warning bg-opacity-10 p-2 rounded-3">
                                <i class="fas fa-comment text-warning"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-1">Thesis Feedback</h6>
                                <p class="mb-0 text-muted">Click the button below to view all feedback in a popup modal.</p>
                            </div>
                        </div>
                        <button id="view-feedbacks-btn" type="button" class="btn btn-outline-primary rounded-pill py-2">
                            <i class="fas fa-eye me-2"></i>View Feedbacks ({{ $feedbacks->count() }})
                        </button>
                    </div>
                </div>
            @endif

            <!-- ============================================ -->
            <!-- THESIS INFO CARD -->
            <!-- ============================================ -->
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <div class="bg-info bg-opacity-10 p-2 rounded-3">
                            <i class="fas fa-circle-info text-info"></i>
                        </div>
                        <h6 class="fw-bold mb-0">Thesis Information</h6>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Status</span>
                        <span class="badge bg-{{ $thesis->status_color }} rounded-pill px-3 py-2">
                            {{ $thesis->status_label }}
                        </span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Created</span>
                        <span class="fw-semibold">{{ $thesis->created_at->format('d M, Y H:i') }}</span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Last Updated</span>
                        <span class="fw-semibold">{{ $thesis->updated_at->format('d M, Y H:i') }}</span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2">
                        <span class="text-muted">Thesis ID</span>
                        <span class="fw-semibold">#{{ $thesis->id }}</span>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- FEEDBACK MODAL -->
<!-- ============================================ -->
@if(isset($feedbacks) && $feedbacks->count() > 0)
    <div id="feedback-modal" class="feedback-modal">
        <div class="feedback-modal-dialog">
            <div class="feedback-modal-header d-flex align-items-center justify-content-between">
                <div>
                    <h5 class="mb-1">Feedback for Thesis "{{ $thesis->title }}"</h5>
                    <small class="text-muted">Total feedback entries: {{ $feedbacks->count() }}</small>
                </div>
                <button type="button" id="close-feedback-modal" class="btn btn-sm btn-outline-secondary" aria-label="Close feedback modal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="feedback-modal-body">
                @foreach($feedbacks as $feedback)
                    <div class="feedback-item p-3 bg-light rounded-3 mb-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="d-flex align-items-center gap-2">
                                <div class="avatar rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 36px; height: 36px; font-size: 14px; font-weight: 600;">
                                    {{ strtoupper(substr($feedback->user->firstname ?? 'N/A', 0, 1)) }}
                                </div>
                                <div>
                                    <strong class="d-block">{{ $feedback->user->firstname ?? 'N/A' }}</strong>
                                    <small class="text-muted">{{ $feedback->created_at->format('d M, Y H:i') }}</small>
                                </div>
                            </div>
                            @if($feedback->rating)
                                <div class="text-warning">
                                    @for($i = 1; $i <= 5; $i++)
                                        <i class="fas fa-star{{ $i <= $feedback->rating ? '' : '-o' }}" style="font-size: 12px;"></i>
                                    @endfor
                                </div>
                            @endif
                        </div>
                        <p class="mt-2 mb-0">{{ $feedback->feedback }}</p>
                        <span class="badge bg-secondary bg-opacity-10 text-secondary mt-1">{{ ucfirst($feedback->type) }}</span>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endif

<!-- ============================================ -->
<!-- CUSTOM STYLES -->
<!-- ============================================ -->
<style>
    .timeline-wrapper {
        padding: 10px 20px;
    }
    
    .step-icon {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        font-size: 20px;
        color: white;
        transition: all 0.4s ease;
        position: relative;
        z-index: 2;
        border: 3px solid transparent;
    }
    
    .step-icon.completed {
        background: #198754;
        border-color: #198754;
        box-shadow: 0 0 0 8px rgba(25, 135, 84, 0.15);
    }
    
    .step-icon.active {
        background: #0d6efd;
        border-color: #0d6efd;
        box-shadow: 0 0 0 8px rgba(13, 110, 253, 0.15);
        animation: pulse-border 2s infinite;
    }
    
    .step-icon.pending {
        background: #e9ecef;
        border-color: #dee2e6;
        color: #adb5bd;
    }
    
    .step-label {
        font-size: 13px;
    }
    
    .step-label .fw-semibold {
        color: #1a1a2e;
    }
    
    .progress-line {
        position: absolute;
        top: 35px;
        left: 12.5%;
        right: 12.5%;
        height: 3px;
        background: #e9ecef;
        z-index: 1;
        border-radius: 3px;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #0d6efd, #198754);
        border-radius: 3px;
        transition: width 1.5s ease;
    }
    
    @keyframes pulse-border {
        0% { box-shadow: 0 0 0 8px rgba(13, 110, 253, 0.15); }
        70% { box-shadow: 0 0 0 15px rgba(13, 110, 253, 0); }
        100% { box-shadow: 0 0 0 8px rgba(13, 110, 253, 0.15); }
    }
    
    .abstract-box {
        border-left: 4px solid #0d6efd;
        font-size: 14px;
    }
    
    .chapter-item {
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    
    .chapter-item:hover {
        border-color: #0d6efd;
        background: rgba(13, 110, 253, 0.05) !important;
    }
    
    .chapter-number {
        font-weight: 700;
        background: #0d6efd !important;
        color: white !important;
    }
    
    .info-item {
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    
    .info-item:hover {
        border-color: #0d6efd;
        background: rgba(13, 110, 253, 0.05) !important;
    }
    
    .icon-wrapper {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    
    .bg-purple {
        background: #6f42c1 !important;
    }
    .text-purple {
        color: #6f42c1 !important;
    }
    
    .avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        font-weight: 600;
        flex-shrink: 0;
        background: #0d6efd !important;
        color: white !important;
    }
    
    .feedback-item:last-child {
        margin-bottom: 0 !important;
    }

    .feedback-modal {
        display: none;
        position: fixed;
        inset: 0;
        z-index: 1050;
        background: rgba(33, 37, 41, 0.65);
        align-items: center;
        justify-content: center;
        padding: 24px;
        overflow-y: auto;
    }

    .feedback-modal.show {
        display: flex;
    }

    .feedback-modal-dialog {
        width: 100%;
        max-width: 760px;
        background: #ffffff;
        border-radius: 18px;
        overflow: hidden;
        box-shadow: 0 30px 80px rgba(0, 0, 0, 0.18);
        animation: fadeInUp 0.25s ease-out;
    }

    .feedback-modal-header {
        padding: 22px 24px;
        border-bottom: 1px solid #e9ecef;
    }

    .feedback-modal-body {
        padding: 22px 24px 26px;
        max-height: calc(100vh - 190px);
        overflow-y: auto;
    }

    .feedback-modal-body .feedback-item {
        border: 1px solid #e9ecef;
    }

    .feedback-modal .btn-outline-secondary {
        min-width: 42px;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(12px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .info-row {
        padding: 10px 0;
    }
    
    .info-row:last-child {
        border-bottom: none !important;
    }
    
    @media (max-width: 768px) {
        .step-icon {
            width: 38px;
            height: 38px;
            font-size: 15px;
        }
        .step-label {
            font-size: 11px;
        }
        .progress-line {
            top: 28px;
        }
        .timeline-wrapper {
            padding: 10px 0;
        }
        .info-item {
            padding: 12px !important;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var feedbackModal = document.getElementById('feedback-modal');
        var openButton = document.getElementById('view-feedbacks-btn');
        var closeButton = document.getElementById('close-feedback-modal');

        if (openButton && feedbackModal) {
            openButton.addEventListener('click', function () {
                feedbackModal.classList.add('show');
                document.body.style.overflow = 'hidden';
            });
        }

        if (closeButton && feedbackModal) {
            closeButton.addEventListener('click', function () {
                feedbackModal.classList.remove('show');
                document.body.style.overflow = '';
            });
        }

        if (feedbackModal) {
            feedbackModal.addEventListener('click', function (event) {
                if (event.target === feedbackModal) {
                    feedbackModal.classList.remove('show');
                    document.body.style.overflow = '';
                }
            });
        }

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && feedbackModal && feedbackModal.classList.contains('show')) {
                feedbackModal.classList.remove('show');
                document.body.style.overflow = '';
            }
        });
    });
</script>
@endsection
