{{-- resources/views/theses/index.blade.php --}}

@extends('layouts.app')

@section('title', 'My Theses')

@section('content')
<div class="container-fluid">
    <!-- ============================================ -->
    <!-- HEADER SECTION -->
    <!-- ============================================ -->
    <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">
                <i class="fas fa-file-alt text-primary me-2"></i>My Theses
            </h2>
            <p class="text-muted mb-0">Manage and track your thesis projects</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="{{ route('theses.completed') }}" class="btn btn-outline-success btn-lg rounded-pill px-4 shadow-sm">
                <i class="fas fa-award me-2"></i>Completed Theses
            </a>
            @if(Auth::user()->isStudent())
                <a href="{{ route('theses.create') }}" class="btn btn-primary btn-lg rounded-pill px-4 shadow-sm">
                    <i class="fas fa-plus-circle me-2"></i>Create New Thesis
                </a>
            @endif
        </div>
    </div>

    <!-- ============================================ -->
    <!-- STATISTICS CARDS -->
    <!-- ============================================ -->
    @if(Auth::user()->isStudent())
        @php
            $total = $theses->total();
            $draft = $theses->where('status', 'proposal_draft')->count();
            $pending = $theses->where('status', 'proposal_submitted')->count();
            $approved = $theses->where('status', 'proposal_approved')->count();
        @endphp
        <div class="row g-3 mb-4">
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center py-3">
                        <div class="d-flex align-items-center justify-content-center gap-2">
                            <i class="fas fa-file-alt text-primary" style="font-size: 24px;"></i>
                            <div>
                                <h5 class="mb-0 fw-bold">{{ $total }}</h5>
                                <small class="text-muted">Total</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center py-3">
                        <div class="d-flex align-items-center justify-content-center gap-2">
                            <i class="fas fa-pencil-alt text-secondary" style="font-size: 24px;"></i>
                            <div>
                                <h5 class="mb-0 fw-bold">{{ $draft }}</h5>
                                <small class="text-muted">Draft</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center py-3">
                        <div class="d-flex align-items-center justify-content-center gap-2">
                            <i class="fas fa-clock text-warning" style="font-size: 24px;"></i>
                            <div>
                                <h5 class="mb-0 fw-bold">{{ $pending }}</h5>
                                <small class="text-muted">Pending</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center py-3">
                        <div class="d-flex align-items-center justify-content-center gap-2">
                            <i class="fas fa-check-circle text-success" style="font-size: 24px;"></i>
                            <div>
                                <h5 class="mb-0 fw-bold">{{ $approved }}</h5>
                                <small class="text-muted">Approved</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <!-- ============================================ -->
    <!-- ALERT MESSAGES -->
    <!-- ============================================ -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm">
            <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm">
            <i class="fas fa-exclamation-circle me-2"></i> {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <!-- ============================================ -->
    <!-- THESIS TABLE -->
    <!-- ============================================ -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4 py-3" style="width: 50px;">#</th>
                            <th class="py-3">Thesis Title</th>
                            
                            <!-- ============================================ -->
                            <!-- STUDENT NAME COLUMN - ADDED -->
                            <!-- ============================================ -->
                            <th class="py-3">Student</th>
                            
                            <th class="py-3">Category</th>
                            <th class="py-3">Supervisor</th>
                            <th class="py-3 text-center">Status</th>
                            <th class="py-3 text-center">Date</th>
                            <th class="py-3 pe-4 text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($theses as $thesis)
                            <tr>
                                <td class="ps-4 fw-semibold text-muted">{{ $loop->iteration }}</td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="thesis-icon me-3">
                                            <i class="fas fa-file-pdf text-danger" style="font-size: 20px;"></i>
                                        </div>
                                        <div>
                                            <div class="fw-semibold">{{ Str::limit($thesis->title, 35) }}</div>
                                            <small class="text-muted">ID: #{{ $thesis->id }}</small>
                                        </div>
                                    </div>
                                </td>
                                
                                <!-- ============================================ -->
                                <!-- STUDENT NAME - DISPLAY -->
                                <!-- ============================================ -->
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 30px; height: 30px;">
                                            <span class="text-primary fw-semibold" style="font-size: 12px;">
                                                {{ strtoupper(substr($thesis->student->firstname ?? 'N/A', 0, 1)) }}
                                            </span>
                                        </div>
                                        <div>
                                            <span class="fw-semibold">{{ $thesis->student->firstname ?? 'N/A' }} {{ $thesis->student->lastname ?? '' }}</span>
                                            <br>
                                            <small class="text-muted">Roll: {{ $thesis->student->roll_no ?? 'N/A' }}</small>
                                        </div>
                                    </div>
                                </td>
                                
                                <td>
                                    <span class="badge bg-light text-dark px-3 py-2 rounded-pill">
                                        {{ $thesis->category->name ?? 'N/A' }}
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm bg-success bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 30px; height: 30px;">
                                            <span class="text-success fw-semibold" style="font-size: 12px;">
                                                {{ strtoupper(substr($thesis->supervisor->firstname ?? 'N/A', 0, 1)) }}
                                            </span>
                                        </div>
                                        <div>
                                            <span>{{ $thesis->supervisor->firstname ?? 'N/A' }} {{ $thesis->supervisor->lastname ?? '' }}</span>
                                            @if($thesis->supervisor && $thesis->supervisor->rank)
                                                <br>
                                                <small class="text-muted">{{ $thesis->supervisor->rank }}</small>
                                            @endif
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-{{ $thesis->status_color }} px-3 py-2 rounded-pill">
                                        {{ $thesis->status_label }}
                                    </span>
                                </td>
                                <td class="text-center text-muted">
                                    <div>{{ $thesis->created_at->format('d/m/Y') }}</div>
                                    <small>{{ $thesis->created_at->format('H:i') }}</small>
                                </td>
                                <td class="pe-4 text-end">
                                    <div class="d-flex justify-content-end gap-1">
                                        <a href="{{ route('theses.show', $thesis) }}" 
                                           class="btn btn-sm btn-outline-info rounded-circle" 
                                           title="View Details" 
                                           style="width: 32px; height: 32px; padding: 0;">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        @if($thesis->status == 'proposal_draft' || $thesis->status == 'proposal_rejected')
                                            @if(Auth::user()->isStudent() && $thesis->student_id == Auth::id())
                                                <a href="{{ route('theses.edit', $thesis) }}" 
                                                   class="btn btn-sm btn-outline-primary rounded-circle" 
                                                   title="Edit Thesis" 
                                                   style="width: 32px; height: 32px; padding: 0;">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            @endif
                                        @endif
                                        
                                        @if(Auth::user()->isAdmin())
                                            <form action="{{ route('theses.destroy', $thesis) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" 
                                                        class="btn btn-sm btn-outline-danger rounded-circle" 
                                                        title="Delete Thesis" 
                                                        style="width: 32px; height: 32px; padding: 0;"
                                                        onclick="return confirm('Are you sure you want to delete this thesis?')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center py-5">
                                    <div class="empty-state">
                                        <i class="fas fa-file-alt text-muted" style="font-size: 64px;"></i>
                                        <h5 class="mt-3 text-muted">No theses found</h5>
                                        @if(Auth::user()->isStudent())
                                            <p class="text-muted mb-0">Click "Create New Thesis" to get started.</p>
                                            <a href="{{ route('theses.create') }}" class="btn btn-primary mt-3">
                                                <i class="fas fa-plus-circle me-2"></i>Create Your First Thesis
                                            </a>
                                        @else
                                            <p class="text-muted mb-0">No theses available.</p>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- ============================================ -->
        <!-- PAGINATION -->
        <!-- ============================================ -->
        @if($theses->hasPages())
            <div class="card-footer bg-white border-top-0 px-4 py-3">
                <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center">
                    <div class="text-muted small mb-2 mb-sm-0">
                        <i class="fas fa-info-circle me-1"></i>
                        Showing <strong>{{ $theses->firstItem() }}</strong> to <strong>{{ $theses->lastItem() }}</strong> 
                        of <strong>{{ $theses->total() }}</strong> results
                    </div>
                    <div>
                        {{ $theses->links('pagination::bootstrap-5') }}
                    </div>
                </div>
            </div>
        @endif
    </div>
</div>

<!-- ============================================ -->
<!-- CUSTOM STYLES -->
<!-- ============================================ -->
<style>
    .thesis-icon {
        width: 36px;
        height: 36px;
        background: rgba(220, 53, 69, 0.1);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .avatar-sm {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: 600;
        flex-shrink: 0;
        background: rgba(13, 110, 253, 0.1);
        color: #0d6efd;
    }
    
    .table > :not(caption) > * > * {
        border-bottom-color: #f0f0f0;
    }
    
    .table tbody tr {
        transition: all 0.2s ease;
    }
    
    .table tbody tr:hover {
        background-color: rgba(13, 110, 253, 0.03);
        transform: scale(1.01);
        box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
    }
    
    .btn-outline-info:hover,
    .btn-outline-primary:hover,
    .btn-outline-danger:hover {
        transform: scale(1.1);
    }
    
    .badge {
        font-weight: 500;
        letter-spacing: 0.3px;
    }
    
    .empty-state {
        padding: 40px 20px;
    }
    
    .card {
        border-radius: 16px !important;
        overflow: hidden;
    }
    
    .card-footer {
        border-radius: 0 0 16px 16px !important;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .table tbody tr {
            transform: none !important;
        }
        .table tbody tr:hover {
            transform: none !important;
            box-shadow: none !important;
        }
        
        .table thead th {
            font-size: 12px;
            padding: 8px 4px !important;
        }
        
        .table tbody td {
            font-size: 13px;
            padding: 8px 4px !important;
        }
        
        .thesis-icon {
            width: 28px;
            height: 28px;
            font-size: 14px;
        }
        
        .thesis-icon i {
            font-size: 14px;
        }
        
        .avatar-sm {
            width: 24px;
            height: 24px;
            font-size: 10px;
        }
    }
</style>
@endsection