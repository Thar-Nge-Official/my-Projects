{{-- resources/views/theses/create.blade.php --}}

@extends('layouts.app')

@section('title', 'Create New Proposal')

@section('content')
<div class="container-fluid">
    <!-- PAGE HEADER -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex align-items-center gap-3">
                <a href="{{ route('student.proposals.index') }}" class="btn btn-light btn-sm rounded-circle shadow-sm" style="width: 42px; height: 42px; padding: 0;">
                    <i class="fas fa-arrow-left text-primary"></i>
                </a>
                <div>
                    <h3 class="fw-bold mb-0 text-dark">Create New Proposal</h3>
                    <p class="text-muted small mb-0">
                        <i class="fas fa-info-circle me-1"></i>
                                            Create up to three proposals here. Admin will approve one and it will become an official thesis.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-body p-4">
                    <!-- Form Header -->
                    <div class="d-flex align-items-center gap-3 mb-4 pb-3 border-bottom">
                        <div class="bg-primary bg-opacity-10 p-3 rounded-3">
                            <i class="fas fa-file-pen text-primary" style="font-size: 24px;"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0">Proposal Information</h5>
                            <p class="text-muted small mb-0">Please fill in all required fields marked with <span class="text-danger">*</span></p>
                        </div>
                    </div>

                    @if($errors->any())
                        <div class="alert alert-danger border-0 rounded-3 mb-4">
                            <div class="d-flex align-items-start gap-2">
                                <i class="fas fa-circle-exclamation mt-1"></i>
                                <div>
                                    <strong>Please fix the following errors:</strong>
                                    <ul class="mb-0 mt-1 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endif

                    <form action="{{ route('student.proposals.store') }}" method="POST">
                        <input type="hidden" name="from_theses_page" value="1">
                        @csrf

                        <!-- STEP 1: BASIC INFORMATION -->
                        <div class="step-wrapper mb-4">
                            <div class="step-header d-flex align-items-center gap-3 mb-3">
                                <div class="step-number d-flex align-items-center justify-content-center rounded-circle bg-primary text-white" style="width: 32px; height: 32px; font-weight: 700; font-size: 14px;">
                                    1
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-0">Basic Information</h6>
                                    <small class="text-muted">Thesis title and type</small>
                                </div>
                                <span class="badge bg-danger bg-opacity-10 text-danger ms-auto rounded-pill px-3 py-1">Required</span>
                            </div>
                            
                            <div class="row g-3">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="title" class="form-label fw-semibold">
                                                                                    <i class="fas fa-heading text-primary me-1"></i> Proposal Title <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control form-control-lg @error('title') is-invalid @enderror" 
                                               id="title" name="title" value="{{ old('title') }}" 
                                               placeholder="Enter a clear and concise thesis title" required>
                                        @error('title')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="thesis_type" class="form-label fw-semibold">
                                            <i class="fas fa-tag text-primary me-1"></i> Thesis Type <span class="text-danger">*</span>
                                        </label>
                                        <select class="form-select form-select-lg @error('thesis_type') is-invalid @enderror" 
                                                id="thesis_type" name="thesis_type" required>
                                            <option value="">Select Type</option>
                                            <option value="Web-based System" {{ old('thesis_type') == 'Web-based System' ? 'selected' : '' }}>
                                                🌐 Web-based System
                                            </option>
                                            <option value="Desktop Application" {{ old('thesis_type') == 'Desktop Application' ? 'selected' : '' }}>
                                                🖥️ Desktop Application
                                            </option>
                                            <option value="Mobile Application" {{ old('thesis_type') == 'Mobile Application' ? 'selected' : '' }}>
                                                📱 Mobile Application
                                            </option>
                                            <option value="Research Paper" {{ old('thesis_type') == 'Research Paper' ? 'selected' : '' }}>
                                                📄 Research Paper
                                            </option>
                                            <option value="System Development" {{ old('thesis_type') == 'System Development' ? 'selected' : '' }}>
                                                ⚙️ System Development
                                            </option>
                                        </select>
                                        @error('thesis_type')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- STEP 2: CATEGORY -->
                        <div class="step-wrapper mb-4">
                            <div class="step-header d-flex align-items-center gap-3 mb-3">
                                <div class="step-number d-flex align-items-center justify-content-center rounded-circle bg-success text-white" style="width: 32px; height: 32px; font-weight: 700; font-size: 14px;">
                                    2
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-0">Category Selection</h6>
                                    <small class="text-muted">Select your thesis category</small>
                                </div>
                                <span class="badge bg-danger bg-opacity-10 text-danger ms-auto rounded-pill px-3 py-1">Required</span>
                            </div>
                            
                            <div class="row g-3">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="category_id" class="form-label fw-semibold">
                                            <i class="fas fa-tags text-primary me-1"></i> Category <span class="text-danger">*</span>
                                        </label>
                                        <select class="form-select form-select-lg @error('category_id') is-invalid @enderror" 
                                                id="category_id" name="category_id" required>
                                            <option value="">Select Category</option>
                                            @foreach($categories as $category)
                                                <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>
                                                    {{ $category->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('category_id')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- STEP 3: ACADEMIC YEAR -->
                        <div class="step-wrapper mb-4">
                            <div class="step-header d-flex align-items-center gap-3 mb-3">
                                <div class="step-number d-flex align-items-center justify-content-center rounded-circle bg-warning text-dark" style="width: 32px; height: 32px; font-weight: 700; font-size: 14px;">
                                    3
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-0">Academic Year</h6>
                                    <small class="text-muted">Study period</small>
                                </div>
                                <span class="badge bg-danger bg-opacity-10 text-danger ms-auto rounded-pill px-3 py-1">Required</span>
                            </div>
                            
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="from_year" class="form-label fw-semibold">
                                            <i class="fas fa-calendar-start text-primary me-1"></i> From Year <span class="text-danger">*</span>
                                        </label>
                                        <input type="number" class="form-control form-control-lg @error('from_year') is-invalid @enderror" 
                                               id="from_year" name="from_year" value="{{ old('from_year', date('Y')) }}" 
                                               min="2000" max="{{ date('Y') + 5 }}" required>
                                        @error('from_year')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="to_year" class="form-label fw-semibold">
                                            <i class="fas fa-calendar-end text-primary me-1"></i> To Year <span class="text-danger">*</span>
                                        </label>
                                        <input type="number" class="form-control form-control-lg @error('to_year') is-invalid @enderror" 
                                               id="to_year" name="to_year" value="{{ old('to_year', date('Y') + 1) }}" 
                                               min="2000" max="{{ date('Y') + 6 }}" required>
                                        @error('to_year')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- STEP 4: THESIS DETAILS -->
                        <div class="step-wrapper mb-4">
                            <div class="step-header d-flex align-items-center gap-3 mb-3">
                                <div class="step-number d-flex align-items-center justify-content-center rounded-circle bg-info text-dark" style="width: 32px; height: 32px; font-weight: 700; font-size: 14px;">
                                    4
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-0">Thesis Details</h6>
                                    <small class="text-muted">Abstract and keywords</small>
                                </div>
                                <span class="badge bg-danger bg-opacity-10 text-danger ms-auto rounded-pill px-3 py-1">Required</span>
                            </div>
                            
                            <div class="row g-3">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="abstract" class="form-label fw-semibold">
                                            <i class="fas fa-align-left text-primary me-1"></i> Abstract <span class="text-danger">*</span>
                                        </label>
                                        <textarea class="form-control form-control-lg @error('abstract') is-invalid @enderror" 
                                                  id="abstract" name="abstract" rows="5" 
                                                  placeholder="Write a comprehensive summary of your proposal..." 
                                                  style="min-height: 150px;" required>{{ old('abstract') }}</textarea>
                                        @error('abstract')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="keywords" class="form-label fw-semibold">
                                            <i class="fas fa-hashtag text-primary me-1"></i> Keywords <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control form-control-lg @error('keywords') is-invalid @enderror" 
                                               id="keywords" name="keywords" value="{{ old('keywords') }}" 
                                               placeholder="e.g., Machine Learning, NLP, Education, Web Development">
                                        @error('keywords')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                        <small class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Separate keywords with commas
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- SUPERVISOR INFO -->
                        <div class="step-wrapper mb-4 bg-light">
                            <div class="step-header d-flex align-items-center gap-3 mb-3">
                                <div class="step-number d-flex align-items-center justify-content-center rounded-circle bg-secondary text-white" style="width: 32px; height: 32px; font-weight: 700; font-size: 14px;">
                                    ⚡
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-0">Supervisor Assignment</h6>
                                    <small class="text-muted">Admin will assign a supervisor to your thesis</small>
                                </div>
                                <span class="badge bg-secondary text-white ms-auto rounded-pill px-3 py-1">Auto-assigned</span>
                            </div>
                            
                            <div class="alert alert-info border-0 rounded-3 mb-0">
                                <div class="d-flex align-items-start gap-2">
                                    <i class="fas fa-info-circle mt-1"></i>
                                    <div>
                                        <strong>Note:</strong> You don't need to select a supervisor. 
                                        The admin will assign a supervisor to your thesis after submission.
                                        <br>
                                        <small class="text-muted mt-1 d-block">
                                            <i class="fas fa-clock me-1"></i>
                                            You can submit your proposal once a supervisor is assigned.
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- FORM ACTIONS -->
                        <div class="d-flex flex-wrap gap-3 justify-content-end pt-3 border-top">
                            <a href="{{ route('student.proposals.index') }}" class="btn btn-outline-secondary rounded-pill px-4 py-2">
                                <i class="fas fa-times me-2"></i> Cancel
                            </a>
                            <button type="reset" class="btn btn-outline-secondary rounded-pill px-4 py-2">
                                <i class="fas fa-undo me-2"></i> Reset
                            </button>
                            <button type="submit" class="btn btn-primary rounded-pill px-5 py-2 shadow-sm">
                                                            <i class="fas fa-paper-plane me-2"></i> Create Proposal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- SIDEBAR -->
        <div class="col-lg-4">
            <div class="card shadow-sm border-0 rounded-4 mb-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">
                        <i class="fas fa-lightbulb text-warning me-2"></i> Helpful Tips
                    </h6>
                    <div class="d-flex gap-3 mb-3">
                        <div class="bg-primary bg-opacity-10 p-2 rounded-3" style="width: 40px; height: 40px; text-align: center;">
                            <i class="fas fa-pen text-primary"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0" style="font-size: 14px;">Clear Title</h6>
                            <small class="text-muted">Choose a concise title that reflects your research</small>
                        </div>
                    </div>
                    <div class="d-flex gap-3 mb-3">
                        <div class="bg-success bg-opacity-10 p-2 rounded-3" style="width: 40px; height: 40px; text-align: center;">
                            <i class="fas fa-tag text-success"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0" style="font-size: 14px;">Right Category</h6>
                            <small class="text-muted">Select the appropriate category for your thesis</small>
                        </div>
                    </div>
                    <div class="d-flex gap-3 mb-3">
                        <div class="bg-info bg-opacity-10 p-2 rounded-3" style="width: 40px; height: 40px; text-align: center;">
                            <i class="fas fa-align-left text-info"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0" style="font-size: 14px;">Strong Abstract</h6>
                            <small class="text-muted">Write a comprehensive summary of your research</small>
                        </div>
                    </div>
                    <div class="d-flex gap-3">
                        <div class="bg-warning bg-opacity-10 p-2 rounded-3" style="width: 40px; height: 40px; text-align: center;">
                            <i class="fas fa-user-check text-warning"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0" style="font-size: 14px;">Supervisor Assigned</h6>
                            <small class="text-muted">Admin will assign a supervisor to guide your thesis</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">
                        <i class="fas fa-info-circle text-info me-2"></i> Quick Info
                    </h6>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Fields</span>
                        <span class="fw-semibold">7 Required</span>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Status</span>
                        <span class="badge bg-warning rounded-pill">Draft</span>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Supervisor</span>
                        <span class="badge bg-secondary rounded-pill">Not Assigned</span>
                    </div>
                    <div class="d-flex justify-content-between py-2">
                        <span class="text-muted">Created By</span>
                        <span class="fw-semibold">{{ Auth::user()->name ?? 'You' }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- CUSTOM STYLES -->
<!-- ============================================ -->
<style>
    .step-wrapper {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 1rem;
        border: 1px solid #e9ecef;
        transition: all 0.3s ease;
    }
    
    .step-wrapper:hover {
        border-color: #0d6efd;
        background: #ffffff;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
    }
    
    .step-wrapper.bg-light {
        background: #f0f2f5 !important;
    }
    
    .step-number {
        font-weight: 700;
        flex-shrink: 0;
    }
    
    .step-number.bg-success {
        background: #198754 !important;
    }
    
    .step-number.bg-warning {
        background: #ffc107 !important;
        color: #212529 !important;
    }
    
    .step-number.bg-info {
        background: #0dcaf0 !important;
        color: #212529 !important;
    }
    
    .step-number.bg-secondary {
        background: #6c757d !important;
    }
    
    .form-control-lg, .form-select-lg {
        border-radius: 0.75rem;
        border: 2px solid #e9ecef;
        padding: 0.75rem 1rem;
        font-size: 0.95rem;
        transition: all 0.3s ease;
        background-color: #ffffff;
    }
    
    .form-control-lg:focus, .form-select-lg:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1);
    }
    
    .form-control-lg.is-invalid, .form-select-lg.is-invalid {
        border-color: #dc3545;
        box-shadow: 0 0 0 4px rgba(220, 53, 69, 0.1);
    }
    
    .form-label {
        font-size: 0.9rem;
        color: #1a1a2e;
        margin-bottom: 0.5rem;
    }
    
    .btn {
        font-weight: 600;
        font-size: 14px;
        transition: all 0.3s ease;
    }
    
    .btn-primary {
        background: linear-gradient(135deg, #0d6efd, #0a58ca);
        border: none;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(13, 110, 253, 0.3);
    }
    
    .btn-outline-secondary:hover {
        transform: translateY(-2px);
    }
    
    .alert-danger {
        background: #f8d7da;
        border-left: 4px solid #dc3545;
    }
    
    .alert-info {
        background: #cfe2ff;
        border-left: 4px solid #0d6efd;
    }
    
    textarea.form-control-lg {
        resize: vertical;
        min-height: 100px;
    }
    
    textarea.form-control-lg::-webkit-scrollbar {
        width: 6px;
    }
    
    textarea.form-control-lg::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 3px;
    }
    
    textarea.form-control-lg::-webkit-scrollbar-thumb {
        background: #c1c7cd;
        border-radius: 3px;
    }
    
    textarea.form-control-lg::-webkit-scrollbar-thumb:hover {
        background: #a8b0b8;
    }
    
    @media (max-width: 768px) {
        .step-wrapper {
            padding: 1rem;
        }
        
        .step-header {
            flex-wrap: wrap;
        }
        
        .step-header .badge {
            margin-left: 0 !important;
            margin-top: 0.5rem;
        }
        
        .btn {
            width: 100%;
            justify-content: center;
        }
        
        .d-flex.gap-3.justify-content-end {
            flex-direction: column;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const textarea = document.getElementById('abstract');
        if (textarea) {
            textarea.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = this.scrollHeight + 'px';
            });
        }

        const fromYear = document.getElementById('from_year');
        const toYear = document.getElementById('to_year');
        
        if (fromYear && toYear) {
            fromYear.addEventListener('change', function() {
                if (parseInt(this.value) >= parseInt(toYear.value)) {
                    toYear.value = parseInt(this.value) + 1;
                }
            });
        }

        const form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                const submitBtn = this.querySelector('button[type="submit"]');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Creating Proposal...';
            });
        }
    });
</script>
@endsection