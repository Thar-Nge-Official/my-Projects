@extends('layouts.app')

@section('title', 'Reset Password')

@section('content')
@php
    $universityName = trim((string) ($appSettings->university_name ?? ''));
    $departmentName = trim((string) ($appSettings->department_name ?? ''));
    $institutionLine = trim($universityName . ($universityName && $departmentName ? ' - ' : '') . $departmentName);
@endphp
<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="auth-container">
            <div class="auth-header">
                <div class="university-logo">
                    <i class="fas fa-lock-open"></i>
                </div>
                <h2>Reset Password</h2>
                <p class="subtitle">Enter your new password</p>
                @if($institutionLine)
                    <div class="university-name">
                        <i class="fas fa-map-marker-alt"></i> {{ $institutionLine }}
                    </div>
                @endif
            </div>

            
            <form action="{{ route('password.update') }}" method="POST">
                @csrf
                <input type="hidden" name="token" value="{{ $token }}">

                <div class="mb-3">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <input type="email" 
                           class="form-control @error('email') is-invalid @enderror" 
                           id="email" 
                           name="email" 
                           value="{{ old('email') }}" 
                           required 
                           autofocus>
                    @error('email')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">
                        <i class="fas fa-lock"></i> New Password
                    </label>
                    <div class="input-group">
                        <input type="password" 
                               class="form-control @error('password') is-invalid @enderror" 
                               id="password" 
                               name="password" 
                               placeholder="Enter new password (min 8 characters)" 
                               required>
                        <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    @error('password')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="password_confirmation" class="form-label">
                        <i class="fas fa-check-circle"></i> Confirm Password
                    </label>
                    <input type="password" 
                           class="form-control" 
                           id="password_confirmation" 
                           name="password_confirmation" 
                           placeholder="Confirm your new password" 
                           required>
                </div>

                <button type="submit" class="btn btn-success w-100">
                    <i class="fas fa-check-circle"></i> Reset Password
                </button>

                <div class="auth-link">
                    <a href="{{ route('login') }}">Back to Login</a>
                </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
    document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const icon = this.querySelector('i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.className = 'fas fa-eye-slash';
        } else {
            passwordInput.type = 'password';
            icon.className = 'fas fa-eye';
        }
    });
</script>
@endpush
@endsection
