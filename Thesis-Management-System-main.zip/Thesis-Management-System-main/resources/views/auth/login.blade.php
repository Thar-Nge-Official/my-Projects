@extends('layouts.app')

@section('title', 'Login - ' . (trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System'))

@section('content')
@php
    $systemName = trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System';
    $universityName = trim((string) ($appSettings->university_name ?? ''));
    $departmentName = trim((string) ($appSettings->department_name ?? ''));
    $institutionLine = trim($universityName . ($universityName && $departmentName ? ' - ' : '') . $departmentName);
@endphp
<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="auth-container">
            <!-- Logo/Header -->
            <div class="auth-header">
                <div class="university-logo">
                    <i class="fas fa-university"></i>
                </div>
                <h2>{{ $systemName }}</h2>
                <p class="subtitle">Login to your account</p>
                @if($institutionLine)
                    <div class="university-name">
                        <i class="fas fa-map-marker-alt"></i> {{ $institutionLine }}
                    </div>
                @endif
            </div>

            <!-- Login Form -->
            <form action="{{ route('login') }}" method="POST">
                @csrf

                <!-- Email -->
                <div class="mb-3">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <input type="email" 
                           class="form-control @error('email') error-border @enderror" 
                           id="email" 
                           name="email" 
                           value="{{ old('email') }}" 
                           placeholder="Enter your email" 
                           required 
                           autofocus>
                    @error('email')
                        <div class="error-text"><i class="fas fa-exclamation-circle"></i> {{ $message }}</div>
                    @enderror
                </div>

                <!-- Password -->
                <div class="mb-3">
                    <label for="password" class="form-label">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <div class="input-group">
                        <input type="password" 
                               class="form-control @error('password') error-border @enderror" 
                               id="password" 
                               name="password" 
                               placeholder="Enter your password" 
                               required>
                        <button class="btn btn-outline-secondary" type="button" id="togglePassword" style="border-radius: 0 10px 10px 0;">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    @error('password')
                        <div class="error-text"><i class="fas fa-exclamation-circle"></i> {{ $message }}</div>
                    @enderror
                </div>

                <!-- Remember Me -->
                <div class="mb-3 d-flex justify-content-between align-items-center">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                        <label class="form-check-label" for="remember" style="font-size: 14px;">
                            <i class="fas fa-check-circle" style="color: #0d6efd;"></i> Remember Me
                        </label>
                    </div>
                    <a href="{{ route('password.request') }}" class="text-decoration-none" style="font-size: 14px;">
                        <i class="fas fa-key"></i> Forgot Password?
                    </a>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>

                <!-- Register Link -->
                <div class="auth-link">
                    Don't have an account? <a href="{{ route('register') }}">Register here</a>
                </div>

                <!-- ============================================ -->
                <!-- QR CODE LOGIN LINK -->
                <!-- ============================================ -->
                <div class="text-center mt-3">
                    <a href="{{ route('qr.scanner') }}" class="text-decoration-none" style="font-size: 14px; color: #6c757d;">
                        <i class="fas fa-qrcode"></i> Login with QR Code
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
    // Toggle Password Visibility
    document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const icon = this.querySelector('i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.className = 'fas fa-eye-slash';
        } else {
            passwordInput.type = 'password';
            icon.className = 'fas fa-eye';
        }
    });
</script>
@endpush
@endsection
