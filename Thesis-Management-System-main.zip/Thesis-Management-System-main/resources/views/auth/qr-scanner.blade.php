@extends('layouts.app')

@section('title', 'QR Code Scanner')

@section('content')
@php
    $universityName = trim((string) ($appSettings->university_name ?? ''));
    $departmentName = trim((string) ($appSettings->department_name ?? ''));
    $institutionLine = trim($universityName . ($universityName && $departmentName ? ' - ' : '') . $departmentName);
@endphp
<div class="row justify-content-center">
    <div class="col-md-8 col-lg-7">
        <div class="auth-container">
            <div class="auth-header">
                <div class="university-logo">
                    <i class="fas fa-qrcode"></i>
                </div>
                <h2>QR Code Scanner</h2>
                <p class="subtitle">Scan your QR Code to login instantly</p>
                @if($institutionLine)
                    <div class="university-name">
                        <i class="fas fa-map-marker-alt"></i> {{ $institutionLine }}
                    </div>
                @endif
            </div>

            <!-- ============================================ -->
            <!-- OPTION 1: Upload QR Code Image -->
            <!-- ============================================ -->
            <div class="upload-section mb-3">
                <div class="card">
                    <div class="card-body">
                        <h6><i class="fas fa-upload"></i> Upload QR Code Image</h6>
                        <p class="text-muted small">Upload a QR Code image (PNG, JPG, SVG) to scan</p>
                        <div class="input-group">
                            <input type="file" 
                                   class="form-control" 
                                   id="qrImageInput" 
                                   accept="image/*"
                                   aria-describedby="uploadBtn">
                            <button class="btn btn-primary" type="button" id="uploadBtn">
                                <i class="fas fa-sync"></i> Scan
                            </button>
                        </div>
                        <div id="uploadStatus" class="mt-2" style="display: none;">
                            <div class="spinner-border spinner-border-sm text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <span class="ms-2">Scanning QR Code...</span>
                        </div>
                        <div id="uploadResult" class="mt-2"></div>
                    </div>
                </div>
            </div>

            <!-- ============================================ -->
            <!-- OPTION 2: Webcam Scanner -->
            <!-- ============================================ -->
            <div class="scanner-section">
                <div class="card">
                    <div class="card-body">
                        <h6><i class="fas fa-camera"></i> Scan with Webcam</h6>
                        <p class="text-muted small">Use your device camera to scan QR Code</p>
                        
                        <!-- QR Scanner -->
                        <div class="scanner-container">
                            <div id="reader" style="width: 100%;"></div>
                            
                            <!-- Camera Permission Message -->
                            <div id="camera-permission" class="text-center mt-3" style="display: none;">
                                <i class="fas fa-camera" style="font-size: 48px; color: #6c757d;"></i>
                                <p class="text-muted mt-2" id="camera-message">Press Start Camera and allow camera access to scan QR Code</p>
                                <div id="camera-select-wrap" class="camera-select-wrap mb-3" style="display: none;">
                                    <label for="cameraSelect" class="form-label small text-muted mb-1">Camera</label>
                                    <select id="cameraSelect" class="form-select">
                                        <option value="">Detecting cameras...</option>
                                    </select>
                                </div>
                                <button onclick="startScanner()" class="btn btn-primary" id="startCameraBtn">
                                    <i class="fas fa-camera"></i> Start Camera
                                </button>
                            </div>

                            <!-- Loading Spinner -->
                            <div id="scanner-loading" class="text-center mt-3" style="display: none;">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <p class="text-muted mt-2" id="scanner-loading-text">Initializing camera...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-4 text-center">
                <a href="{{ route('login') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Login
                </a>
            </div>
        </div>
    </div>
</div>

<!-- QR Code Scanner Libraries -->
<script src="{{ asset('vendor/qr-scanner/html5-qrcode.min.js') }}"></script>
<script src="{{ asset('vendor/qr-scanner/jsQR.js') }}"></script>

<style>
    .scanner-container {
        background: #f8f9fa;
        border-radius: 12px;
        padding: 20px;
        border: 2px dashed #dee2e6;
        min-height: 250px;
        position: relative;
    }

    #reader {
        border: none !important;
        border-radius: 8px;
        overflow: hidden;
    }

    #reader video {
        border-radius: 8px;
        width: 100% !important;
        height: auto !important;
    }

    #reader .qr-scanner {
        border: none !important;
    }

    .camera-select-wrap {
        max-width: 420px;
        margin-left: auto;
        margin-right: auto;
        text-align: left;
    }

    .upload-section .card,
    .scanner-section .card {
        border-radius: 12px;
        border: 1px solid #e9ecef;
    }

    .upload-section .card-body,
    .scanner-section .card-body {
        padding: 20px;
    }

    .scanner-instruction {
        text-align: center;
        padding: 10px;
        background: rgba(13, 110, 253, 0.1);
        border-radius: 8px;
        margin-top: 10px;
        color: #0d6efd;
        font-size: 14px;
    }

    #uploadResult .alert {
        border-radius: 8px;
        padding: 10px 15px;
        margin: 0;
    }

    #uploadResult .alert-success {
        background: #d1e7dd;
        color: #0f5132;
    }

    #uploadResult .alert-danger {
        background: #f8d7da;
        color: #842029;
    }
</style>

<script>
    let html5QrCode = null;
    let scannerStarting = false;
    let scannerRunning = false;
    let cameraTimeout = null;
    let availableCameras = [];
    let selectedCameraId = '';

    function resolveQrLoginUrl(decodedText) {
        try {
            const scannedUrl = new URL(decodedText);
            const localHosts = ['localhost', '127.0.0.1'];
            const isLocalNetwork = scannedUrl.hostname.startsWith('192.168.');
            const isQrLoginRoute = scannedUrl.pathname.startsWith('/qr-login/scan/');

            if (isQrLoginRoute && (localHosts.includes(scannedUrl.hostname) || isLocalNetwork)) {
                return window.location.origin + scannedUrl.pathname + scannedUrl.search + scannedUrl.hash;
            }

            return scannedUrl.href;
        } catch (error) {
            return decodedText;
        }
    }

    // ============================================
    // FILE UPLOAD SCANNER
    // ============================================
    document.getElementById('uploadBtn').addEventListener('click', function() {
        const fileInput = document.getElementById('qrImageInput');
        const file = fileInput.files[0];
        
        if (!file) {
            alert('Please select a QR Code image first.');
            return;
        }

        const statusDiv = document.getElementById('uploadStatus');
        const resultDiv = document.getElementById('uploadResult');
        
        statusDiv.style.display = 'block';
        resultDiv.innerHTML = '';

        const reader = new FileReader();
        reader.onload = function(e) {
            const image = new Image();
            image.onload = function() {
                try {
                    // Create canvas and draw image
                    const canvas = document.createElement('canvas');
                    canvas.width = image.width;
                    canvas.height = image.height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
                    
                    // Get image data
                    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                    const code = jsQR(imageData.data, imageData.width, imageData.height);
                    
                    statusDiv.style.display = 'none';
                    
                    if (code && code.data) {
                        // QR Code detected - redirect
                        resultDiv.innerHTML = `
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i> QR Code detected! Redirecting...
                            </div>
                        `;
                        setTimeout(() => {
                            window.location.href = resolveQrLoginUrl(code.data);
                        }, 1000);
                    } else {
                        resultDiv.innerHTML = `
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-circle"></i> No QR Code found in the image. Please try again.
                            </div>
                        `;
                    }
                } catch (error) {
                    statusDiv.style.display = 'none';
                    resultDiv.innerHTML = `
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> Error scanning image: ${error.message}
                        </div>
                    `;
                }
            };
            image.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });

    // ============================================
    // WEBCAM SCANNER
    // ============================================
    function startScanner() {
        if (scannerStarting) {
            return;
        }

        if (!window.isSecureContext) {
            showCameraMessage(
                'Camera access is blocked because this page is opened with HTTP. Use HTTPS or upload the QR image below.'
            );
            return;
        }

        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            showCameraMessage('This browser does not support camera scanning. Please upload your QR image instead.');
            return;
        }

        if (typeof Html5Qrcode === 'undefined') {
            showCameraMessage('QR scanner library is still loading. Please wait a moment and press Start Camera again.');
            return;
        }

        setStartButtonLoading(true);
        scannerStarting = true;
        document.getElementById('scanner-loading').style.display = 'block';
        document.getElementById('scanner-loading-text').textContent = 'Checking available cameras...';
        document.getElementById('camera-permission').style.display = 'none';

        const readerElement = document.getElementById('reader');
        readerElement.style.display = 'block';

        if (html5QrCode) {
            const stopPromise = scannerRunning ? html5QrCode.stop() : Promise.resolve();

            stopPromise.then(() => {
                html5QrCode.clear();
                initializeScanner();
            }).catch(() => {
                initializeScanner();
            });
        } else {
            initializeScanner();
        }
    }

    function initializeScanner() {
        clearTimeout(cameraTimeout);
        html5QrCode = new Html5Qrcode("reader");

        const config = {
            fps: 10,
            qrbox: { width: 250, height: 250 },
            aspectRatio: 1.0
        };

        cameraTimeout = setTimeout(() => {
            if (!scannerRunning) {
                document.getElementById('scanner-loading-text').textContent = 'Still waiting for camera permission. Please allow camera access if your browser asks.';
            }
        }, 15000);

        Html5Qrcode.getCameras()
            .then((cameras) => {
                if (!cameras || cameras.length === 0) {
                    throw new Error('No camera found');
                }

                document.getElementById('scanner-loading-text').textContent = 'Starting camera...';

                availableCameras = cameras;
                renderCameraSelector(cameras);

                const cameraId = selectedCameraId || chooseCameraId(cameras);
                selectedCameraId = cameraId;

                return html5QrCode.start(
                    cameraId,
                    config,
                    onScanSuccess,
                    onScanError
                );
            })
            .then(onCameraStarted)
            .catch((cameraListError) => {
                document.getElementById('scanner-loading-text').textContent = 'Trying default camera...';

                tryCamera({ facingMode: "environment" }, config)
                    .catch(() => {
                        document.getElementById('scanner-loading-text').textContent = 'Trying front camera...';

                        return tryCamera({ facingMode: "user" }, config);
                    })
                    .then(onCameraStarted)
                    .catch((err) => {
                        clearTimeout(cameraTimeout);
                        scannerStarting = false;
                        scannerRunning = false;
                        setStartButtonLoading(false);
                        showCameraMessage(cameraErrorMessage(err || cameraListError));
                        console.error('Camera error:', err || cameraListError);
                    });
            });
    }

    function tryCamera(cameraConfig, scannerConfig) {
        return html5QrCode.start(
            cameraConfig,
            scannerConfig,
            onScanSuccess,
            onScanError
        );
    }

    function chooseCameraId(cameras) {
        const preferredBuiltInCamera = cameras.find((camera) => {
            const label = String(camera.label || '').toLowerCase();
            return isBuiltInCamera(label);
        });

        if (preferredBuiltInCamera) {
            return preferredBuiltInCamera.id;
        }

        const nonVirtualCamera = cameras.find((camera) => {
            const label = String(camera.label || '').toLowerCase();
            return !isPhoneOrVirtualCamera(label);
        });

        return (nonVirtualCamera || cameras[0]).id;
    }

    function isBuiltInCamera(label) {
        const builtInTerms = ['integrated', 'built-in', 'builtin', 'internal', 'webcam', 'usb camera', 'hd camera', 'facetime'];
        return builtInTerms.some((term) => label.includes(term)) && !isPhoneOrVirtualCamera(label);
    }

    function isPhoneOrVirtualCamera(label) {
        const externalTerms = ['phone link', 'iphone', 'android', 'droidcam', 'iriun', 'epoccam', 'obs', 'virtual', 'snap camera', 'continuity'];
        return externalTerms.some((term) => label.includes(term));
    }

    function renderCameraSelector(cameras) {
        const wrapper = document.getElementById('camera-select-wrap');
        const select = document.getElementById('cameraSelect');

        if (!wrapper || !select || !cameras || cameras.length === 0) {
            return;
        }

        const preferredCameraId = selectedCameraId || chooseCameraId(cameras);

        select.innerHTML = cameras.map((camera, index) => {
            const label = camera.label || `Camera ${index + 1}`;
            const selected = camera.id === preferredCameraId ? 'selected' : '';

            return `<option value="${escapeHtml(camera.id)}" ${selected}>${escapeHtml(label)}</option>`;
        }).join('');

        selectedCameraId = preferredCameraId;
        wrapper.style.display = 'block';
    }

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function onCameraStarted() {
        clearTimeout(cameraTimeout);
        scannerStarting = false;
        scannerRunning = true;
        setStartButtonLoading(false);
        document.getElementById('scanner-loading').style.display = 'none';
        document.getElementById('camera-permission').style.display = 'none';
    }

    function showCameraMessage(message) {
        document.getElementById('scanner-loading').style.display = 'none';
        document.getElementById('camera-permission').style.display = 'block';
        document.getElementById('camera-message').textContent = message;
        setStartButtonLoading(false);
    }

    function setStartButtonLoading(isLoading) {
        const button = document.getElementById('startCameraBtn');

        if (!button) {
            return;
        }

        button.disabled = isLoading;
        button.innerHTML = isLoading
            ? '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Starting...'
            : '<i class="fas fa-camera"></i> Start Camera';
    }

    function cameraErrorMessage(error) {
        const message = String(error && (error.message || error.name || error) || '').toLowerCase();

        if (message.includes('permission') || message.includes('notallowed')) {
            return 'Camera permission was blocked. Allow camera access in the browser and press Start Camera again.';
        }

        if (message.includes('notfound') || message.includes('not found')) {
            return 'No camera was found on this device. Please upload your QR image instead.';
        }

        if (message.includes('notreadable') || message.includes('track')) {
            return 'The camera is busy in another app. Close other camera apps and press Start Camera again.';
        }

        return 'Camera could not start. Please refresh the page, allow camera access, or upload your QR image instead.';
    }

    function onScanSuccess(decodedText, decodedResult) {
        console.log('QR Code scanned:', decodedText);
        
        // Stop scanning
        if (html5QrCode) {
            html5QrCode.stop().then(() => {
                scannerRunning = false;
                html5QrCode.clear();
            });
        }

        // Redirect to the QR Code URL
        window.location.href = resolveQrLoginUrl(decodedText);
    }

    function onScanError(errorMessage) {
        // console.warn('Scan error:', errorMessage);
    }

    document.addEventListener('DOMContentLoaded', function() {
        const cameraSelect = document.getElementById('cameraSelect');

        if (cameraSelect) {
            cameraSelect.addEventListener('change', function() {
                selectedCameraId = this.value;

                if (scannerRunning) {
                    startScanner();
                }
            });
        }

        if (!window.isSecureContext) {
            showCameraMessage('Camera scanning needs HTTPS. This HTTP page can still scan by uploaded QR image.');
        } else if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            showCameraMessage('Press Start Camera and allow camera access when your browser asks.');
        } else {
            showCameraMessage('This browser does not support camera scanning. Please upload your QR image instead.');
        }
    });

    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        if (html5QrCode) {
            html5QrCode.stop().then(() => {
                scannerRunning = false;
                html5QrCode.clear();
            }).catch(() => {});
        }
    });
</script>
@endsection
