@extends('layouts.app')

@section('title', 'Register - ' . (trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System'))

@section('content')
@php
    $systemName = trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System';
    $universityName = trim((string) ($appSettings->university_name ?? ''));
    $departmentName = trim((string) ($appSettings->department_name ?? ''));
    $institutionLine = trim($universityName . ($universityName && $departmentName ? ' - ' : '') . $departmentName);
@endphp
<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="auth-container">
            <!-- Logo/Header -->
            <div class="auth-header">
                <div class="university-logo">
                    <i class="fas fa-user-plus"></i>
                </div>
                <h2>Create Account</h2>
                <p class="subtitle">Register to get started with {{ $systemName }}</p>
                @if($institutionLine)
                    <div class="university-name">
                        <i class="fas fa-map-marker-alt"></i> {{ $institutionLine }}
                    </div>
                @endif
            </div>

            @if($studentRegistrationClosed ?? false)
                <div class="alert alert-warning border-0 shadow-sm">
                    <i class="fas fa-lock me-2"></i>
                    Student registration is currently closed by the system administrator.
                </div>
            @endif

            <!-- Register Form -->
            <form action="{{ route('register') }}" method="POST" id="registerForm">
                @csrf

                <!-- Name Row -->
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="firstname" class="form-label">
                            <i class="fas fa-user"></i> First Name
                        </label>
                        <input type="text" 
                               class="form-control @error('firstname') error-border @enderror" 
                               id="firstname" 
                               name="firstname" 
                               value="{{ old('firstname') }}" 
                               placeholder="Enter first name" 
                               required>
                        @error('firstname')
                            <div class="error-text">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="lastname" class="form-label">
                            <i class="fas fa-user"></i> Last Name
                        </label>
                        <input type="text" 
                               class="form-control @error('lastname') error-border @enderror" 
                               id="lastname" 
                               name="lastname" 
                               value="{{ old('lastname') }}" 
                               placeholder="Enter last name" 
                               required>
                        @error('lastname')
                            <div class="error-text">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <!-- Email -->
                <div class="mb-3">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <input type="email" 
                           class="form-control @error('email') error-border @enderror" 
                           id="email" 
                           name="email" 
                           value="{{ old('email') }}" 
                           placeholder="Enter your email" 
                           required>
                    @error('email')
                        <div class="error-text">{{ $message }}</div>
                    @enderror
                </div>

                <!-- Password Row -->
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="password" class="form-label">
                            <i class="fas fa-lock"></i> Password
                        </label>
                        <div class="input-group">
                            <input type="password" 
                                   class="form-control @error('password') error-border @enderror" 
                                   id="password" 
                                   name="password" 
                                   placeholder="Enter password (min 8 characters)" 
                                   required>
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword" style="border-radius: 0 10px 10px 0;">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-text">Password must be at least 8 characters long.</div>
                        @error('password')
                            <div class="error-text">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="password_confirmation" class="form-label">
                            <i class="fas fa-check-circle"></i> Confirm Password
                        </label>
                        <input type="password" 
                               class="form-control" 
                               id="password_confirmation" 
                               name="password_confirmation" 
                               placeholder="Confirm your password" 
                               required>
                    </div>
                </div>

                <!-- User Type Selection -->
                <div class="mb-3">
                    <label for="type" class="form-label">
                        <i class="fas fa-user-tag"></i> Register as
                    </label>
                    <select class="form-select role-select @error('type') error-border @enderror" 
                            id="type" 
                            name="type" 
                            required>
                        <option value="">Select your role</option>
                        <option value="student" {{ old('type') == 'student' ? 'selected' : '' }} {{ ($studentRegistrationClosed ?? false) ? 'disabled' : '' }}>
                            Student
                        </option>
                        <option value="supervisor" {{ old('type') == 'supervisor' ? 'selected' : '' }}>
                            Supervisor
                        </option>
                        <option value="admin" {{ old('type') == 'admin' ? 'selected' : '' }}>
                            Admin
                        </option>
                    </select>
                    @error('type')
                        <div class="error-text">{{ $message }}</div>
                    @enderror
                </div>

                <!-- Student Fields -->
                <div id="studentFields" class="role-fields" style="{{ old('type') == 'student' ? 'display: block;' : 'display: none;' }}">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="roll_no" class="form-label">
                                <i class="fas fa-id-card"></i> Roll Number
                            </label>
                            <input type="text" 
                                   class="form-control" 
                                   id="roll_no" 
                                   name="roll_no" 
                                   value="{{ old('roll_no') }}" 
                                   placeholder="e.g., 2MCS-2">
                            <div class="form-text">For students only</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="class" class="form-label">
                                <i class="fas fa-chalkboard-teacher"></i> Class
                            </label>
                            <select class="form-select" id="class" name="class">
                                <option value="">Select your class</option>
                                <option value="Final Year" {{ old('class') == 'Final Year' ? 'selected' : '' }}>Final Year</option>
                                <option value="Second Year Honours" {{ old('class') == 'Second Year Honours' ? 'selected' : '' }}>Second Year Honours</option>
                                <option value="Master Second Year" {{ old('class') == 'Master Second Year' ? 'selected' : '' }}>Master Second Year</option>
                                <option value="PhD Research" {{ old('class') == 'PhD Research' ? 'selected' : '' }}>PhD Research</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Supervisor Fields -->
                <div id="supervisorFields" class="role-fields" style="{{ old('type') == 'supervisor' ? 'display: block;' : 'display: none;' }}">
                    <div class="mb-3">
                        <label for="rank" class="form-label">
                            <i class="fas fa-user-tie"></i> Rank
                        </label>
                        <input type="text" 
                               class="form-control" 
                               id="rank" 
                               name="rank" 
                               value="{{ old('rank') }}" 
                               placeholder="e.g., Professor, Associate Professor">
                        <div class="form-text">For supervisors only</div>
                    </div>
                </div>

                <!-- Admin Fields -->
                <div id="adminFields" class="role-fields" style="{{ old('type') == 'admin' ? 'display: block;' : 'display: none;' }}">
                    <div class="mb-3">
                        <label for="admin_rank" class="form-label">
                            <i class="fas fa-user-tie"></i> Admin Rank
                        </label>
                        <input type="text" 
                               class="form-control" 
                               id="admin_rank" 
                               name="rank" 
                               value="{{ old('rank', 'Professor and Head') }}" 
                               placeholder="Professor and Head">
                        <div class="form-text text-primary">
                            <i class="fas fa-info-circle"></i> Default: "Professor and Head"
                        </div>
                    </div>
                </div>

                <!-- Terms & Conditions -->
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="terms" name="terms" {{ old('terms') ? 'checked' : '' }} required>
                    <label class="form-check-label" for="terms">
                        I agree to the <a href="{{ route('legal.terms') }}" class="text-primary" target="_blank" rel="noopener">Terms of Service</a> and <a href="{{ route('legal.privacy') }}" class="text-primary" target="_blank" rel="noopener">Privacy Policy</a>
                    </label>
                    @error('terms')
                        <div class="error-text">{{ $message }}</div>
                    @enderror
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-success w-100" id="createAccountBtn" disabled>
                    <i class="fas fa-user-plus"></i> Create Account
                </button>

                <!-- Login Link -->
                <div class="auth-link">
                    Already have an account? <a href="{{ route('login') }}">Sign In</a>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    /* ============================================ */
    /* ADDITIONAL STYLES FOR REGISTER PAGE */
    /* ============================================ */
    
    .role-fields {
        animation: slideDown 0.3s ease;
        background: rgba(108, 99, 255, 0.03);
        border-radius: 12px;
        padding: 16px 18px;
        margin-bottom: 16px;
        border: 1px solid rgba(108, 99, 255, 0.06);
    }

    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .role-select {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 12px center;
        background-size: 12px 12px;
        appearance: none;
    }

    .form-check-input:checked {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }

    .form-check-label {
        color: rgba(0, 0, 0, 0.6);
        font-size: 14px;
    }

    .form-check-label a {
        text-decoration: none;
        font-weight: 600;
    }

    .form-check-label a:hover {
        text-decoration: underline;
    }

    #createAccountBtn:disabled {
        cursor: not-allowed;
        opacity: 0.55;
    }

    /* Responsive */
    @media (max-width: 576px) {
        .role-fields {
            padding: 12px 14px;
        }
    }
</style>

@push('scripts')
<script>
    // Toggle Password Visibility
    document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const icon = this.querySelector('i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.className = 'fas fa-eye-slash';
        } else {
            passwordInput.type = 'password';
            icon.className = 'fas fa-eye';
        }
    });

    // Show/Hide Fields based on Role
    document.getElementById('type').addEventListener('change', function() {
        const studentFields = document.getElementById('studentFields');
        const supervisorFields = document.getElementById('supervisorFields');
        const adminFields = document.getElementById('adminFields');
        
        // Hide all first
        studentFields.style.display = 'none';
        supervisorFields.style.display = 'none';
        adminFields.style.display = 'none';
        
        if (this.value === 'student') {
            studentFields.style.display = 'block';
        } else if (this.value === 'supervisor') {
            supervisorFields.style.display = 'block';
        } else if (this.value === 'admin') {
            adminFields.style.display = 'block';
        }
    });

    // Trigger on page load
    document.addEventListener('DOMContentLoaded', function() {
        const type = document.getElementById('type');
        const event = new Event('change');
        type.dispatchEvent(event);

        const termsCheckbox = document.getElementById('terms');
        const createAccountBtn = document.getElementById('createAccountBtn');

        function updateSubmitState() {
            createAccountBtn.disabled = !termsCheckbox.checked;
        }

        termsCheckbox.addEventListener('change', updateSubmitState);
        updateSubmitState();
    });
</script>
@endpush
@endsection
