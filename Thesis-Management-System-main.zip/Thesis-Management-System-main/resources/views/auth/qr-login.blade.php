@extends('layouts.app')

@section('title', 'QR Code Login')

@section('content')
@php
    $universityName = trim((string) ($appSettings->university_name ?? ''));
    $departmentName = trim((string) ($appSettings->department_name ?? ''));
    $institutionLine = trim($universityName . ($universityName && $departmentName ? ' - ' : '') . $departmentName);
@endphp
<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="auth-container">
            <div class="auth-header">
                <div class="university-logo">
                    <i class="fas fa-qrcode"></i>
                </div>
                <h2>Generate QR Code</h2>
                <p class="subtitle">Enter your credentials to generate QR Code</p>
                @if($institutionLine)
                    <div class="university-name">
                        <i class="fas fa-map-marker-alt"></i> {{ $institutionLine }}
                    </div>
                @endif
            </div>

            <form action="{{ route('qr.generate') }}" method="POST">
                @csrf

                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-qrcode"></i> Generate QR Code
                </button>

                <div class="auth-link">
                    <a href="{{ route('login') }}">Back to Login</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
