@extends('layouts.app')

@section('title', 'Forgot Password')

@section('content')
@php
    $universityName = trim((string) ($appSettings->university_name ?? ''));
    $departmentName = trim((string) ($appSettings->department_name ?? ''));
    $institutionLine = trim($universityName . ($universityName && $departmentName ? ' - ' : '') . $departmentName);
@endphp
<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="auth-container">
            <div class="auth-header">
                <div class="university-logo">
                    <i class="fas fa-key"></i>
                </div>
                <h2>Forgot Password</h2>
                <p class="subtitle">Enter your email to reset your password</p>
                @if($institutionLine)
                    <div class="university-name">
                        <i class="fas fa-map-marker-alt"></i> {{ $institutionLine }}
                    </div>
                @endif
            </div>

            
            <form action="{{ route('password.email') }}" method="POST">
                @csrf

                <div class="mb-3">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <input type="email" 
                           class="form-control" 
                           id="email" 
                           name="email" 
                           value="{{ old('email') }}" 
                           placeholder="Enter your email address" 
                           required 
                           autofocus>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-paper-plane"></i> Send Reset Link
                </button>

                <div class="auth-link">
                    <a href="{{ route('login') }}"><i class="fas fa-arrow-left"></i> Back to Login</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
