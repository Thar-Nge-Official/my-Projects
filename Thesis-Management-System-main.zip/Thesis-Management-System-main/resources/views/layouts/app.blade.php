<!DOCTYPE html>
<html lang="en">
<head>
    @php
        $systemName = trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System';
        $navLogo = $appSettings->logo ?? null;
    @endphp
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', $systemName)</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* ============================================
           GLOBAL STYLES
           ============================================ */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            background: #f0f2f5;
            padding-top: 70px;
        }

        /* Give authenticated pages comfortable space below the fixed navbar. */
        .main-content--with-navbar {
            padding-top: 1.5rem;
            padding-bottom: 2rem;
        }

        /* ============================================
           NAVBAR STYLES - STICKY TOP
           ============================================ */
        .navbar-dark.bg-dark {
            background: #1a1a2e !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            padding: 6px 0;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            width: 100%;
            z-index: 9999;
            backdrop-filter: blur(10px);
            background: rgba(26, 26, 46, 0.95) !important;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 18px;
            color: white !important;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 4px 0;
        }

        .navbar-brand i {
            font-size: 20px;
            color: #0d6efd;
        }

        .navbar-brand .logo-text {
            font-weight: 700;
            font-size: 18px;
            color: white;
        }

        .navbar-brand .logo-text span {
            color: #0d6efd;
        }

        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.7) !important;
            transition: all 0.3s ease;
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 14px;
        }

        .navbar-dark .nav-link:hover {
            color: white !important;
            background: rgba(255, 255, 255, 0.08);
        }

        .navbar-dark .nav-link.active {
            color: white !important;
            background: rgba(13, 110, 253, 0.2);
        }

        .navbar-dark .nav-link i {
            margin-right: 5px;
            font-size: 13px;
        }

        .navbar-avatar {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255, 255, 255, 0.2);
            margin-right: 6px;
        }

        .navbar-avatar-placeholder {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: #0d6efd;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 12px;
            margin-right: 6px;
        }

        .dropdown-toggle {
            padding: 4px 8px !important;
            font-size: 14px;
        }

        .dropdown-menu {
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            border: 1px solid #e9ecef;
            padding: 6px 0;
            font-size: 14px;
            margin-top: 8px;
        }

        .dropdown-item {
            padding: 6px 18px;
            font-size: 13px;
            transition: all 0.3s ease;
        }

        .dropdown-item:hover {
            background: #f8f9fa;
        }

        .dropdown-item.text-danger:hover {
            background: #f8d7da;
        }

        .dropdown-item i {
            width: 18px;
            margin-right: 6px;
            text-align: center;
            font-size: 13px;
        }

        .navbar .badge {
            font-size: 10px;
            padding: 2px 6px;
            margin-left: 4px;
        }

        .navbar-toggler {
            padding: 4px 8px;
            font-size: 16px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .navbar-toggler-icon {
            width: 20px;
            height: 20px;
        }

        /* ============================================
           ALERT MESSAGES - AUTO DISMISS
           ============================================ */
        .alert-auto-dismiss {
            animation: slideDown 0.5s ease forwards;
            position: relative;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-auto-dismiss .btn-close {
            position: absolute;
            right: 10px;
            top: 10px;
        }

        /* ============================================
           RESPONSIVE
           ============================================ */
        @media (max-width: 576px) {
            body {
                padding-top: 60px;
            }

            .main-content--with-navbar {
                padding-top: 1rem;
            }
            
            .navbar-brand {
                font-size: 16px;
            }

            .navbar-brand i {
                font-size: 18px;
            }

            .navbar-dark .nav-link {
                font-size: 13px;
                padding: 4px 10px;
            }
        }

        /* ============================================
           AUTH CONTAINER STYLES
           ============================================ */
        .auth-container {
            max-width: 450px;
            margin: 60px auto;
            padding: 35px 30px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            position: relative;
            z-index: 1;
            border: 1px solid #e9ecef;
        }

        .auth-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .auth-header .university-logo {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #0d6efd, #0a58ca);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            box-shadow: 0 8px 25px rgba(13, 110, 253, 0.3);
        }

        .auth-header .university-logo i {
            font-size: 35px;
            color: white;
        }

        .auth-header h2 {
            color: #1a1a2e;
            font-weight: 700;
            font-size: 24px;
            margin-bottom: 5px;
        }

        .auth-header .subtitle {
            color: #6c757d;
            font-size: 14px;
            font-weight: 400;
        }

        .auth-header .university-name {
            color: #0d6efd;
            font-weight: 600;
            font-size: 13px;
            margin-top: 5px;
            letter-spacing: 0.5px;
        }

        .auth-container .form-label {
            font-weight: 500;
            color: #1a1a2e;
            font-size: 14px;
        }

        .auth-container .form-control {
            border-radius: 10px;
            padding: 12px 15px;
            border: 2px solid #e9ecef;
            background: #f8f9fa;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .auth-container .form-control:focus {
            border-color: #0d6efd;
            background: white;
            box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1);
        }

        .auth-container .form-control.error-border {
            border-color: #dc3545;
        }

        .auth-container .btn-primary {
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            background: linear-gradient(135deg, #0d6efd, #0a58ca);
            border: none;
            transition: all 0.3s ease;
        }

        .auth-container .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(13, 110, 253, 0.3);
        }

        .auth-container .btn-success {
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            background: linear-gradient(135deg, #198754, #157347);
            border: none;
            transition: all 0.3s ease;
        }

        .auth-container .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(25, 135, 84, 0.3);
        }

        .auth-link {
            text-align: center;
            margin-top: 20px;
            color: #6c757d;
            font-size: 14px;
        }

        .auth-link a {
            color: #0d6efd;
            text-decoration: none;
            font-weight: 600;
        }

        .auth-link a:hover {
            text-decoration: underline;
            color: #0a58ca;
        }

        .alert {
            border-radius: 10px;
            padding: 12px 15px;
            border: none;
            font-size: 14px;
            margin-top: 20px;
        }

        .alert-success {
            background: #d1e7dd;
            color: #0f5132;
        }

        .alert-danger {
            background: #f8d7da;
            color: #842029;
        }

        .error-text {
            color: #dc3545;
            font-size: 12px;
            margin-top: 5px;
        }

        /* ============================================
           WELCOME PAGE STYLES
           ============================================ */
        .welcome-container {
            min-height: 80vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            z-index: 1;
        }

        .welcome-card {
            background: white;
            border-radius: 20px;
            padding: 50px 40px;
            max-width: 600px;
            width: 100%;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.08);
            border: 1px solid #e9ecef;
        }

        .welcome-card .icon {
            font-size: 70px;
            color: #0d6efd;
            margin-bottom: 20px;
        }

        .welcome-card h1 {
            color: #1a1a2e;
            font-weight: 700;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .welcome-card .subtitle {
            color: #6c757d;
            font-size: 16px;
            margin-bottom: 30px;
        }

        .welcome-card .btn-group {
            gap: 15px;
        }

        .welcome-card .btn {
            padding: 12px 35px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .welcome-card .btn:hover {
            transform: translateY(-2px);
        }
    </style>
    @stack('styles')
</head>
<body>
    @auth
    <!-- ============================================ -->
    <!-- NAVBAR WITH THESIS LINK -->
    <!-- ============================================ -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="{{ route('dashboard') }}">
                @if($navLogo)
                    <img src="{{ asset('storage/' . $navLogo) }}" alt="{{ $systemName }}" style="height: 28px; width: auto; max-width: 110px; object-fit: contain;">
                @else
                    <i class="fas fa-graduation-cap"></i>
                @endif
                <span class="logo-text">{{ $systemName }}</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <!-- ============================================ -->
                    <!-- DASHBOARD -->
                    <!-- ============================================ -->
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('dashboard') || request()->routeIs('admin.dashboard') || request()->routeIs('supervisor.dashboard') || request()->routeIs('student.dashboard') ? 'active' : '' }}" 
                           href="{{ route('dashboard') }}">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>

                    <!-- ============================================ -->
                    <!-- THESIS LINK - FOR ALL USERS -->
                    <!-- ============================================ -->
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('theses.*') ? 'active' : '' }}" 
                           href="{{ route('theses.index') }}">
                            <i class="fas fa-file-alt"></i> Theses
                            @if(Auth::user()->isStudent())
                                @php
                                    $draftCount = App\Models\Thesis::where('student_id', Auth::id())
                                                                   ->where('status', 'proposal_draft')
                                                                   ->count();
                                @endphp
                                @if($draftCount > 0)
                                    <span class="badge bg-warning rounded-pill">{{ $draftCount }}</span>
                                @endif
                            @endif
                        </a>
                    </li>

                    <!-- ============================================ -->
                    <!-- ============================================ -->
                    <!-- ⭐ PROPOSALS LINK - STUDENT ONLY              -->
                    <!-- ============================================ -->
                    <!-- ============================================ -->
                    @if(Auth::user()->isStudent())
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('student.proposals.*') ? 'active' : '' }}" 
                               href="{{ route('student.proposals.index') }}">
                                <i class="fas fa-pen-to-square"></i> My Proposals
                                @php
                                    $submittedCount = App\Models\ThesisProposal::where('student_id', Auth::id())
                                        ->where('status', 'submitted')
                                        ->count();
                                    
                                    $draftCount = App\Models\ThesisProposal::where('student_id', Auth::id())
                                        ->where('status', 'draft')
                                        ->count();
                                @endphp
                                @if($submittedCount > 0)
                                    <span class="badge bg-warning text-dark rounded-pill">{{ $submittedCount }}</span>
                                @endif
                                @if($draftCount > 0 && $draftCount < 3)
                                    <span class="badge bg-info rounded-pill">{{ $draftCount }}/3</span>
                                @endif
                            </a>
                        </li>
                    @endif

                    <!-- ============================================ -->
                    <!-- ============================================ -->
                    <!-- ⭐ PROPOSALS LINK - SUPERVISOR ONLY           -->
                    <!-- ============================================ -->
                    <!-- ============================================ -->
                    @if(Auth::user()->isSupervisor())
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('supervisor.proposals.*') ? 'active' : '' }}" 
                               href="{{ route('supervisor.proposals.index') }}">
                                <i class="fas fa-user-tie"></i> Proposals
                                @php
                                    $assignedCount = App\Models\ThesisProposal::where('supervisor_id', Auth::id())
                                        ->where('status', 'approved')
                                        ->count();
                                @endphp
                                @if($assignedCount > 0)
                                    <span class="badge bg-info rounded-pill">{{ $assignedCount }}</span>
                                @endif
                            </a>
                        </li>
                    @endif

                    <!-- ============================================ -->
                    <!-- ============================================ -->
                    <!-- ⭐ PROPOSALS LINK - ADMIN ONLY (DROPDOWN)     -->
                    <!-- ============================================ -->
                    <!-- ============================================ -->
                    @if(Auth::user()->isAdmin())
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle {{ request()->routeIs('admin.proposals.*') ? 'active' : '' }}" 
                               href="#" id="proposalsDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-clipboard-list"></i> Proposals
                                @php
                                    $pendingCount = App\Models\ThesisProposal::where('status', 'submitted')->count();
                                @endphp
                                @if($pendingCount > 0)
                                    <span class="badge bg-danger rounded-pill">{{ $pendingCount }}</span>
                                @endif
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="proposalsDropdown">
                                <li>
                                    <a class="dropdown-item {{ request()->routeIs('admin.proposals.index') ? 'active' : '' }}" 
                                       href="{{ route('admin.proposals.index') }}">
                                        <i class="fas fa-list"></i> All Proposals
                                        @php
                                            $allCount = App\Models\ThesisProposal::count();
                                        @endphp
                                        <span class="badge bg-secondary float-end">{{ $allCount }}</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item {{ request()->routeIs('admin.proposals.pending') ? 'active' : '' }}" 
                                       href="{{ route('admin.proposals.pending') }}">
                                        <i class="fas fa-clock text-warning"></i> Pending
                                        @php
                                            $pendingCount2 = App\Models\ThesisProposal::where('status', 'submitted')->count();
                                        @endphp
                                        @if($pendingCount2 > 0)
                                            <span class="badge bg-danger float-end">{{ $pendingCount2 }}</span>
                                        @endif
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item {{ request()->routeIs('admin.proposals.approved') ? 'active' : '' }}" 
                                       href="{{ route('admin.proposals.approved') }}">
                                        <i class="fas fa-check-circle text-success"></i> Approved
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item {{ request()->routeIs('admin.proposals.rejected') ? 'active' : '' }}" 
                                       href="{{ route('admin.proposals.rejected') }}">
                                        <i class="fas fa-times-circle text-danger"></i> Rejected
                                    </a>
                                </li>
                            </ul>
                        </li>
                    @endif

                    <!-- ============================================ -->
                    <!-- ADMIN LINKS -->
                    <!-- ============================================ -->
                    @if(Auth::user()->isAdmin())
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.categories*') ? 'active' : '' }}" 
                               href="{{ route('admin.categories') }}">
                                <i class="fas fa-tags"></i> Categories
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.users*') ? 'active' : '' }}" 
                               href="{{ route('admin.users') }}">
                                <i class="fas fa-users"></i> Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.registrations*') ? 'active' : '' }}" 
                               href="{{ route('admin.registrations') }}">
                                <i class="fas fa-user-plus"></i> Registrations
                                @php
                                    $pendingRegCount = App\Models\User::where('registration_status', 'pending')->count();
                                @endphp
                                @if($pendingRegCount > 0)
                                    <span class="badge bg-danger rounded-pill">{{ $pendingRegCount }}</span>
                                @endif
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.settings*') ? 'active' : '' }}" 
                               href="{{ route('admin.settings') }}">
                                <i class="fas fa-cog"></i> System Settings
                            </a>
                        </li>
                    @endif
                </ul>
                
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <?php $navAvatarUrl = (Auth::user()->avatar && Auth::user()->avatar != 'no-image-available.png') ? ('/storage/avatars/' . rawurlencode(Auth::user()->avatar)) : null; ?>
                            @if($navAvatarUrl)
                                <img src="{{ $navAvatarUrl }}" 
                                     alt="{{ Auth::user()->name ?? Auth::user()->firstname }}" 
                                     class="navbar-avatar" loading="lazy">
                            @else
                                <span class="navbar-avatar-placeholder">
                                    {{ strtoupper(substr(Auth::user()->name ?? Auth::user()->firstname, 0, 1)) }}
                                </span>
                            @endif
                            {{ Auth::user()->name ?? Auth::user()->firstname }}
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item {{ request()->routeIs('profile.index') ? 'active' : '' }}" 
                                   href="{{ route('profile.index') }}">
                                    <i class="fas fa-user-circle"></i> Profile
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item {{ request()->routeIs('qr.*') ? 'active' : '' }}" 
                                   href="{{ route('qr.show') }}">
                                    <i class="fas fa-qrcode"></i> QR Code
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="{{ route('logout') }}" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="fas fa-sign-out-alt"></i> Logout
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    @endauth

    <!-- ============================================ -->
    <!-- MAIN CONTENT WITH AUTO-DISMISS ALERTS -->
    <!-- ============================================ -->
    <div class="container main-content {{ auth()->check() ? 'main-content--with-navbar' : '' }}" style="position: relative; z-index: 1;">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show alert-auto-dismiss" role="alert" id="alertSuccess">
                <i class="fas fa-check-circle"></i> {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show alert-auto-dismiss" role="alert" id="alertError">
                <i class="fas fa-exclamation-circle"></i> {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        @if($errors->any())
            <div class="alert alert-danger alert-dismissible fade show alert-auto-dismiss" role="alert">
                <i class="fas fa-exclamation-circle"></i> 
                <ul class="mb-0 mt-2">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        @yield('content')
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- ============================================ -->
    <!-- AUTO-DISMISS ALERT SCRIPT (3 seconds) -->
    <!-- ============================================ -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-dismiss success alerts after 3 seconds
            const successAlert = document.getElementById('alertSuccess');
            if (successAlert) {
                setTimeout(function() {
                    const alert = new bootstrap.Alert(successAlert);
                    alert.close();
                }, 3000);
            }

            // Auto-dismiss error alerts after 3 seconds
            const errorAlert = document.getElementById('alertError');
            if (errorAlert) {
                setTimeout(function() {
                    const alert = new bootstrap.Alert(errorAlert);
                    alert.close();
                }, 3000);
            }

            // Auto-dismiss any other alerts with class 'alert-auto-dismiss'
            const autoDismissAlerts = document.querySelectorAll('.alert-auto-dismiss:not(#alertSuccess):not(#alertError)');
            autoDismissAlerts.forEach(function(alert) {
                setTimeout(function() {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 3000);
            });
        });
    </script>

    @stack('scripts')
</body>
</html>
