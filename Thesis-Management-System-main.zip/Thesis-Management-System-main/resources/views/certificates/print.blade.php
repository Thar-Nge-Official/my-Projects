{{-- resources/views/certificates/print.blade.php --}}

@php
    $universityName = trim((string) ($appSettings->university_name ?? '')) ?: 'University of Yangon';
    $departmentName = trim((string) ($appSettings->department_name ?? '')) ?: 'Department of Computer Studies';
    $logoUrl = $appSettings->logo ? asset('storage/' . $appSettings->logo) : asset('images/cslogo.jpg');
@endphp

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Certificate of Completion</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Times New Roman', serif;
            background: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .certificate-card {
            background: #ffffff;
            border-radius: 16px;
            border: 4px solid #6c63ff;
            width: 100%;
            max-width: 1050px;
            padding: 30px 40px 25px;
            position: relative;
        }
        
        .certificate-content {
            text-align: center;
            position: relative;
        }
        
        /* ============================================ */
        /* LOGO - WITH VALID PATH */
        /* ============================================ */
        .uni-logo {
            width: 70px;
            height: 70px;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            overflow: hidden;
            border: 2px solid #6c63ff;
        }
        
        .uni-logo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .uni-name h2 {
            font-size: 18px;
            font-weight: 800;
            color: #1a1a2e;
            letter-spacing: 3px;
            margin: 0;
        }
        
        .uni-name p {
            font-size: 12px;
            color: #6c757d;
            margin: 0;
            font-weight: 500;
            letter-spacing: 1px;
        }
        
        .cert-title {
            margin: 16px 0 12px;
        }
        
        .cert-title h1 {
            font-family: 'Times New Roman', serif;
            font-size: 26px;
            font-weight: 900;
            color: #1a1a2e;
            letter-spacing: 3px;
            margin: 0;
        }
        
        .cert-line {
            width: 70px;
            height: 3px;
            background: linear-gradient(90deg, #6c63ff, #00d2ff);
            margin: 8px auto 0;
            border-radius: 2px;
        }
        
        .cert-body {
            padding: 5px 0;
        }
        
        .cert-body .text-muted {
            font-size: 14px;
            color: #6c757d !important;
            margin: 5px 0;
            font-weight: 400;
        }
        
        .student-name {
            font-family: 'Times New Roman', serif;
            font-size: 34px;
            font-weight: 900;
            color: #1a1a2e;
            letter-spacing: 2px;
            display: inline-block;
            border-bottom: 3px solid #6c63ff;
            padding-bottom: 3px;
        }
        .student-details {
            margin-top: 10px;
            font-size: 13px;
            color: #6c757d;
            font-weight: 500;
        }
        
        .thesis-title {
            font-size: 20px;
            font-weight: 700;
            color: #6c63ff;
            font-style: italic;
            margin: 0;
        }
        
        .cert-description {
            font-size: 13px;
            color: #6c757d;
            max-width: 600px;
            margin: 10px auto 0;
            line-height: 1.6;
        }
        
        .cert-meta {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
            padding: 12px 0;
            margin: 12px 0 16px;
            border-top: 2px solid #f0f0f0;
            border-bottom: 2px solid #f0f0f0;
            flex-wrap: wrap;
        }
        
        .meta-item {
            text-align: center;
        }
        
        .meta-label {
            display: block;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: #adb5bd;
            margin-bottom: 1px;
        }
        
        .meta-value {
            display: block;
            font-size: 14px;
            font-weight: 700;
            color: #1a1a2e;
        }
        
        .meta-divider {
            width: 1px;
            height: 30px;
            background: #e9ecef;
        }
        
        .cert-signatures {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            padding: 15px 20px 5px;
        }
        
        .signature {
            flex: 1;
        }
        
        .signature-left {
            text-align: left;
        }
        
        .signature-right {
            text-align: right;
        }
        
        .signature-line {
            width: 180px;
            height: 2px;
            background: #1a1a2e;
            margin: 0 0 6px 0;
        }
        
        .signature-right .signature-line {
            margin-left: auto;
            margin-right: 0;
        }
        
        .signature-label {
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #6c757d;
            margin-bottom: 2px;
        }
        
        .signature-name {
            font-size: 15px;
            font-weight: 700;
            color: #1a1a2e;
        }
        
        .signature-title {
            font-size: 11px;
            color: #6c757d;
            font-weight: 400;
        }
        
        .cert-footer {
            padding-top: 12px;
            margin-top: 6px;
            border-top: 1px solid #f0f0f0;
        }
        
        .cert-footer p {
            font-size: 10px;
            color: #adb5bd;
            margin: 1px 0;
            letter-spacing: 0.5px;
        }
        
        @media print {
            body {
                padding: 0;
            }
            .certificate-card {
                border: 3px solid #6c63ff;
                border-radius: 8px;
                padding: 20px 25px 15px;
                box-shadow: none;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="certificate-card">
        
        <div class="certificate-content">
            
            <!-- Logo -->
            <div class="uni-logo">
                <img src="{{ $logoUrl }}" alt="University Logo">
            </div>
            
            <!-- University Name -->
            <div class="uni-name">
                <h2>{{ strtoupper($universityName) }}</h2>
                <p>{{ $departmentName }}</p>
            </div>
            
            <!-- Certificate Title -->
            <div class="cert-title">
                <h1>CERTIFICATE OF COMPLETION</h1>
                <div class="cert-line"></div>
            </div>
            
            <!-- Certificate Body -->
            <div class="cert-body">
                <p class="text-muted">This certifies that</p>
                
                <div class="student-name">{{ $certificate->student->firstname }} {{ $certificate->student->lastname }}</div>
                <div class="student-details">
                    <span class="text-muted">Roll No: {{ $certificate->student->roll_no ?? 'N/A' }}</span>
                    <span class="text-muted mx-2">|</span>
                    <span class="text-muted">Class: {{ $certificate->student->class ?? 'N/A' }}</span>
                </div>
                
                <p class="text-muted">has successfully completed the thesis</p>
                
                <div class="thesis-title">"{{ $certificate->thesis->title }}"</div>
                
                <p class="cert-description">
                    {{ $certificate->description }}
                </p>
            </div>
            
            <!-- Certificate Meta -->
            <div class="cert-meta">
                <div class="meta-item">
                    <span class="meta-label">Certificate No.</span>
                    <span class="meta-value">{{ $certificate->certificate_number }}</span>
                </div>
                <div class="meta-divider"></div>
                <div class="meta-item">
                    <span class="meta-label">Issue Date</span>
                    <span class="meta-value">{{ $certificate->issued_at->format('d M, Y') }}</span>
                </div>
                <div class="meta-divider"></div>
                <div class="meta-item">
                    <span class="meta-label">Issued By</span>
                    <span class="meta-value">{{ $certificate->issuer->firstname ?? 'N/A' }} {{ $certificate->issuer->lastname ?? '' }}</span>
                </div>
            </div>
            
            <!-- Signatures - Left and Right -->
            <div class="cert-signatures">
                <div class="signature signature-left">
                    <div class="signature-line"></div>
                    <div class="signature-name fs-4">{{ $certificate->thesis->supervisor->firstname ?? 'N/A' }} {{ $certificate->thesis->supervisor->lastname ?? '' }}</div>
                    <div class="signature-title">Supervisor / Associate Professor</div>
                    <div class="signature-label">{{ $departmentName }}</div>
                    <div class="signature-label">{{ $universityName }}</div>
                </div>
                
                <div class="signature signature-right">
                    <div class="signature-line"></div>
                    <div class="signature-name fs-4">{{ $certificate->issuer->firstname ?? 'N/A' }} {{ $certificate->issuer->lastname ?? '' }}</div>
                    <div class="signature-title">Professor and Head</div>
                    <div class="signature-label">{{ $departmentName }}</div>
                    <div class="signature-label">{{ $universityName }}</div>
                </div>
            </div>
            
            <!-- Footer -->
            <div class="cert-footer">
                <p>This certificate is electronically generated and is valid without signature.</p>
                <p>&copy; {{ date('Y') }} {{ $universityName }}. All Rights Reserved.</p>
            </div>
            
        </div>
        
    </div>
    
    <script>
        window.onload = function() {
            window.print();
        }
    </script>
</body>
</html>
