{{-- resources/views/certificates/show.blade.php --}}

@extends('layouts.app')

@section('title', 'Certificate of Completion')

@section('content')
@php
    $universityName = trim((string) ($appSettings->university_name ?? '')) ?: 'University of Yangon';
    $departmentName = trim((string) ($appSettings->department_name ?? '')) ?: 'Department of Computer Studies';
@endphp
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <!-- Certificate Wrapper -->
            <div class="certificate-wrapper" id="certificate-wrapper">
                
                <!-- Certificate Card -->
                <div class="certificate-card" id="certificate-card">
                    
                    <!-- Main Content -->
                    <div class="certificate-content">
                        
                        <!-- Logo -->
                        <div class="uni-logo">
                            @php
                                $logoPath = $appSettings->logo
                                    ? public_path('storage/' . $appSettings->logo)
                                    : public_path('images/cslogo.jpg');
                                if (file_exists($logoPath)) {
                                    $imageData = base64_encode(file_get_contents($logoPath));
                                    $imageSrc = 'data:image/' . pathinfo($logoPath, PATHINFO_EXTENSION) . ';base64,' . $imageData;
                                } else {
                                    $imageSrc = asset('images/cslogo.jpg');
                                }
                            @endphp
                            <img src="{{ $imageSrc }}" alt="University Logo" 
                                 onerror="this.style.display='none'; this.parentElement.innerHTML='<div style=\'width:70px;height:70px;background:#6c63ff;border-radius:50%;display:flex;align-items:center;justify-content:center;color:white;font-size:28px;font-weight:bold;\'>UY</div>'">
                        </div>
                        
                        <!-- University Name -->
                        <div class="uni-name">
                            <h2>{{ strtoupper($universityName) }}</h2>
                            <p>{{ $departmentName }}</p>
                        </div>
                        
                        <!-- Certificate Title -->
                        <div class="cert-title">
                            <h1>CERTIFICATE OF COMPLETION</h1>
                            <div class="cert-line"></div>
                        </div>
                        
                        <!-- Certificate Body -->
                        <div class="cert-body">
                            <p class="text-muted">This certifies that</p>
                            
                            <div class="student-name">{{ $certificate->student->firstname }} {{ $certificate->student->lastname }}</div>
                            <div class="student-details">
                                <span class="text-muted">Roll No: {{ $certificate->student->roll_no ?? 'N/A' }}</span>
                                <span class="text-muted mx-2">|</span>
                                <span class="text-muted">Class: {{ $certificate->student->class ?? 'N/A' }}</span>
                            </div>
                        
                            <p class="text-muted">has successfully completed the thesis</p>
                            
                            <div class="thesis-title">"{{ $certificate->thesis->title }}"</div>
                            
                            <p class="cert-description">
                                {{ $certificate->description }}
                            </p>
                        </div>
                        
                        <!-- Certificate Meta -->
                        <div class="cert-meta">
                            <div class="meta-item">
                                <span class="meta-label">Certificate No.</span>
                                <span class="meta-value">{{ $certificate->certificate_number }}</span>
                            </div>
                            <div class="meta-divider"></div>
                            <div class="meta-item">
                                <span class="meta-label">Issue Date</span>
                                <span class="meta-value">{{ $certificate->issued_at->format('d M, Y') }}</span>
                            </div>
                            <div class="meta-divider"></div>
                            <div class="meta-item">
                                <span class="meta-label">Issued By</span>
                                <span class="meta-value">{{ $certificate->issuer->firstname ?? 'N/A' }} {{ $certificate->issuer->lastname ?? '' }}</span>
                            </div>
                        </div>
                        
                        <!-- Signatures - Left and Right -->
                        <div class="cert-signatures">
                            <div class="signature signature-left">
                                <div class="signature-line"></div>
                                <div class="signature-name fs-4">{{ $certificate->thesis->supervisor->firstname ?? 'N/A' }} {{ $certificate->thesis->supervisor->lastname ?? '' }}</div>
                                <div class="signature-title">Supervisor / Associate Professor</div>
                                <div class="signature-label">{{ $departmentName }}</div>
                                <div class="signature-label">{{ $universityName }}</div>
                            </div>
                            
                            <div class="signature signature-right">
                                <div class="signature-line"></div>
                                <div class="signature-name fs-4">{{ $certificate->issuer->firstname ?? 'N/A' }} {{ $certificate->issuer->lastname ?? '' }}</div>
                                <div class="signature-title">Professor and Head</div>
                                <div class="signature-label">{{ $departmentName }}</div>
                                <div class="signature-label">{{ $universityName }}</div>
                            </div>
                        </div>
                        
                        <!-- Footer -->
                        <div class="cert-footer">
                            <p>This certificate is electronically generated and is valid without signature.</p>
                            <p>&copy; {{ date('Y') }} {{ $universityName }}. All Rights Reserved.</p>
                        </div>
                        
                    </div>
                    
                </div>
                
                <!-- Action Buttons -->
                <div class="cert-actions">
                    <a href="{{ route('certificates.print', $certificate) }}" class="btn btn-print" target="_blank">
                        <i class="fas fa-print me-2"></i> Print Certificate
                    </a>
                    <a href="{{ route('theses.show', $certificate->thesis) }}" class="btn btn-back">
                        <i class="fas fa-arrow-left me-2"></i> Back to Thesis
                    </a>
                </div>
                
            </div>
        </div>
    </div>
</div>

<style>
    /* ============================================ */
    /* CERTIFICATE WRAPPER */
    /* ============================================ */
    .certificate-wrapper {
        padding: 30px 20px;
        animation: fadeUp 0.8s ease;
    }
    
    @keyframes fadeUp {
        from {
            opacity: 0;
            transform: translateY(40px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    /* ============================================ */
    /* CERTIFICATE CARD */
    /* ============================================ */
    .certificate-card {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 30px 80px rgba(0, 0, 0, 0.08);
        overflow: hidden;
        position: relative;
        border: 4px solid #6c63ff;
    }
    
    /* ============================================ */
    /* CERTIFICATE CONTENT */
    /* ============================================ */
    .certificate-content {
        padding: 40px 50px 30px;
        text-align: center;
        position: relative;
    }
    
    /* ============================================ */
    /* LOGO */
    /* ============================================ */
    .uni-logo {
        width: 80px;
        height: 80px;
        margin: 0 auto 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        overflow: hidden;
        border: 3px solid #6c63ff;
        background: #ffffff;
    }
    
    .uni-logo img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    /* ============================================ */
    /* UNIVERSITY NAME */
    /* ============================================ */
    .uni-name h2 {
        font-size: 18px;
        font-weight: 800;
        color: #1a1a2e;
        letter-spacing: 3px;
        margin: 0;
    }
    
    .uni-name p {
        font-size: 12px;
        color: #6c757d;
        margin: 0;
        font-weight: 500;
        letter-spacing: 1px;
    }
    
    /* ============================================ */
    /* CERTIFICATE TITLE */
    /* ============================================ */
    .cert-title {
        margin: 16px 0 12px;
    }
    
    .cert-title h1 {
        font-family: 'Times New Roman', serif;
        font-size: 26px;
        font-weight: 900;
        color: #1a1a2e;
        letter-spacing: 3px;
        margin: 0;
    }
    
    .cert-line {
        width: 70px;
        height: 3px;
        background: linear-gradient(90deg, #6c63ff, #00d2ff);
        margin: 8px auto 0;
        border-radius: 2px;
    }
    
    /* ============================================ */
    /* CERTIFICATE BODY */
    /* ============================================ */
    .cert-body {
        padding: 5px 0;
    }
    
    .cert-body .text-muted {
        font-size: 14px;
        color: #6c757d !important;
        margin: 5px 0;
        font-weight: 400;
    }
    
    .student-name {
        font-family: 'Times New Roman', serif;
        font-size: 34px;
        font-weight: 900;
        color: #1a1a2e;
        letter-spacing: 2px;
        display: inline-block;
        border-bottom: 3px solid #6c63ff;
        padding-bottom: 3px;
    }
    .student-details {
        margin-top: 10px;
        font-size: 13px;
        color: #6c757d;
        font-weight: 500;
    }
    
    .thesis-title {
        font-size: 20px;
        font-weight: 700;
        color: #6c63ff;
        font-style: italic;
        margin: 0;
    }
    
    .cert-description {
        font-size: 13px;
        color: #6c757d;
        max-width: 600px;
        margin: 10px auto 0;
        line-height: 1.6;
    }
    
    /* ============================================ */
    /* CERTIFICATE META */
    /* ============================================ */
    .cert-meta {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 20px;
        padding: 12px 0;
        margin: 12px 0 16px;
        border-top: 2px solid #f0f0f0;
        border-bottom: 2px solid #f0f0f0;
        flex-wrap: wrap;
    }
    
    .meta-item {
        text-align: center;
    }
    
    .meta-label {
        display: block;
        font-size: 10px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: #adb5bd;
        margin-bottom: 1px;
    }
    
    .meta-value {
        display: block;
        font-size: 14px;
        font-weight: 700;
        color: #1a1a2e;
    }
    
    .meta-divider {
        width: 1px;
        height: 30px;
        background: #e9ecef;
    }
    
    /* ============================================ */
    /* SIGNATURES - LEFT AND RIGHT */
    /* ============================================ */
    .cert-signatures {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        padding: 15px 20px 5px;
    }
    
    .signature {
        flex: 1;
    }
    
    .signature-left {
        text-align: left;
    }
    
    .signature-right {
        text-align: right;
    }
    
    .signature-line {
        width: 180px;
        height: 2px;
        background: #1a1a2e;
        margin: 0 0 6px 0;
    }
    
    .signature-right .signature-line {
        margin-left: auto;
        margin-right: 0;
    }
    
    .signature-label {
        font-size: 10px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: #6c757d;
        margin-bottom: 2px;
    }
    
    .signature-name {
        font-size: 15px;
        font-weight: 700;
        color: #1a1a2e;
    }
    
    .signature-title {
        font-size: 11px;
        color: #6c757d;
        font-weight: 400;
    }
    
    /* ============================================ */
    /* FOOTER */
    /* ============================================ */
    .cert-footer {
        padding-top: 12px;
        margin-top: 6px;
        border-top: 1px solid #f0f0f0;
    }
    
    .cert-footer p {
        font-size: 10px;
        color: #adb5bd;
        margin: 1px 0;
        letter-spacing: 0.5px;
    }
    
    /* ============================================ */
    /* ACTION BUTTONS */
    /* ============================================ */
    .cert-actions {
        display: flex;
        gap: 12px;
        justify-content: center;
        margin-top: 30px;
        flex-wrap: wrap;
    }
    
    .cert-actions .btn {
        font-weight: 600;
        font-size: 14px;
        padding: 12px 28px;
        border-radius: 50px;
        transition: all 0.3s ease;
        font-family: 'Inter', sans-serif;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: none;
        cursor: pointer;
    }
    
    .btn-download {
        background: linear-gradient(135deg, #6c63ff, #5a52d5);
        color: #ffffff;
        box-shadow: 0 4px 20px rgba(108, 99, 255, 0.3);
    }
    
    .btn-download:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 35px rgba(108, 99, 255, 0.4);
        color: #ffffff;
    }
    
    .btn-print {
        background: #ffffff;
        color: #1a1a2e;
        border: 2px solid #e9ecef;
    }
    
    .btn-print:hover {
        background: #f8f9fa;
        border-color: #adb5bd;
        transform: translateY(-2px);
    }
    
    .btn-back {
        background: transparent;
        color: #6c757d;
        border: 2px solid #e9ecef;
    }
    
    .btn-back:hover {
        background: #f8f9fa;
        border-color: #adb5bd;
        transform: translateY(-2px);
        color: #6c757d;
    }
    
    /* ============================================ */
    /* RESPONSIVE */
    /* ============================================ */
    @media (max-width: 992px) {
        .certificate-content {
            padding: 30px 25px 20px;
        }
    }
    
    @media (max-width: 768px) {
        .certificate-content {
            padding: 20px 15px 15px;
        }
        
        .cert-title h1 {
            font-size: 20px;
        }
        
        .student-name {
            font-size: 28px;
        }
        
        .thesis-title {
            font-size: 18px;
        }
        
        .cert-meta {
            flex-direction: column;
            gap: 8px;
        }
        
        .meta-divider {
            display: none;
        }
        
        .cert-signatures {
            flex-direction: column;
            align-items: center !important;
            gap: 25px;
            padding: 10px 0;
        }
        
        .signature-left,
        .signature-right {
            text-align: center !important;
        }
        
        .signature-left .signature-line,
        .signature-right .signature-line {
            margin: 0 auto !important;
        }
        
        .uni-logo {
            width: 60px;
            height: 60px;
        }
        
        .uni-name h2 {
            font-size: 16px;
        }
        
        .cert-actions {
            flex-direction: column;
            align-items: center;
        }
        
        .cert-actions .btn {
            width: 100%;
            justify-content: center;
        }
    }
    
    @media (max-width: 576px) {
        .certificate-content {
            padding: 15px 10px 10px;
        }
        
        .cert-title h1 {
            font-size: 18px;
        }
        
        .student-name {
            font-size: 24px;
        }
        
        .thesis-title {
            font-size: 16px;
        }
        
        .cert-description {
            font-size: 12px;
        }
    }
    
    /* ============================================ */
    /* PRINT STYLES */
    /* ============================================ */
    @media print {
        .cert-actions {
            display: none !important;
        }
        
        .certificate-wrapper {
            padding: 0 !important;
            animation: none !important;
        }
        
        .certificate-card {
            box-shadow: none !important;
            border: 3px solid #6c63ff !important;
            border-radius: 12px !important;
        }
        
        .certificate-content {
            padding: 30px 35px 20px !important;
        }
        
        /* Hide navbar and footer */
        .navbar,
        footer,
        .cert-actions {
            display: none !important;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Any additional JavaScript if needed
    });
</script>
@endsection
