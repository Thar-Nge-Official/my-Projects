{{-- resources/views/chapters/show.blade.php --}}

@extends('layouts.app')

@section('title', $chapter->chapter_title)

@section('content')
<div class="container-fluid">
    <!-- ============================================ -->
    <!-- PAGE HEADER -->
    <!-- ============================================ -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex flex-wrap flex-md-nowrap justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <a href="{{ route('theses.show', $chapter->thesis) }}" class="btn btn-light btn-sm rounded-circle shadow-sm" style="width: 42px; height: 42px; padding: 0;">
                        <i class="fas fa-arrow-left text-primary"></i>
                    </a>
                    <div>
                        <h3 class="fw-bold mb-0 text-dark">Chapter {{ $chapter->chapter_number }}: {{ $chapter->chapter_title }}</h3>
                        <div class="d-flex flex-wrap align-items-center gap-2 mt-1">
                            <span class="badge bg-{{ $chapter->status_color }} px-3 py-2 rounded-pill">
                                <i class="fas fa-circle me-1" style="font-size: 8px;"></i>
                                {{ $chapter->status_label }}
                            </span>
                            <span class="text-muted">•</span>
                            <span class="text-muted small">Thesis: {{ Str::limit($chapter->thesis->title, 30) }}</span>
                        </div>
                    </div>
                </div>
                <div class="mt-2 mt-md-0">
                    @if($chapter->status == 'draft')
                        <span class="badge bg-secondary bg-gradient px-4 py-2 rounded-pill shadow-sm">
                            <i class="fas fa-pencil-alt me-1"></i> Draft
                        </span>
                    @elseif($chapter->status == 'submitted')
                        <span class="badge bg-warning bg-gradient px-4 py-2 rounded-pill shadow-sm">
                            <i class="fas fa-clock me-1"></i> Pending Review
                        </span>
                    @elseif($chapter->status == 'supervisor_approved')
                        <span class="badge bg-info bg-gradient px-4 py-2 rounded-pill shadow-sm">
                            <i class="fas fa-user-check me-1"></i> Supervisor Approved
                        </span>
                    @elseif(in_array($chapter->status, ['admin_approved', 'approved']))
                        <span class="badge bg-success bg-gradient px-4 py-2 rounded-pill shadow-sm">
                            <i class="fas fa-check-circle me-1"></i> Admin Approved
                        </span>
                    @elseif($chapter->status == 'revision')
                        <span class="badge bg-danger bg-gradient px-4 py-2 rounded-pill shadow-sm">
                            <i class="fas fa-pen-fancy me-1"></i> Revision Required
                        </span>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- MAIN CONTENT -->
    <!-- ============================================ -->
    <div class="row g-4">
        <div class="col-lg-8">
            <!-- Chapter Content -->
            <div class="card shadow-sm border-0 rounded-4 mb-4">
                <div class="card-body p-4">
                    <div class="chapter-content">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-align-left text-primary me-2"></i>Content
                        </h5>
                        <div class="content-box p-4 bg-light rounded-3">
                            @php
                                $sections = json_decode($chapter->content, true);
                                $rawContent = $chapter->content;
                            @endphp
                        
                            @if($sections && is_array($sections) && count($sections) > 0)
                                <div class="nested-sections">
                                    @php
                                        // Build nested structure
                                        $tree = [];
                                        
                                        foreach ($sections as $section) {
                                            $level = $section['level'] ?? 1;
                                            $number = $section['number'] ?? '';
                                            $title = $section['title'] ?? '';
                                            $paragraphs = $section['paragraphs'] ?? null;
                                            $content = $section['content'] ?? '';
                                            $image = $section['image'] ?? '';
                                            $caption = $section['caption'] ?? '';

                                            // Normalize paragraphs: if content exists but paragraphs not set, use content as single paragraph
                                            if (is_null($paragraphs)) {
                                                if (!empty($content)) {
                                                    $paragraphs = [$content];
                                                } else {
                                                    $paragraphs = [];
                                                }
                                            } elseif (is_string($paragraphs)) {
                                                $paragraphs = [$paragraphs];
                                            }
                                             
                                            $node = [
                                                'number' => $number,
                                                'title' => $title,
                                                'paragraphs' => $paragraphs,
                                                'content' => $content,
                                                'image' => $image,
                                                'caption' => $caption,
                                                'level' => $level,
                                                'children' => []
                                            ];
                                            
                                            if ($level == 1) {
                                                $tree[] = $node;
                                            } else {
                                                // Find parent - go to last item at each level
                                                $parent = &$tree[count($tree) - 1];
                                                for ($i = 2; $i < $level; $i++) {
                                                    if (isset($parent['children']) && count($parent['children']) > 0) {
                                                        $parent = &$parent['children'][count($parent['children']) - 1];
                                                    }
                                                }
                                                $parent['children'][] = $node;
                                            }
                                        }
                                    @endphp
                                    
                                    {{-- Render tree recursively using a function --}}
                                    @php
                                        // Small CSS tweak for nicer paragraph rendering and image handling
                                        echo '<style>
                                            .section-node .section-content { background: #fbfcfd; border-radius: 8px; padding: 18px; }
                                            .section-node .section-number { min-width: 56px; font-weight:700; color:#0d6efd; }
                                            .section-text { max-width: 920px; }
                                            .section-title { font-weight:600; margin-bottom:8px; font-size:16px; }
                                            .section-paragraphs { margin-top:6px; }
                                            .section-body { color:#525f7f; font-size:15px; line-height:1.7; margin-bottom:12px; }
                                            .section-image img { max-width:100%; height:auto; display:block; margin-top:10px; border-radius:6px; }
                                            .content-box { background: #f8fafc; }
                                        </style>';

                                        function renderTree($nodes, $level = 1) {
                                            $html = '';
                                            foreach ($nodes as $node) {
                                                $number = $node['number'] ?? '';
                                                $title = $node['title'] ?? '';
                                                $paragraphs = $node['paragraphs'] ?? [];
                                                $children = $node['children'] ?? [];
                                                $image = $node['image'] ?? '';
                                                $caption = $node['caption'] ?? '';
                                              
                                                $html .= '<div class="section-node" data-level="' . $level . '">';
                                                $html .= '<div class="section-content d-flex">';
                                                $html .= '<span class="section-number me-3">' . e($number) . '</span>';
                                                $html .= '<div class="section-text">';
                                                if (!empty($title)) {
                                                    $html .= '<div class="section-title">' . e($title) . '</div>';
                                                }

                                                // Paragraphs block
                                                if (!empty($paragraphs) && is_array($paragraphs)) {
                                                    $html .= '<div class="section-paragraphs">';
                                                    foreach ($paragraphs as $paragraph) {
                                                        if (!empty($paragraph)) {
                                                            $html .= '<p class="section-body">' . e($paragraph) . '</p>';
                                                        }
                                                    }
                                                    $html .= '</div>';
                                                } elseif (!empty($node['content'])) {
                                                    $html .= '<div class="section-paragraphs"><p class="section-body">' . e($node['content']) . '</p></div>';
                                                }

                                                // Image handling - build URL with encoded path segments so filenames with spaces work
                                                if (!empty($image)) {
                                                    try {
                                                        $parts = explode('/', ltrim($image, '/'));
                                                        $encoded = implode('/', array_map('rawurlencode', $parts));
                                                        // Use relative URL to avoid host mismatch (asset() may use APP_URL)
                                                        $imgUrl = '/' . ltrim('storage/' . $encoded, '/');
                                                    } catch (\Exception $e) {
                                                        $imgUrl = '/storage/' . str_replace(' ', '%20', ltrim($image, '/'));
                                                    }
                                                    $html .= '<div class="section-image"><img src="' . e($imgUrl) . '" alt="Section image" /></div>';
                                                    if (!empty($caption)) {
                                                        $html .= '<div class="section-image-caption text-muted small fst-italic mt-2">' . e($caption) . '</div>';
                                                    }
                                                }

                                                $html .= '</div>'; // section-text
                                                $html .= '</div>'; // section-content
                                                 
                                                if (!empty($children)) {
                                                    $html .= '<div class="children mt-3">';
                                                    $html .= renderTree($children, $level + 1);
                                                    $html .= '</div>';
                                                }
                                                 
                                                $html .= '</div>';
                                            }
                                            return $html;
                                        }
                                    @endphp
                                    
                                    {!! renderTree($tree) !!}
                                </div>
                            @else
                                @if(!empty($rawContent))
                                    <div class="text-muted py-3">{!! nl2br(e($rawContent)) !!}</div>
                                @else
                                    <p class="text-muted text-center py-3">No content added yet.</p>
                                @endif
                            @endif
                        </div>
                    </div>

                    @if($chapter->file_path)
                        <div class="mt-4">
                            <h5 class="fw-bold mb-3">
                                <i class="fas fa-paperclip text-primary me-2"></i>Attached File
                            </h5>
                            <div class="d-flex align-items-center gap-3 p-3 bg-light rounded-3">
                                <div class="file-icon bg-primary bg-opacity-10 p-3 rounded-3">
                                    <i class="fas fa-file-pdf text-danger" style="font-size: 24px;"></i>
                                </div>
                                <div>
                                    <strong>{{ basename($chapter->file_path) }}</strong>
                                    <br>
                                    <small class="text-muted">
                                        <i class="far fa-file me-1"></i>
                                        @php
                                            $fileSize = Storage::disk('public')->size($chapter->file_path);
                                            $fileSizeFormatted = number_format($fileSize / 1024, 2) . ' KB';
                                        @endphp
                                        {{ $fileSizeFormatted }}
                                    </small>
                                </div>
                                <div class="ms-auto">
                                    <a href="{{ asset('storage/' . $chapter->file_path) }}" target="_blank" class="btn btn-primary rounded-pill">
                                        <i class="fas fa-download me-2"></i>Download File
                                    </a>
                                </div>
                            </div>
                        </div>
                    @endif

                    <!-- Chapter Info -->
                    <div class="mt-4 pt-3 border-top">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <div class="info-item">
                                    <small class="text-muted d-block">
                                        <i class="far fa-calendar-plus me-1"></i>Created
                                    </small>
                                    <span class="fw-semibold">{{ $chapter->created_at->format('d M, Y H:i') }}</span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="info-item">
                                    <small class="text-muted d-block">
                                        <i class="far fa-calendar-edit me-1"></i>Last Updated
                                    </small>
                                    <span class="fw-semibold">{{ $chapter->updated_at->format('d M, Y H:i') }}</span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="info-item">
                                    <small class="text-muted d-block">
                                        <i class="fas fa-file-word me-1"></i>Word Count
                                    </small>
                                    <span class="fw-semibold">{{ $chapter->word_count ?? 0 }} words</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    @if($chapter->revision_feedback)
                        <div class="alert alert-warning border-0 rounded-3 mt-4">
                            <div class="d-flex align-items-start gap-2">
                                <i class="fas fa-pen-fancy mt-1" style="font-size: 20px;"></i>
                                <div>
                                    <strong>Revision Feedback:</strong>
                                    <p class="mb-0 mt-1">{{ $chapter->revision_feedback }}</p>
                                </div>
                            </div>
                        </div>
                    @endif

                    @if($chapter->approved_by)
                        <div class="alert alert-success border-0 rounded-3 mt-4">
                            <div class="d-flex align-items-start gap-2">
                                <i class="fas fa-check-circle mt-1" style="font-size: 20px;"></i>
                                <div>
                                    <strong>Approved by:</strong>
                                    {{ $chapter->approver->firstname ?? 'N/A' }} {{ $chapter->approver->lastname ?? '' }}
                                    <br>
                                    <small class="text-muted">
                                        <i class="far fa-calendar-check me-1"></i>
                                        Approved on: {{ $chapter->approved_at ? $chapter->approved_at->format('d M, Y H:i') : 'N/A' }}
                                    </small>
                                </div>
                            </div>
                        </div>
                    @endif

                    @if($chapter->submitted_at)
                        <div class="alert alert-info border-0 rounded-3 mt-4">
                            <div class="d-flex align-items-start gap-2">
                                <i class="fas fa-paper-plane mt-1" style="font-size: 20px;"></i>
                                <div>
                                    <strong>Submitted for Review:</strong>
                                    <br>
                                    <small class="text-muted">
                                        <i class="far fa-calendar me-1"></i>
                                        Submitted on: {{ $chapter->submitted_at->format('d M, Y H:i') }}
                                    </small>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- ============================================ -->
        <!-- SIDEBAR -->
        <!-- ============================================ -->
        <div class="col-lg-4">
            <!-- ============================================ -->
            <!-- STUDENT ACTIONS -->
            <!-- ============================================ -->
            @if(Auth::user()->isStudent() && $chapter->thesis->student_id == Auth::id())
                @if($chapter->status == 'draft' || $chapter->status == 'revision')
                    <div class="card shadow-sm border-0 rounded-4 mb-4">
                        <div class="card-header bg-transparent border-0 p-4 pb-0">
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-warning bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-pen-to-square text-warning"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Chapter Actions</h6>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <div class="d-grid gap-2">
                                <a href="{{ route('chapters.edit', $chapter) }}" class="btn btn-outline-primary rounded-pill py-2">
                                    <i class="fas fa-edit me-2"></i>Edit Chapter
                                </a>
                                @if($chapter->status == 'draft')
                                    <form action="{{ route('chapters.destroy', $chapter) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-outline-danger rounded-pill py-2 w-100" onclick="return confirm('Are you sure you want to delete this chapter?')">
                                            <i class="fas fa-trash me-2"></i>Delete Chapter
                                        </button>
                                    </form>
                                    <hr>
                                    @if(empty($chapter->content) && empty($chapter->file_path))
                                        <div class="alert alert-warning border-0 rounded-3 mb-0">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Please add content or upload a file before submitting.
                                        </div>
                                    @else
                                        <form action="{{ route('chapters.submit', $chapter) }}" method="POST">
                                            @csrf
                                            <button type="submit" class="btn btn-success rounded-pill py-2 w-100" onclick="return confirm('Are you sure you want to submit this chapter for review?')">
                                                <i class="fas fa-paper-plane me-2"></i>Submit for Review
                                            </button>
                                        </form>
                                    @endif
                                @elseif($chapter->status == 'revision')
                                    <div class="alert alert-info border-0 rounded-3 mb-0">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Please revise the chapter based on feedback and submit again.
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                @else
                    <div class="card shadow-sm border-0 rounded-4 mb-4">
                        <div class="card-header bg-transparent border-0 p-4 pb-0">
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-secondary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-lock text-secondary"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Chapter Locked</h6>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <div class="alert alert-secondary border-0 rounded-3 mb-0">
                                <i class="fas fa-info-circle me-1"></i>
                                This chapter is <strong>{{ strtolower($chapter->status_label) }}</strong> and cannot be edited.
                                @if($chapter->status == 'submitted')
                                    <br>
                                    <small class="text-muted">Waiting for supervisor review.</small>
                                @elseif($chapter->status == 'supervisor_approved')
                                    <br>
                                    <small class="text-muted">Waiting for admin review.</small>
                                @elseif(in_array($chapter->status, ['admin_approved', 'approved']))
                                    <br>
                                    <small class="text-muted">Final approval completed.</small>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif
            @endif

            <!-- ============================================ -->
            <!-- SUPERVISOR REVIEW ACTIONS -->
            <!-- ============================================ -->
            @if(Auth::user()->isSupervisor() && $chapter->thesis->supervisor_id == Auth::id())
                @if($chapter->status == 'submitted')
                    <div class="card shadow-sm border-0 rounded-4 mb-4">
                        <div class="card-header bg-transparent border-0 p-4 pb-0">
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-warning bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-user-check text-warning"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Supervisor Review</h6>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <!-- Supervisor Approve -->
                            <form action="{{ route('chapters.approve-supervisor', $chapter) }}" method="POST" class="mb-3">
                                @csrf
                                <div class="mb-2">
                                    <textarea name="feedback" class="form-control form-control-sm rounded-3" placeholder="Approval feedback..." rows="2" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-success rounded-pill py-2 w-100" onclick="return confirm('Approve this chapter? It will be sent to admin for final review.')">
                                    <i class="fas fa-check me-2"></i>Approve & Send to Admin
                                </button>
                                <small class="text-muted d-block mt-1 text-center">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Chapter will be sent to admin for final approval
                                </small>
                            </form>
                            
                            <!-- Supervisor Reject -->
                            <form action="{{ route('chapters.reject-supervisor', $chapter) }}" method="POST">
                                @csrf
                                <div class="mb-2">
                                    <textarea name="feedback" class="form-control form-control-sm rounded-3" placeholder="Revision feedback..." rows="2" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-danger rounded-pill py-2 w-100" onclick="return confirm('Reject this chapter? Student will need to revise.')">
                                    <i class="fas fa-times me-2"></i>Reject & Request Revision
                                </button>
                            </form>
                        </div>
                    </div>
                @endif
            @endif

            <!-- ============================================ -->
            <!-- ADMIN REVIEW ACTIONS -->
            <!-- ============================================ -->
            @if(Auth::user()->isAdmin())
                @if(in_array($chapter->status, ['supervisor_approved', 'approved']) && $chapter->approved_by != Auth::id())
                    <div class="card shadow-sm border-0 rounded-4 mb-4">
                        <div class="card-header bg-transparent border-0 p-4 pb-0">
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-primary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-user-shield text-primary"></i>
                                </div>
                                <h6 class="fw-bold mb-0">Admin Review</h6>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <!-- Admin Approve -->
                            <form action="{{ route('chapters.approve-admin', $chapter) }}" method="POST" class="mb-3">
                                @csrf
                                <div class="mb-2">
                                    <textarea name="feedback" class="form-control form-control-sm rounded-3" placeholder="Approval feedback..." rows="2" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-success rounded-pill py-2 w-100" onclick="return confirm('Approve this chapter?')">
                                    <i class="fas fa-check me-2"></i>Final Approve
                                </button>
                            </form>
                            
                            <!-- Admin Reject -->
                            <form action="{{ route('chapters.reject-admin', $chapter) }}" method="POST">
                                @csrf
                                <div class="mb-2">
                                    <textarea name="feedback" class="form-control form-control-sm rounded-3" placeholder="Revision feedback..." rows="2" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-danger rounded-pill py-2 w-100" onclick="return confirm('Reject this chapter? Student will need to revise.')">
                                    <i class="fas fa-times me-2"></i>Reject & Request Revision
                                </button>
                            </form>
                        </div>
                    </div>
                @endif
            @endif

            @if(in_array($chapter->status, ['admin_approved', 'approved']) && $chapter->thesis->status == 'approved')
                <div class="card shadow-sm border-0 rounded-4 mb-4">
                    <div class="card-body p-4">
                        <div class="d-grid gap-2">
                            <a href="{{ route('chapters.download-pdf', $chapter) }}" class="btn btn-success rounded-pill py-2">
                                <i class="fas fa-file-pdf me-2"></i>Download Completed Chapter PDF
                            </a>
                        </div>
                    </div>
                </div>
            @endif

            <!-- ============================================ -->
            <!-- FEEDBACK BUTTON -->
            <!-- ============================================ -->
            @if(isset($canViewFeedbacks) && $canViewFeedbacks && isset($feedbacks) && $feedbacks->count() > 0)
                <div class="card shadow-sm border-0 rounded-4 mb-4">
                    <div class="card-body p-4 d-flex flex-column gap-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-warning bg-opacity-10 p-2 rounded-3">
                                <i class="fas fa-comment text-warning"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-1">Chapter Feedback</h6>
                                <p class="mb-0 text-muted">Click the button below to view all feedback in a popup modal.</p>
                            </div>
                        </div>
                        <button id="view-feedbacks-btn" type="button" class="btn btn-outline-primary rounded-pill py-2">
                            <i class="fas fa-eye me-2"></i>View Feedbacks ({{ $feedbacks->count() }})
                        </button>
                    </div>
                </div>
            @endif

            <!-- ============================================ -->
            <!-- CHAPTER INFO -->
            <!-- ============================================ -->
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-header bg-transparent border-0 p-4 pb-0">
                    <div class="d-flex align-items-center gap-2">
                        <div class="bg-info bg-opacity-10 p-2 rounded-3">
                            <i class="fas fa-info-circle text-info"></i>
                        </div>
                        <h6 class="fw-bold mb-0">Chapter Information</h6>
                    </div>
                </div>
                <div class="card-body p-4">
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Status</span>
                        <span class="badge bg-{{ $chapter->status_color }} rounded-pill px-3 py-2">
                            {{ $chapter->status_label }}
                        </span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Chapter #</span>
                        <span class="fw-semibold">{{ $chapter->chapter_number }}</span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Thesis</span>
                        <span class="fw-semibold text-truncate" style="max-width: 150px;">{{ Str::limit($chapter->thesis->title, 20) }}</span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Created</span>
                        <span class="fw-semibold">{{ $chapter->created_at->format('d M, Y') }}</span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2">
                        <span class="text-muted">Word Count</span>
                        <span class="fw-semibold">{{ $chapter->word_count ?? 0 }}</span>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

@if(isset($canViewFeedbacks) && $canViewFeedbacks && isset($feedbacks) && $feedbacks->count() > 0)
    <div id="feedback-modal" class="feedback-modal">
        <div class="feedback-modal-dialog">
            <div class="feedback-modal-header d-flex align-items-center justify-content-between">
                <div>
                    <h5 class="mb-1">Feedback for Chapter {{ $chapter->chapter_number }}</h5>
                    <small class="text-muted">Total feedback entries: {{ $feedbacks->count() }}</small>
                </div>
                <button type="button" id="close-feedback-modal" class="btn btn-sm btn-outline-secondary" aria-label="Close feedback modal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="feedback-modal-body">
                @foreach($feedbacks as $feedback)
                    <div class="feedback-item p-3 bg-light rounded-3 mb-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="d-flex align-items-center gap-2">
                                <div class="avatar rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 36px; height: 36px; font-size: 14px; font-weight: 600;">
                                    {{ strtoupper(substr($feedback->user->firstname ?? 'N/A', 0, 1)) }}
                                </div>
                                <div>
                                    <strong class="d-block">{{ $feedback->user->firstname ?? 'N/A' }}</strong>
                                    <small class="text-muted">{{ $feedback->created_at->format('d M, Y H:i') }}</small>
                                </div>
                            </div>
                            @if($feedback->rating)
                                <div class="text-warning">
                                    @for($i = 1; $i <= 5; $i++)
                                        <i class="fas fa-star{{ $i <= $feedback->rating ? '' : '-o' }}" style="font-size: 12px;"></i>
                                    @endfor
                                </div>
                            @endif
                        </div>
                        <p class="mt-2 mb-0">{{ $feedback->feedback }}</p>
                        <span class="badge bg-secondary bg-opacity-10 text-secondary mt-1">{{ ucfirst($feedback->type) }}</span>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endif

<!-- ============================================ -->
<!-- CUSTOM STYLES -->
<!-- ============================================ -->
<style>
    .content-box {
        border-left: 4px solid #0d6efd;
        background: #f8f9fa !important;
        min-height: 50px;
        border-radius: 8px;
    }

    /* Nested Section Styles */
    .nested-sections {
        font-family: 'Inter', sans-serif;
    }

    .section-node {
        position: relative;
        padding: 6px 0;
        border-bottom: 1px solid rgba(0, 0, 0, 0.04);
    }

    .section-node:last-child {
        border-bottom: none;
    }

    .section-node .section-content {
        display: flex;
        align-items: flex-start;
        gap: 16px;
        padding: 4px 0;
        transition: all 0.2s ease;
    }

    .section-node .section-content:hover {
        background: rgba(13, 110, 253, 0.04);
        border-radius: 6px;
        padding: 4px 8px;
        margin: 0 -8px;
    }

    .section-node .section-number {
        font-weight: 700;
        font-size: 14px;
        color: #0d6efd;
        min-width: 55px;
        flex-shrink: 0;
        padding-top: 2px;
    }

    /* Level 1 - Blue */
    .section-node[data-level="1"] > .section-content .section-number {
        color: #0d6efd;
        font-size: 15px;
        font-weight: 800;
    }

    .section-node[data-level="1"] > .section-content .section-title {
        font-size: 16px;
        font-weight: 700;
        color: #1a1a2e;
    }

    /* Level 2 - Green */
    .section-node[data-level="2"] > .section-content .section-number {
        color: #198754;
        font-size: 14px;
        font-weight: 700;
    }

    .section-node[data-level="2"] > .section-content .section-title {
        font-size: 15px;
        font-weight: 600;
        color: #2d3436;
    }

    /* Level 3 - Orange */
    .section-node[data-level="3"] > .section-content .section-number {
        color: #fd7e14;
        font-size: 13px;
        font-weight: 700;
    }

    .section-node[data-level="3"] > .section-content .section-title {
        font-size: 14px;
        font-weight: 600;
        color: #2d3436;
    }

    /* Level 4 - Purple */
    .section-node[data-level="4"] > .section-content .section-number {
        color: #6f42c1;
        font-size: 13px;
        font-weight: 700;
    }

    .section-node[data-level="4"] > .section-content .section-title {
        font-size: 14px;
        font-weight: 500;
        color: #2d3436;
    }

    /* Children container */
    .section-node .children {
        margin-left: 30px;
        padding-left: 20px;
        border-left: 2px solid rgba(13, 110, 253, 0.1);
        position: relative;
    }

    .section-node .children::before {
        content: '';
        position: absolute;
        left: -2px;
        top: 0;
        bottom: 0;
        width: 2px;
        background: linear-gradient(to bottom, #0d6efd, #198754, #fd7e14);
        opacity: 0.3;
        border-radius: 2px;
    }

    /* Connector dots */
    .section-node .children .section-node:first-child::after {
        content: '';
        position: absolute;
        left: -6px;
        top: 16px;
        width: 10px;
        height: 2px;
        background: rgba(13, 110, 253, 0.2);
    }

    .section-node .children .section-node:last-child::after {
        content: '';
        position: absolute;
        left: -6px;
        bottom: 50%;
        width: 10px;
        height: 2px;
        background: rgba(13, 110, 253, 0.2);
    }

    .section-node .section-text {
        flex: 1;
    }

    .section-node .section-title {
        font-weight: 600;
        margin-bottom: 2px;
    }

    .section-node .section-body {
        font-size: 14px;
        color: #6c757d;
        margin-bottom: 0;
        line-height: 1.6;
    }

    .section-node .children .section-node:hover > .section-content {
        background: rgba(13, 110, 253, 0.03);
        border-radius: 6px;
    }

    .info-row {
        padding: 10px 0;
    }

    .info-row:last-child {
        border-bottom: none !important;
    }

    .btn-outline-danger:hover {
        background: #dc3545;
        color: white;
    }

    .file-icon {
        width: 60px;
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .card-header {
        padding-bottom: 0 !important;
    }

    .info-item {
        background: #f8f9fa;
        padding: 10px 15px;
        border-radius: 8px;
    }

    .avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        font-weight: 600;
        flex-shrink: 0;
        background: #0d6efd !important;
        color: white !important;
    }

    .feedback-item:last-child {
        margin-bottom: 0 !important;
    }

    .feedback-modal {
        display: none;
        position: fixed;
        inset: 0;
        z-index: 1050;
        background: rgba(33, 37, 41, 0.65);
        align-items: center;
        justify-content: center;
        padding: 24px;
        overflow-y: auto;
    }

    .feedback-modal.show {
        display: flex;
    }

    .feedback-modal-dialog {
        width: 100%;
        max-width: 760px;
        background: #ffffff;
        border-radius: 18px;
        overflow: hidden;
        box-shadow: 0 30px 80px rgba(0, 0, 0, 0.18);
        animation: fadeInUp 0.25s ease-out;
    }

    .feedback-modal-header {
        padding: 22px 24px;
        border-bottom: 1px solid #e9ecef;
    }

    .feedback-modal-body {
        padding: 22px 24px 26px;
        max-height: calc(100vh - 190px);
        overflow-y: auto;
    }

    .feedback-modal-body .feedback-item {
        border: 1px solid #e9ecef;
    }

    .feedback-modal .btn-outline-secondary {
        min-width: 42px;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(12px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Responsive */
    @media (max-width: 768px) {
        .section-node .children {
            margin-left: 15px;
            padding-left: 12px;
        }

        .section-node .section-content {
            gap: 10px;
            flex-wrap: wrap;
        }

        .section-node .section-number {
            min-width: 45px;
            font-size: 13px;
        }

        .section-node[data-level="1"] > .section-content .section-title {
            font-size: 15px;
        }

        .section-node[data-level="2"] > .section-content .section-title {
            font-size: 14px;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var feedbackModal = document.getElementById('feedback-modal');
        var openButton = document.getElementById('view-feedbacks-btn');
        var closeButton = document.getElementById('close-feedback-modal');

        if (openButton && feedbackModal) {
            openButton.addEventListener('click', function () {
                feedbackModal.classList.add('show');
                document.body.style.overflow = 'hidden';
            });
        }

        if (closeButton && feedbackModal) {
            closeButton.addEventListener('click', function () {
                feedbackModal.classList.remove('show');
                document.body.style.overflow = '';
            });
        }

        if (feedbackModal) {
            feedbackModal.addEventListener('click', function (event) {
                if (event.target === feedbackModal) {
                    feedbackModal.classList.remove('show');
                    document.body.style.overflow = '';
                }
            });
        }

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && feedbackModal && feedbackModal.classList.contains('show')) {
                feedbackModal.classList.remove('show');
                document.body.style.overflow = '';
            }
        });
    });
</script>
@endsection