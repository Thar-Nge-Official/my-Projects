@php
    $universityName = trim((string) ($appSettings->university_name ?? '')) ?: 'University of Yangon';
    $departmentName = trim((string) ($appSettings->department_name ?? '')) ?: 'Department of Computer Studies';
@endphp

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Chapter {{ $chapter->chapter_number }} - {{ $chapter->chapter_title }}</title>
    <style>
        body {
            font-family: 'Times New Roman', serif;
            color: #1a1a2e;
            margin: 30px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .header h1 {
            margin: 8px 0 0;
            font-size: 24px;
            letter-spacing: 2px;
        }
        .header h2 {
            margin: 8px 0 0;
            font-size: 16px;
            font-weight: 600;
            color: #6c757d;
        }
        .header p {
            margin: 6px 0 0;
            font-size: 12px;
            color: #6c757d;
        }
        .chapter-title {
            margin: 20px 0 12px;
            font-size: 20px;
            font-weight: 700;
            text-align: center;
            color: #0d6efd;
        }
        .meta {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #495057;
            margin-bottom: 24px;
        }
        .meta div {
            max-width: 45%;
        }
        .section {
            margin-bottom: 24px;
        }
        .section-title {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 8px;
            color: #0d6efd;
        }
        .section-number {
            font-weight: 700;
            color: #198754;
            margin-bottom: 8px;
        }
        .paragraph {
            font-size: 12px;
            line-height: 1.8;
            margin-bottom: 12px;
            text-align: justify;
        }
        .image-wrapper {
            text-align: center;
            margin: 14px 0;
        }
        .image-wrapper img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            border: 1px solid #dee2e6;
        }
        .footer {
            margin-top: 40px;
            border-top: 1px solid #dee2e6;
            padding-top: 12px;
            font-size: 10px;
            color: #6c757d;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ strtoupper($universityName) }}</h1>
        <h2>{{ $departmentName }}</h2>
        <p>Completed Chapter Reference Document</p>
    </div>

    <div class="chapter-title">Chapter {{ $chapter->chapter_number }}: {{ $chapter->chapter_title }}</div>

    <div class="meta">
        <div>
            <strong>Student:</strong> {{ $chapter->thesis->student->firstname ?? 'N/A' }} {{ $chapter->thesis->student->lastname ?? '' }}<br>
            <strong>Roll No.:</strong> {{ $chapter->thesis->student->roll_no ?? 'N/A' }}<br>
            <strong>Class:</strong> {{ $chapter->thesis->student->class ?? 'N/A' }}
        </div>
        <div style="text-align: right;">
            <strong>Thesis:</strong> {{ $chapter->thesis->title }}<br>
            <strong>Approved On:</strong> {{ optional($chapter->approved_at)->format('d M, Y') ?? 'N/A' }}<br>
            <strong>Certificate No.:</strong> {{ optional($chapter->thesis->certificate)->certificate_number ?? 'N/A' }}
        </div>
    </div>

    @php
        $content = json_decode($chapter->content, true);
        if (!is_array($content)) {
            $content = null;
        }
    @endphp

    @if($content && count($content) > 0)
        @foreach($content as $section)
            <div class="section">
                <div class="section-number">{{ $section['number'] ?? '' }} {{ $section['title'] ?? '' }}</div>
                @php
                    $paragraphs = $section['paragraphs'] ?? null;
                    if (is_string($paragraphs)) {
                        $paragraphs = [$paragraphs];
                    }
                @endphp
                @if(is_array($paragraphs) && count($paragraphs) > 0)
                    @foreach($paragraphs as $paragraph)
                        @if(trim($paragraph) !== '')
                            <div class="paragraph">{!! nl2br(e($paragraph)) !!}</div>
                        @endif
                    @endforeach
                @elseif(!empty($section['content']))
                    <div class="paragraph">{!! nl2br(e($section['content'])) !!}</div>
                @endif

                @if(!empty($section['image']))
                    @php
                        $imagePath = $section['image'];
                        $imageData = null;
                        if (Storage::disk('public')->exists($imagePath)) {
                            $imageContent = Storage::disk('public')->get($imagePath);
                            $mimeType = Storage::disk('public')->mimeType($imagePath);
                            $imageData = 'data:' . $mimeType . ';base64,' . base64_encode($imageContent);
                        }
                    @endphp
                    @if($imageData)
                        <div class="image-wrapper">
                            <img src="{{ $imageData }}" alt="Chapter Image">
                        </div>
                    @endif
                    @if(!empty($section['caption']))
                        <div style="font-size: 11px; color: #6c757d; text-align: center; margin-top: 6px; font-style: italic;">{{ $section['caption'] }}</div>
                    @endif
                @endif
            </div>
        @endforeach
    @else
        <div class="paragraph">{!! nl2br(e($chapter->content ?? 'No chapter content available.')) !!}</div>
    @endif

    @if($chapter->file_path)
        <div class="section">
            <div class="section-title">Attached File</div>
            <div class="paragraph">This chapter includes an attached zip file. Please download it from the thesis management system to access the file content.</div>
        </div>
    @endif

    <div class="footer">
        Generated for reference only. This PDF contains the approved chapter content from a completed thesis.
    </div>
</body>
</html>
