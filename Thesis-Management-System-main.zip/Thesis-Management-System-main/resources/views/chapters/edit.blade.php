@extends('layouts.app')

@section('title', 'Edit Chapter')

@section('content')
<div class="container-fluid">
    <!-- ============================================ -->
    <!-- PAGE HEADER -->
    <!-- ============================================ -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex align-items-center gap-3">
                <a href="{{ route('chapters.show', $chapter) }}" class="btn btn-light btn-sm rounded-circle shadow-sm" style="width: 42px; height: 42px; padding: 0;">
                    <i class="fas fa-arrow-left text-primary"></i>
                </a>
                <div>
                    <h3 class="fw-bold mb-0 text-dark">Edit Chapter</h3>
                    <p class="text-muted small mb-0">
                        <i class="fas fa-info-circle me-1"></i>
                        Chapter {{ $chapter->chapter_number }}: <strong>{{ $chapter->chapter_title }}</strong>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- MAIN CONTENT -->
    <!-- ============================================ -->
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-3 mb-4 pb-3 border-bottom">
                        <div class="bg-warning bg-opacity-10 p-3 rounded-3">
                            <i class="fas fa-pen-to-square text-warning" style="font-size: 24px;"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0">Edit Chapter Information</h5>
                            <p class="text-muted small mb-0">Update your chapter details</p>
                        </div>
                    </div>

                    @if($errors->any())
                        <div class="alert alert-danger border-0 rounded-3 mb-4">
                            <div class="d-flex align-items-start gap-2">
                                <i class="fas fa-circle-exclamation mt-1"></i>
                                <div>
                                    <strong>Please fix the following errors:</strong>
                                    <ul class="mb-0 mt-1 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endif

                    <form action="{{ route('chapters.update', $chapter) }}" method="POST" enctype="multipart/form-data" id="chapterForm">
                        @csrf
                        @method('PUT')

                        <div class="row g-3">
                            <!-- Chapter Title -->
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="chapter_title" class="form-label fw-semibold">
                                        <i class="fas fa-heading text-primary me-1"></i> Chapter Title <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" class="form-control form-control-lg @error('chapter_title') is-invalid @enderror" 
                                           id="chapter_title" name="chapter_title" value="{{ old('chapter_title', $chapter->chapter_title) }}" 
                                           placeholder="Enter chapter title" required>
                                    @error('chapter_title')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <!-- ============================================ -->
                            <!-- CONTENT WITH STRUCTURED SECTIONS -->
                            <!-- ============================================ -->
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-label fw-semibold">
                                        <i class="fas fa-align-left text-primary me-1"></i> Content Structure
                                    </label>
                                    <p class="text-muted small mb-2">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Edit sections with auto-numbering (1.1, 1.1.1, 1.2, 1.1.2, etc.)
                                    </p>
                                    
                                    <div id="sections-container" class="mb-3">
                                        <!-- Sections will be loaded from existing data -->
                                    </div>
                                    
                                    <div class="d-flex flex-wrap gap-2">
                                        <button type="button" class="btn btn-outline-primary rounded-pill px-3" id="add-section-btn">
                                            <i class="fas fa-plus me-1"></i> Add Section
                                        </button>
                                        <button type="button" class="btn btn-outline-secondary rounded-pill px-3" id="add-subsection-btn">
                                            <i class="fas fa-level-down-alt me-1"></i> Add Sub-section
                                        </button>
                                        <button type="button" class="btn btn-outline-danger rounded-pill px-3" id="clear-sections-btn">
                                            <i class="fas fa-trash me-1"></i> Clear All
                                        </button>
                                    </div>
                                    
                                    <!-- Hidden input to store structured content -->
                                    <input type="hidden" name="content" id="content-hidden">
                                </div>
                            </div>

                            <!-- File Upload -->
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="file" class="form-label fw-semibold">
                                        <i class="fas fa-file-upload text-primary me-1"></i> Upload File (Optional)
                                    </label>
                                    @if($chapter->file_path)
                                        <div class="alert alert-info border-0 rounded-3 mb-2">
                                            <i class="fas fa-file me-2"></i>
                                            Current file: <a href="{{ asset('storage/' . $chapter->file_path) }}" target="_blank">View File</a>
                                        </div>
                                    @endif
                                    <input type="file" class="form-control @error('file') is-invalid @enderror" 
                                           id="file" name="file" accept=".zip">
                                    @error('file')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Supported format: ZIP (Max: 3000MB) — For uploading the system file.
                                    </small>
                                </div>
                            </div>
                        </div>

                        <!-- Form Actions -->
                        <div class="d-flex flex-wrap gap-3 justify-content-end pt-3 mt-3 border-top">
                            <a href="{{ route('chapters.show', $chapter) }}" class="btn btn-outline-secondary rounded-pill px-4 py-2">
                                <i class="fas fa-times me-2"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary rounded-pill px-5 py-2 shadow-sm" id="submit-btn">
                                <i class="fas fa-save me-2"></i> Update Chapter
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- SECTION TEMPLATE -->
<!-- ============================================ -->
<script id="section-template" type="text/template">
    <div class="section-item mb-3" data-level="{level}" data-parent="{parent}" data-number="{number}">
        <div class="p-3 bg-light rounded-3 section-card">
            <div class="d-flex align-items-start gap-2">
                <span class="section-number fw-bold text-primary" style="min-width: 70px; font-size: 15px;">{number}</span>
                <div class="flex-grow-1">
                    <div class="d-flex flex-wrap gap-2 mb-3">
                        <input type="text" class="form-control form-control-sm section-title" placeholder="Enter section title..." style="flex: 1;" value="{title}">
                        <button type="button" class="btn btn-sm btn-outline-secondary add-paragraph-btn" title="Add paragraph">
                            <i class="fas fa-plus me-1"></i>Paragraph
                        </button>
                    </div>
                    <div class="paragraphs-container mb-3"></div>
                    <input type="hidden" class="section-image-path" value="{image}">
                    <div class="d-flex flex-wrap gap-2 align-items-center">
                        <input type="file" name="section_images[]" accept="image/*" class="form-control form-control-sm section-image" style="max-width: 220px;">
                        <input type="text" name="section_captions[]" class="form-control form-control-sm section-caption" placeholder="Image caption (optional)" style="max-width: 260px;">
                        <button type="button" class="btn btn-sm btn-outline-danger remove-section-btn" title="Remove this section">
                            <i class="fas fa-times"></i>
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-primary add-subsection-btn" title="Add sub-section under this">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</script>

<style>
    .section-item {
        transition: all 0.3s ease;
        animation: fadeIn 0.3s ease;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .section-item:hover {
        background: rgba(108, 99, 255, 0.05);
        border-radius: 8px;
    }
    
    .section-item .section-number {
        font-weight: 700;
        font-size: 15px;
        color: #0d6efd;
        min-width: 70px;
        display: flex;
        align-items: center;
    }
    
    .section-item .form-control {
        border: 1px solid #e9ecef;
        font-size: 14px;
        transition: all 0.3s ease;
        height: 38px;
    }
    
    .section-item .form-control:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.1);
    }
    
    .section-item .remove-section-btn,
    .section-item .add-subsection-btn {
        opacity: 0.3;
        transition: all 0.3s ease;
        width: 34px;
        height: 34px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .section-item:hover .remove-section-btn,
    .section-item:hover .add-subsection-btn {
        opacity: 1;
    }
    
    .section-item .remove-section-btn:hover {
        background: #dc3545;
        color: white;
        opacity: 1;
    }
    
    .section-item .add-subsection-btn:hover {
        background: #0d6efd;
        color: white;
        opacity: 1;
    }
    
    /* Indentation for sub-sections */
    .section-item[data-level="2"] {
        margin-left: 30px;
    }
    
    .section-item[data-level="3"] {
        margin-left: 60px;
    }
    
    .section-item[data-level="4"] {
        margin-left: 90px;
    }
    
    .section-item[data-level="2"] .section-number {
        color: #198754;
    }
    
    .section-item[data-level="3"] .section-number {
        color: #ffc107;
    }
    
    .section-item[data-level="4"] .section-number {
        color: #dc3545;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .section-item .d-flex {
            flex-wrap: wrap;
            gap: 6px;
        }
        
        .section-item .section-number {
            min-width: 50px;
            font-size: 14px;
        }
        
        .section-item .form-control {
            flex: 1 1 100% !important;
        }
        
        .section-item[data-level="2"] {
            margin-left: 15px;
        }
        
        .section-item[data-level="3"] {
            margin-left: 30px;
        }
        
        .section-item[data-level="4"] {
            margin-left: 45px;
        }
        
        .section-item .remove-section-btn,
        .section-item .add-subsection-btn {
            opacity: 1;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // ============================================
        // SECTION MANAGEMENT - EDIT MODE
        // ============================================
        
        // Get the chapter number from the existing chapter
        let chapterNumber = {{ $chapter->chapter_number }};
        
        // Counters for each level
        let levelCounters = {};
        let sectionCounter = 0;
        
        // Get template
        const template = document.getElementById('section-template').innerHTML;
        const container = document.getElementById('sections-container');
        
        // ============================================
        // LOAD EXISTING SECTIONS
        // ============================================
        
        function loadExistingSections() {
            const content = @json($chapter->content ?? '');
            
            if (!content || content === '' || content === '[]' || content === 'null') {
                addSection(1, '', ['']);
                return;
            }
            
            try {
                const sections = JSON.parse(content);
                
                if (!sections || sections.length === 0) {
                    addSection(1, '', ['']);
                    return;
                }
                
                levelCounters = {};
                
                sections.forEach((section) => {
                    const level = section.level || 1;
                    const title = section.title || '';
                    let paragraphs = Array.isArray(section.paragraphs)
                        ? section.paragraphs
                        : (section.content ? [section.content] : ['']);
                    if (paragraphs.length === 0) {
                        paragraphs = [''];
                    }
                    const imagePath = section.image || '';
                    const caption = section.caption || '';
                     
                    addSectionWithData(level, section.number || '', title, paragraphs, imagePath, caption);
                });
            } catch (e) {
                console.error('Error parsing content:', e);
                if (content && content !== '[]' && content !== 'null') {
                    addSection(1, '', [content]);
                } else {
                    addSection(1, '', ['']);
                }
            }
        }
        
        function resetCountersForLevels(level) {
            for (let i = level; i <= 4; i++) {
                levelCounters[i] = 0;
            }
        }
        
        function getNextNumber(level, isNewMainSection = false) {
            if (isNewMainSection || level === 1) {
                if (!levelCounters[1]) {
                    levelCounters[1] = 0;
                }
                levelCounters[1]++;
                resetCountersForLevels(2);
            } else {
                if (!levelCounters[level]) {
                    levelCounters[level] = 0;
                }
                levelCounters[level]++;
            }
            
            let number = '';
            for (let i = 1; i <= level; i++) {
                if (i === 1) {
                    number += chapterNumber + '.';
                    number += levelCounters[i] || 1;
                } else {
                    number += '.';
                    number += levelCounters[i] || 1;
                }
            }
            return number;
        }
        
        function addSectionWithData(level, existingNumber, title, paragraphs = [''], imagePath = '', caption = '') {
            if (level > 4) {
                alert('Maximum 4 levels of nesting allowed!');
                return;
            }

            const isNewMainSection = (level === 1);
            let number = existingNumber;
            if (!number || number === '') {
                number = getNextNumber(level, isNewMainSection);
            } else {
                if (level === 1) {
                    if (!levelCounters[1]) {
                        levelCounters[1] = 0;
                    }
                    levelCounters[1]++;
                    resetCountersForLevels(2);
                } else {
                    if (!levelCounters[level]) {
                        levelCounters[level] = 0;
                    }
                    levelCounters[level]++;
                }
            }

            const parentNumber = getParentNumber(level);
             
            let html = template
                .replace(/{level}/g, level)
                .replace(/{parent}/g, parentNumber)
                .replace(/{number}/g, number)
                .replace(/{title}/g, title.replace(/"/g, '&quot;'))
                .replace(/{image}/g, imagePath);
             
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;
            const sectionElement = tempDiv.firstElementChild;
             
            container.appendChild(sectionElement);
            sectionCounter++;
             
            paragraphs.forEach(paragraphText => addParagraph(sectionElement, paragraphText || ''));
             
            if (imagePath) {
                sectionElement.querySelector('.section-image-path').value = imagePath;
            }
            if (caption) {
                const captionInput = sectionElement.querySelector('.section-caption');
                if (captionInput) captionInput.value = caption;
            }

            setupSectionEvents(sectionElement);

            if (imagePath) {
                try {
                    const imgPreview = document.createElement('div');
                    imgPreview.className = 'mt-2';
                    imgPreview.innerHTML = `<img src="${imagePath.startsWith('http') ? imagePath : ('/storage/' + imagePath)}" style="max-height:80px; max-width:220px; display:block; margin-bottom:6px;" class="img-fluid rounded" />`;
                    const fileInput = sectionElement.querySelector('.section-image');
                    if (fileInput && fileInput.parentNode) {
                        fileInput.parentNode.insertBefore(imgPreview, fileInput);
                    } else {
                        sectionElement.appendChild(imgPreview);
                    }
                } catch (e) {
                    console.warn('Error rendering section image preview', e);
                }
            }

            recalculateNumbers();
        }
        
        function getParentNumber(level) {
            if (level <= 1) return '';
            let number = '';
            for (let i = 1; i < level; i++) {
                if (i === 1) {
                    number += chapterNumber + '.';
                    number += levelCounters[i] || 1;
                } else {
                    number += '.';
                    number += levelCounters[i] || 1;
                }
            }
            return number;
        }
        
        function addSection(level = 1, title = '', paragraphs = [''], imagePath = '') {
            if (level > 4) {
                alert('Maximum 4 levels of nesting allowed!');
                return;
            }
            
            const isNewMainSection = (level === 1);
            const number = getNextNumber(level, isNewMainSection);
            const parentNumber = getParentNumber(level);
            
            let html = template
                .replace(/{level}/g, level)
                .replace(/{parent}/g, parentNumber)
                .replace(/{number}/g, number)
                .replace(/{title}/g, title.replace(/"/g, '&quot;'))
                .replace(/{image}/g, imagePath);
            
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;
            const sectionElement = tempDiv.firstElementChild;
            
            container.appendChild(sectionElement);
            sectionCounter++;
            
            const titleInput = sectionElement.querySelector('.section-title');
            setTimeout(() => titleInput.focus(), 100);

            paragraphs.forEach(paragraphText => addParagraph(sectionElement, paragraphText || ''));
            if (imagePath) {
                sectionElement.querySelector('.section-image-path').value = imagePath;
            }

            setupSectionEvents(sectionElement);
            recalculateNumbers();
        }
        
        function setupSectionEvents(sectionElement) {
            // Remove button
            const removeBtn = sectionElement.querySelector('.remove-section-btn');
            removeBtn.addEventListener('click', function() {
                if (confirm('Remove this section?')) {
                    const removedLevel = parseInt(sectionElement.dataset.level) || 1;
                    let next = sectionElement.nextElementSibling;
                    while (next && parseInt(next.dataset.level) > removedLevel) {
                        const toRemove = next;
                        next = next.nextElementSibling;
                        toRemove.remove();
                    }
                    sectionElement.remove();
                    recalculateNumbers();
                }
            });
            
            // Add sub-section button
            const addSubBtn = sectionElement.querySelector('.add-subsection-btn');
            addSubBtn.addEventListener('click', function() {
                const currentLevel = parseInt(sectionElement.dataset.level) || 1;
                if (currentLevel < 4) {
                    insertSectionAfter(sectionElement, currentLevel + 1);
                } else {
                    alert('Maximum 4 levels of nesting allowed!');
                }
            });

            // Add paragraph button
            const addParagraphBtn = sectionElement.querySelector('.add-paragraph-btn');
            addParagraphBtn.addEventListener('click', function() {
                addParagraph(sectionElement, '');
            });

            // Remove paragraph buttons by delegation
            sectionElement.addEventListener('click', function(event) {
                const removeParagraph = event.target.closest('.remove-paragraph-btn');
                if (removeParagraph) {
                    const paragraphBlock = removeParagraph.closest('.paragraph-block');
                    if (paragraphBlock) {
                        paragraphBlock.remove();
                    }
                }
            });
        }

        function createParagraphField(text = '') {
            const wrapper = document.createElement('div');
            wrapper.className = 'paragraph-block mb-2';
            wrapper.innerHTML = `
                <div class="d-flex gap-2 align-items-start">
                    <textarea class="form-control form-control-sm section-paragraph" placeholder="Enter paragraph..." style="flex: 1; min-height: 80px; resize: vertical;">${text.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</textarea>
                    <button type="button" class="btn btn-sm btn-outline-danger remove-paragraph-btn" title="Remove paragraph" style="height: 38px; align-self: flex-start;">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            return wrapper;
        }

        function addParagraph(sectionElement, text = '') {
            const paragraphsContainer = sectionElement.querySelector('.paragraphs-container');
            if (!paragraphsContainer) return;
            paragraphsContainer.appendChild(createParagraphField(text));
        }

        function insertSectionAfter(referenceSection, level = 1) {
            if (level > 4) {
                alert('Maximum 4 levels of nesting allowed!');
                return;
            }

            const number = getNextNumber(level, level === 1);
            const parentNumber = getParentNumber(level);
            
            let html = template
                .replace(/{level}/g, level)
                .replace(/{parent}/g, parentNumber)
                .replace(/{number}/g, number)
                .replace(/{title}/g, '')
                .replace(/{image}/g, '');
            
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;
            const sectionElement = tempDiv.firstElementChild;

            referenceSection.insertAdjacentElement('afterend', sectionElement);
            sectionCounter++;
            addParagraph(sectionElement, '');
            setupSectionEvents(sectionElement);
            recalculateNumbers();
        }

        function recalculateNumbers() {
            const items = Array.from(container.querySelectorAll('.section-item'));
            const counters = {1: 0, 2: 0, 3: 0, 4: 0};

            items.forEach((item, index) => {
                const level = parseInt(item.dataset.level) || 1;

                if (level === 1) {
                    counters[1]++;
                    counters[2] = 0;
                    counters[3] = 0;
                    counters[4] = 0;
                } else {
                    if (!counters[level - 1]) {
                        counters[level - 1] = 1;
                    }
                    counters[level] = (counters[level] || 0) + 1;
                    for (let i = level + 1; i <= 4; i++) {
                        counters[i] = 0;
                    }
                }

                let number = chapterNumber + '.' + counters[1];
                for (let i = 2; i <= level; i++) {
                    number += '.' + (counters[i] || 1);
                }

                const numberSpan = item.querySelector('.section-number');
                if (numberSpan) {
                    numberSpan.textContent = number;
                }
                
                item.dataset.number = number;

                let parentNumber = '';
                if (level > 1) {
                    for (let prevIndex = index - 1; prevIndex >= 0; prevIndex--) {
                        const prevItem = items[prevIndex];
                        const prevLevel = parseInt(prevItem.dataset.level) || 1;
                        if (prevLevel === level - 1) {
                            parentNumber = prevItem.dataset.number;
                            break;
                        }
                    }
                }
                item.dataset.parent = parentNumber;
            });
        }
        
        // ============================================
        // BUTTON EVENTS
        // ============================================
        
        document.getElementById('add-section-btn').addEventListener('click', function() {
            addSection(1);
        });
        
        document.getElementById('add-subsection-btn').addEventListener('click', function() {
            const lastItem = container.querySelector('.section-item:last-child');
            if (!lastItem) {
                addSection(1);
                return;
            }
            const lastLevel = parseInt(lastItem.dataset.level) || 1;
            if (lastLevel >= 4) {
                alert('Maximum 4 levels of nesting allowed!');
                return;
            }
            addSection(lastLevel + 1);
        });
        
        document.getElementById('clear-sections-btn').addEventListener('click', function() {
            if (container.querySelectorAll('.section-item').length === 0) return;
            if (confirm('Remove all sections?')) {
                container.innerHTML = '';
                levelCounters = {};
                sectionCounter = 0;
                addSection(1);
            }
        });
        
        // ============================================
        // FORM SUBMISSION
        // ============================================
        
        document.getElementById('submit-btn').addEventListener('click', function(e) {
            e.preventDefault();
            
            const items = container.querySelectorAll('.section-item');
            const sectionsData = [];
            
            items.forEach(item => {
                const number = item.dataset.number || '';
                const title = item.querySelector('.section-title')?.value || '';
                const level = parseInt(item.dataset.level) || 1;
                const imagePath = item.querySelector('.section-image-path')?.value || '';
                const caption = item.querySelector('.section-caption')?.value.trim() || '';
                const paragraphs = [];

                item.querySelectorAll('.section-paragraph').forEach(paragraphEl => {
                    const paragraphText = paragraphEl.value.trim();
                    if (paragraphText) {
                        paragraphs.push(paragraphText);
                    }
                });

                if (title.trim() || paragraphs.length > 0 || imagePath || caption) {
                    sectionsData.push({
                        number: number,
                        level: level,
                        title: title.trim(),
                        paragraphs: paragraphs,
                        image: imagePath,
                        caption: caption
                    });
                }
            });
            
            const jsonContent = JSON.stringify(sectionsData);
            document.getElementById('content-hidden').value = jsonContent;
            
            document.getElementById('chapterForm').submit();
        });
        
        // ============================================
        // INITIALIZATION
        // ============================================
        
        // Load existing sections or add empty
        setTimeout(() => {
            loadExistingSections();
        }, 100);
    });
</script>
@endsection