@extends('layouts.app')

@section('title', 'Proposal Details')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="proposal-page-header">
                <div class="proposal-page-title d-flex align-items-center gap-3">
                    <a href="{{ route('admin.proposals.index') }}" class="btn btn-light btn-sm rounded-circle shadow-sm" style="width: 42px; height: 42px; padding: 0;">
                        <i class="fas fa-arrow-left text-primary"></i>
                    </a>
                    <div>
                        <h3 class="fw-bold mb-0 text-dark">{{ $proposal->title }}</h3>
                        <div class="d-flex flex-wrap align-items-center gap-2 mt-1">
                            <span class="badge bg-{{ $proposal->status_color }} px-3 py-2 rounded-pill">
                                <i class="fas fa-circle me-1" style="font-size: 8px;"></i>
                                {{ $proposal->status_label }}
                            </span>
                            <span class="text-muted">•</span>
                            <span class="text-muted small">ID: #{{ $proposal->id }}</span>
                            @if($proposal->is_selected)
                                <span class="badge bg-success">⭐ Selected</span>
                            @endif
                        </div>
                    </div>
                </div>
                @if($proposal->status == 'submitted' || $proposal->status == 'pending')
                    <div class="proposal-review-actions">
                        <form action="{{ route('admin.proposals.approve', $proposal) }}" method="POST" class="proposal-approval-form">
                            @csrf
                            <div class="proposal-approval-controls">
                                <select id="supervisor_id" name="supervisor_id" class="form-select form-select-sm" aria-label="Assign supervisor" required>
                                    <option value="">Select Supervisor</option>
                                    @foreach($supervisors as $supervisor)
                                        <option value="{{ $supervisor->id }}">{{ $supervisor->firstname }} {{ $supervisor->lastname }}</option>
                                    @endforeach
                                </select>
                                <button type="submit" class="btn btn-success rounded-pill px-4 proposal-approve-button" onclick="return confirm('Approve this proposal? A thesis will be created for the student.')">
                                    <i class="fas fa-check me-2"></i>Approve &amp; Create Thesis
                                </button>
                            </div>
                            <div class="form-text text-muted mt-1">Choose a supervisor before approving.</div>
                        </form>
                        <button type="button" class="btn btn-danger rounded-pill px-4 proposal-reject-button" data-bs-toggle="modal" data-bs-target="#rejectModal">
                            <i class="fas fa-times me-2"></i>Reject
                        </button>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Reject Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="{{ route('admin.proposals.reject', $proposal) }}" method="POST">
                    @csrf
                    <div class="modal-header">
                        <h5 class="modal-title">Reject Proposal</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Rejection Reason <span class="text-danger">*</span></label>
                            <textarea name="rejection_reason" class="form-control" rows="4" placeholder="Why is this proposal being rejected?" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary rounded-pill" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger rounded-pill">
                            <i class="fas fa-times me-2"></i> Reject Proposal
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0 rounded-4 mb-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <div class="bg-info bg-opacity-10 p-2 rounded-3">
                            <i class="fas fa-info-circle text-info"></i>
                        </div>
                        <h6 class="fw-bold mb-0">Proposal Information</h6>
                    </div>
                    
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-primary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-user-graduate text-primary"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Student</label>
                                    <p class="fw-semibold mb-0">{{ $proposal->student->firstname ?? 'N/A' }} {{ $proposal->student->lastname ?? '' }}</p>
                                    <small class="text-muted">Roll: {{ $proposal->student->roll_no ?? 'N/A' }}</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-warning bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-tags text-warning"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Category</label>
                                    <p class="fw-semibold mb-0">{{ $proposal->category->name ?? 'N/A' }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-danger bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-code text-danger"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Thesis Type</label>
                                    <p class="fw-semibold mb-0">{{ $proposal->thesis_type ?? 'N/A' }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-secondary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-calendar-days text-secondary"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Academic Year</label>
                                    <p class="fw-semibold mb-0">{{ $proposal->from_year ?? 'N/A' }} - {{ $proposal->to_year ?? 'N/A' }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-success bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-clock text-success"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Submitted Date</label>
                                    <p class="fw-semibold mb-0">{{ $proposal->submitted_at ? $proposal->submitted_at->format('d/m/Y H:i') : 'Not submitted' }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-item d-flex align-items-start gap-3 p-3 bg-light rounded-3">
                                <div class="icon-wrapper bg-primary bg-opacity-10 p-2 rounded-3">
                                    <i class="fas fa-check-circle text-primary"></i>
                                </div>
                                <div>
                                    <label class="text-muted small text-uppercase fw-semibold d-block">Approved Date</label>
                                    <p class="fw-semibold mb-0">{{ $proposal->approved_at ? $proposal->approved_at->format('d/m/Y H:i') : 'Pending' }}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    @if($proposal->rejection_reason)
                        <div class="alert alert-danger border-0 rounded-3 mt-4">
                            <div class="d-flex align-items-center gap-2">
                                <i class="fas fa-circle-exclamation"></i>
                                <div>
                                    <strong>Rejection Reason:</strong>
                                    <span>{{ $proposal->rejection_reason }}</span>
                                </div>
                            </div>
                        </div>
                    @endif

                    @if($proposal->keywords)
                        <div class="mt-4">
                            <label class="text-muted small text-uppercase fw-semibold d-block mb-2">Keywords</label>
                            <div class="d-flex flex-wrap gap-2">
                                @foreach(explode(',', $proposal->keywords) as $keyword)
                                    <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill">#{{ trim($keyword) }}</span>
                                @endforeach
                            </div>
                        </div>
                    @endif

                    <div class="mt-4">
                        <label class="text-muted small text-uppercase fw-semibold d-block mb-2">Abstract</label>
                        <div class="abstract-box p-4 bg-light rounded-3">
                            <p class="mb-0" style="line-height: 1.8;">{{ $proposal->abstract }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm border-0 rounded-4 mb-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <div class="bg-info bg-opacity-10 p-2 rounded-3">
                            <i class="fas fa-circle-info text-info"></i>
                        </div>
                        <h6 class="fw-bold mb-0">Proposal Info</h6>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Status</span>
                        <span class="badge bg-{{ $proposal->status_color }} rounded-pill px-3 py-2">{{ $proposal->status_label }}</span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Created</span>
                        <span class="fw-semibold">{{ $proposal->created_at->format('d M, Y H:i') }}</span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Last Updated</span>
                        <span class="fw-semibold">{{ $proposal->updated_at->format('d M, Y H:i') }}</span>
                    </div>
                    <div class="info-row d-flex justify-content-between py-2">
                        <span class="text-muted">Proposal ID</span>
                        <span class="fw-semibold">#{{ $proposal->id }}</span>
                    </div>
                </div>
            </div>

            @if($proposal->status == 'approved' && $proposal->thesis)
                <div class="card shadow-sm border-0 rounded-4 border border-success">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-2 mb-3">
                            <div class="bg-success bg-opacity-10 p-2 rounded-3">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <h6 class="fw-bold mb-0 text-success">Thesis Created!</h6>
                        </div>
                        <p class="text-muted small mb-2">A thesis has been created from this proposal.</p>
                        <a href="{{ route('theses.show', $proposal->thesis) }}" class="btn btn-primary rounded-pill w-100">
                            <i class="fas fa-eye me-2"></i> View Thesis
                        </a>
                    </div>
                </div>
            @endif

            @if(in_array($proposal->status, ['submitted', 'pending']))
                <div class="card shadow-sm border-0 rounded-4 bg-light">
                    <div class="card-body p-4 text-center">
                        <div class="bg-warning bg-opacity-10 p-3 rounded-3 d-inline-block">
                            <i class="fas fa-clock text-warning" style="font-size: 32px;"></i>
                        </div>
                        <h6 class="fw-bold mt-3">Pending Review</h6>
                        <p class="text-muted small mb-0">This proposal is waiting for admin approval.</p>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>

<style>
    .proposal-page-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 1.5rem;
    }

    .proposal-page-title {
        min-width: 0;
    }

    .proposal-page-title h3 {
        overflow-wrap: anywhere;
    }

    .proposal-review-actions {
        display: flex;
        align-items: flex-start;
        gap: 0.75rem;
        width: 100%;
        max-width: 700px;
    }

    .proposal-approval-form {
        flex: 1 1 0;
        min-width: 0;
        margin: 0;
    }

    .proposal-approval-controls {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .proposal-approval-controls .form-select {
        flex: 1 1 220px;
        width: auto;
        min-width: 220px;
    }

    .proposal-approve-button,
    .proposal-reject-button {
        flex: 0 0 auto;
        min-height: 38px;
        white-space: nowrap;
    }

    .abstract-box {
        border-left: 4px solid #0d6efd;
        font-size: 14px;
    }

    @media (max-width: 1199.98px) {
        .proposal-page-header {
            flex-direction: column;
        }

        .proposal-review-actions {
            max-width: none;
        }
    }

    @media (max-width: 575.98px) {
        .proposal-page-header,
        .proposal-review-actions,
        .proposal-approval-controls {
            gap: 0.5rem;
        }

        .proposal-review-actions,
        .proposal-approval-controls {
            flex-direction: column;
            align-items: stretch;
        }

        .proposal-approval-controls .form-select {
            width: 100%;
            min-width: 0;
        }
    }
</style>
@endsection
