@extends('layouts.app')

@section('title', 'Approved Thesis Proposals')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-check-circle text-success me-2"></i>Approved Thesis Proposals</h2>
            <p class="text-muted mb-0">View proposals that have already been approved and converted into thesis projects.</p>
        </div>
        <div class="btn-group" role="group">
            <a href="{{ route('admin.proposals.index') }}" class="btn btn-outline-primary">All</a>
            <a href="{{ route('admin.proposals.pending') }}" class="btn btn-outline-secondary">Pending</a>
            <a href="{{ route('admin.proposals.approved') }}" class="btn btn-outline-success active">Approved</a>
            <a href="{{ route('admin.proposals.rejected') }}" class="btn btn-outline-danger">Rejected</a>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4 py-3" style="width: 50px;">#</th>
                            <th class="py-3">Title</th>
                            <th class="py-3">Student</th>
                            <th class="py-3">Category</th>
                            <th class="py-3 text-center">Status</th>
                            <th class="py-3 text-center">Approved</th>
                            <th class="py-3 pe-4 text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($proposals as $proposal)
                            <tr>
                                <td class="ps-4 fw-semibold text-muted">{{ $loop->iteration }}</td>
                                <td class="fw-semibold">{{ Str::limit($proposal->title, 45) }}</td>
                                <td>{{ $proposal->student->firstname ?? 'N/A' }} {{ $proposal->student->lastname ?? '' }}</td>
                                <td>{{ $proposal->category->name ?? 'N/A' }}</td>
                                <td class="text-center">
                                    <span class="badge bg-{{ $proposal->status_color }} px-3 py-2 rounded-pill">{{ $proposal->status_label }}</span>
                                </td>
                                <td class="text-center text-muted">{{ $proposal->approved_at ? $proposal->approved_at->format('d/m/Y') : '—' }}</td>
                                <td class="pe-4 text-end">
                                    <a href="{{ route('admin.proposals.show', $proposal) }}" class="btn btn-sm btn-info rounded-circle" title="View Proposal" style="width: 34px; height: 34px; padding: 0;">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center py-5">
                                    <div>
                                        <i class="fas fa-check-circle text-muted" style="font-size: 48px;"></i>
                                        <h5 class="mt-3 text-muted">No approved proposals found</h5>
                                        <p class="text-muted mb-0">There are no approved proposals yet.</p>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @if($proposals->hasPages())
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>Showing {{ $proposals->firstItem() }} to {{ $proposals->lastItem() }} of {{ $proposals->total() }}</div>
            <div>{{ $proposals->links() }}</div>
        </div>
    @endif
</div>
@endsection
