@extends('layouts.app')

@section('title', 'System Settings')

@push('styles')
<style>
    .settings-page {
        background: #eef0f3;
        min-height: calc(100vh - 80px);
        padding-top: 18px;
    }

    .settings-title {
        text-align: center;
        font-size: clamp(2rem, 4vw, 3.5rem);
        font-weight: 700;
        letter-spacing: 0;
        color: #1f2b3d;
        margin: 18px 0 8px;
        line-height: 1.1;
    }

    .settings-subtitle {
        text-align: center;
        color: #6b7280;
        font-size: 1.05rem;
        margin-bottom: 26px;
        font-weight: 400;
    }

    .settings-card {
        max-width: 1040px;
        margin: 0 auto;
        background: rgba(255,255,255,0.6);
        border: 1px solid #dfe3e8;
        border-radius: 12px;
        padding: 28px 28px 20px;
        box-shadow: none;
    }

    .scenario-panel {
        max-width: 1040px;
        margin: 0 auto 18px;
        background: #fff;
        border: 1px solid #dfe3e8;
        border-radius: 12px;
        padding: 20px;
    }

    .scenario-panel-title {
        color: #1f2b3d;
        font-size: 1.05rem;
        font-weight: 700;
        margin-bottom: 14px;
    }

    .scenario-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
    }

    .scenario-btn {
        border: 1px solid #dfe3e8;
        border-radius: 8px;
        background: #f8fafc;
        color: #1f2b3d;
        display: flex;
        flex-direction: column;
        gap: 6px;
        min-height: 92px;
        padding: 14px;
        text-align: left;
        transition: all 0.2s ease;
    }

    .scenario-btn:hover {
        border-color: #0d6efd;
        background: #eef5ff;
    }

    .scenario-btn strong {
        font-size: 0.95rem;
    }

    .scenario-btn span {
        color: #6b7280;
        font-size: 0.82rem;
        line-height: 1.35;
    }

    .settings-form .form-label {
        display: block;
        font-size: 1.02rem;
        font-weight: 600;
        color: #1f2b3d;
        margin-bottom: 10px;
    }

    .settings-form .form-control,
    .settings-form .form-select {
        width: 100%;
        min-height: 50px;
        border: 1px solid #c9ced6;
        border-radius: 18px;
        background: #f7f7f8;
        color: #1f2b3d;
        font-size: 1.05rem;
        padding: 12px 16px;
        box-shadow: none;
    }

    .field-help {
        color: #6b7280;
        font-size: 0.82rem;
        margin-top: 6px;
    }

    .settings-form textarea.form-control {
        min-height: 110px;
        resize: vertical;
    }

    .settings-section-title {
        color: #1f2b3d;
        font-size: 1rem;
        font-weight: 700;
        margin: 4px 0 18px;
        padding-bottom: 10px;
        border-bottom: 1px solid #dfe3e8;
    }

    .current-image {
        display: inline-flex;
        align-items: center;
        gap: 12px;
        margin-top: 10px;
        color: #6b7280;
        font-size: 0.9rem;
    }

    .current-image img {
        max-width: 120px;
        max-height: 56px;
        object-fit: contain;
        border: 1px solid #dfe3e8;
        border-radius: 8px;
        background: #fff;
        padding: 6px;
    }

    .settings-form .form-control:focus,
    .settings-form .form-select:focus {
        border-color: #4ca3ff;
        box-shadow: 0 0 0 3px rgba(76, 163, 255, 0.12);
        background: #fff;
        outline: none;
    }

    .settings-form .mb-3,
    .settings-form .mb-4 {
        margin-bottom: 1.35rem !important;
    }

    .settings-form .save-btn {
        background: linear-gradient(180deg, #0d6efd 0%, #0b5ed7 100%);
        border: 0;
        border-radius: 999px;
        font-size: 1.05rem;
        font-weight: 600;
        padding: 12px 28px;
        min-width: 170px;
    }

    .settings-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        justify-content: space-between;
        align-items: center;
        padding-top: 8px;
    }

    .settings-form .save-btn:hover {
        filter: brightness(1.03);
    }

    .settings-form select {
        appearance: none;
        background-image: linear-gradient(45deg, transparent 50%, #4b5563 50%), linear-gradient(135deg, #4b5563 50%, transparent 50%);
        background-position: calc(100% - 20px) calc(50% - 3px), calc(100% - 14px) calc(50% - 3px);
        background-size: 6px 6px, 6px 6px;
        background-repeat: no-repeat;
        padding-right: 42px;
    }

    @media (max-width: 576px) {
        .settings-card {
            padding: 20px 18px 16px;
        }
        .settings-title {
            font-size: 2.5rem;
        }
    }

    @media (max-width: 992px) {
        .scenario-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }

    @media (max-width: 576px) {
        .scenario-grid {
            grid-template-columns: 1fr;
        }

        .settings-actions .btn,
        .settings-actions form {
            width: 100%;
        }
    }
</style>
@endpush

@section('content')
<div class="settings-page">
    <div class="container">
        <div class="settings-title">System Settings</div>
        <div class="settings-subtitle">Global configuration of the Academic Management Information System</div>

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show mx-auto" style="max-width: 650px;">
                <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show mx-auto" style="max-width: 650px;">
                <i class="fas fa-exclamation-circle me-2"></i> {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @if($errors->any())
            <div class="alert alert-danger alert-dismissible fade show mx-auto" style="max-width: 650px;">
                <i class="fas fa-exclamation-circle me-2"></i>
                <ul class="mb-0 mt-2">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="scenario-panel">
            <div class="scenario-panel-title">
                <i class="fas fa-layer-group me-2 text-primary"></i>Scenario Presets
            </div>
            <div class="scenario-grid">
                <button type="button" class="scenario-btn" data-scenario="academic">
                    <strong>Academic Year Setup</strong>
                    <span>Normal operation with registration open for a new thesis cycle.</span>
                </button>
                <button type="button" class="scenario-btn" data-scenario="review">
                    <strong>Proposal Review Period</strong>
                    <span>Keep the system active while pausing new registrations.</span>
                </button>
                <button type="button" class="scenario-btn" data-scenario="maintenance">
                    <strong>Maintenance Window</strong>
                    <span>Put the system into maintenance while admins continue working.</span>
                </button>
                <button type="button" class="scenario-btn" data-scenario="department">
                    <strong>Department Profile</strong>
                    <span>Fill institution details for emails, certificates, and contact pages.</span>
                </button>
            </div>
        </div>

        <div class="settings-card">
            <form action="{{ route('admin.settings.update') }}" method="POST" enctype="multipart/form-data" class="settings-form">
                @csrf
                @method('PUT')

                <div class="settings-section-title">
                    <i class="fas fa-sliders-h me-2 text-primary"></i>Basic Settings
                </div>

                <div class="mb-3">
                    <label for="system_name" class="form-label">System Name</label>
                    <input type="text"
                           class="form-control @error('system_name') is-invalid @enderror"
                               id="system_name"
                               name="system_name"
                               value="{{ old('system_name', $settings->system_name ?? 'Thesis Management System') }}"
                               placeholder="Thesis Management System"
                               required>
                    @error('system_name')
                        <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="university_name" class="form-label">University Name</label>
                        <input type="text"
                               class="form-control @error('university_name') is-invalid @enderror"
                               id="university_name"
                               name="university_name"
                               value="{{ old('university_name', $settings->university_name ?? '') }}"
                               placeholder="University of Computer Studies">
                        @error('university_name')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="department_name" class="form-label">Department Name</label>
                        <input type="text"
                               class="form-control @error('department_name') is-invalid @enderror"
                               id="department_name"
                               name="department_name"
                               value="{{ old('department_name', $settings->department_name ?? '') }}"
                               placeholder="Department of Computer Science">
                        @error('department_name')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="academic_year" class="form-label">Academic Year</label>
                        <input type="text"
                               class="form-control @error('academic_year') is-invalid @enderror"
                               id="academic_year"
                               name="academic_year"
                               value="{{ old('academic_year', $settings->academic_year ?? '') }}"
                               placeholder="e.g., 2025-2026">
                        @error('academic_year')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="student_registration" class="form-label">Student Registration</label>
                        <select name="student_registration" id="student_registration" class="form-select">
                            <option value="open" {{ (old('student_registration', $settings->student_registration ?? 'open') == 'open') ? 'selected' : '' }}>Open</option>
                            <option value="closed" {{ (old('student_registration', $settings->student_registration ?? '') == 'closed') ? 'selected' : '' }}>Closed</option>
                        </select>
                        <div class="field-help">Closed blocks new student registration while existing users can continue.</div>
                    </div>
                </div>

                <div class="mb-4">
                    <label for="system_status" class="form-label">System Status</label>
                    <select name="system_status" id="system_status" class="form-select">
                        <option value="active" {{ (old('system_status', $settings->system_status ?? 'active') == 'active') ? 'selected' : '' }}>Active</option>
                        <option value="maintenance" {{ (old('system_status', $settings->system_status ?? '') == 'maintenance') ? 'selected' : '' }}>Maintenance</option>
                    </select>
                    <div class="field-help">Maintenance mode blocks non-admin users through the existing system-status middleware.</div>
                </div>

                <div class="settings-section-title mt-4">
                    <i class="fas fa-address-book me-2 text-primary"></i>Contact Information
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email"
                               class="form-control @error('email') is-invalid @enderror"
                               id="email"
                               name="email"
                               value="{{ old('email', $settings->email ?? '') }}"
                               placeholder="department@example.edu">
                        @error('email')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="text"
                               class="form-control @error('phone') is-invalid @enderror"
                               id="phone"
                               name="phone"
                               value="{{ old('phone', $settings->phone ?? '') }}"
                               placeholder="+95 9 123 456 789">
                        @error('phone')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="mb-4">
                    <label for="address" class="form-label">Address</label>
                    <textarea class="form-control @error('address') is-invalid @enderror"
                              id="address"
                              name="address"
                              placeholder="Department office, campus address, city">{{ old('address', $settings->address ?? '') }}</textarea>
                    @error('address')
                        <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                </div>

                <div class="settings-section-title mt-4">
                    <i class="fas fa-image me-2 text-primary"></i>Brand Images
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="logo" class="form-label">Logo</label>
                        <input type="file"
                               class="form-control @error('logo') is-invalid @enderror"
                               id="logo"
                               name="logo"
                               accept=".jpg,.jpeg,.png,.gif,.svg,image/*">
                        <div class="field-help">Recommended for header and email branding. Uploading a new file preserves the old file on disk.</div>
                        @if($settings->logo)
                            <div class="current-image">
                                <img src="{{ asset('storage/' . $settings->logo) }}" alt="Current logo">
                                <span>Current logo</span>
                            </div>
                        @endif
                        @error('logo')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="favicon" class="form-label">Favicon</label>
                        <input type="file"
                               class="form-control @error('favicon') is-invalid @enderror"
                               id="favicon"
                               name="favicon"
                               accept=".ico,.png,image/x-icon,image/png">
                        <div class="field-help">Recommended size: square PNG or ICO.</div>
                        @if($settings->favicon)
                            <div class="current-image">
                                <img src="{{ asset('storage/' . $settings->favicon) }}" alt="Current favicon">
                                <span>Current favicon</span>
                            </div>
                        @endif
                        @error('favicon')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="settings-actions">
                    <button type="submit" class="btn btn-primary save-btn">
                        <i class="fas fa-save me-2"></i> Save
                    </button>
                    <button type="submit" form="settings-reset-form" class="btn btn-outline-secondary rounded-pill px-4">
                        <i class="fas fa-rotate-left me-2"></i> Reset Defaults
                    </button>
                </div>
            </form>

            <form id="settings-reset-form"
                  action="{{ route('admin.settings.reset') }}"
                  method="POST"
                  onsubmit="return confirm('Reset text/status settings to defaults? Uploaded files will be preserved.');">
                @csrf
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const currentYear = new Date().getFullYear();
        const nextYear = currentYear + 1;
        const scenarios = {
            academic: {
                academic_year: `${currentYear}-${nextYear}`,
                student_registration: 'open',
                system_status: 'active'
            },
            review: {
                student_registration: 'closed',
                system_status: 'active'
            },
            maintenance: {
                student_registration: 'closed',
                system_status: 'maintenance'
            },
            department: {
                system_name: 'Thesis Management System',
                university_name: 'University of Computer Studies',
                department_name: 'Department of Computer Science',
                email: 'department@example.edu',
                phone: '+95 9 123 456 789',
                address: 'Department office, university campus'
            }
        };

        document.querySelectorAll('[data-scenario]').forEach(function (button) {
            button.addEventListener('click', function () {
                const scenario = scenarios[button.dataset.scenario] || {};
                Object.entries(scenario).forEach(function ([field, value]) {
                    const input = document.getElementById(field);
                    if (input) {
                        input.value = value;
                        input.dispatchEvent(new Event('change'));
                    }
                });
            });
        });
    });
</script>
@endpush
@endsection
