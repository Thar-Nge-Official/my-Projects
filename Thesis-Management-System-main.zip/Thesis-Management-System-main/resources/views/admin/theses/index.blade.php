@extends('layouts.app')

@section('title', 'All Theses')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2><i class="fas fa-file-alt"></i> All Theses</h2>
                    <p class="text-muted mb-0">View and manage all theses in the system</p>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Student</th>
                                    <th>Supervisor</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($theses as $thesis)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ Str::limit($thesis->title, 30) }}</td>
                                        <td>{{ $thesis->student->name ?? 'N/A' }}</td>
                                        <td>{{ $thesis->supervisor->name ?? 'N/A' }}</td>
                                        <td>{{ $thesis->category->name ?? 'N/A' }}</td>
                                        <td>
                                            <span class="badge bg-{{ $thesis->status == 'approved' ? 'success' : ($thesis->status == 'rejected' ? 'danger' : 'warning') }}">
                                                {{ ucfirst($thesis->status) }}
                                            </span>
                                        </td>
                                        <td>
                                            <a href="{{ route('admin.theses.view', $thesis) }}" class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <form action="{{ route('admin.theses.delete', $thesis) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">
                                            <i class="fas fa-file-alt fa-3x d-block mb-3"></i>
                                            <h5>No theses found</h5>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    @if($theses->hasPages())
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <div>Showing {{ $theses->firstItem() }} to {{ $theses->lastItem() }} of {{ $theses->total() }}</div>
                            <div>{{ $theses->links() }}</div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection