@extends('layouts.app')

@section('title', 'Manage Categories')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- ============================================ -->
            <!-- HEADER WITH SEARCH BAR -->
            <!-- ============================================ -->
            <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mb-4">
                <div>
                    <h2><i class="fas fa-tags"></i> Manage Categories</h2>
                    <p class="text-muted mb-0">Manage thesis categories for the system</p>
                </div>
                
                <!-- Search + Add Button Group -->
                <div class="d-flex gap-2 mt-2 mt-sm-0">
                    <!-- Real-time Search Input -->
                    <div class="input-group" style="width: 280px;">
                        <span class="input-group-text bg-white">
                            <i class="fas fa-search text-primary"></i>
                        </span>
                        <input type="text" 
                               class="form-control" 
                               id="searchInput" 
                               placeholder="Search categories..." 
                               value="{{ request('search') }}"
                               style="border-left: none;">
                        @if(request('search'))
                            <a href="{{ route('admin.categories') }}" class="btn btn-outline-secondary" title="Clear search">
                                <i class="fas fa-times"></i>
                            </a>
                        @endif
                    </div>
                    
                    <a href="{{ route('admin.categories.create') }}" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add Category
                    </a>
                </div>
            </div>

            <!-- ============================================ -->
            <!-- SEARCH RESULTS INFO -->
            <!-- ============================================ -->
            <div id="searchInfo">
                @if(request('search'))
                    <div class="alert alert-info alert-dismissible fade show">
                        <i class="fas fa-info-circle"></i> 
                        Showing results for: <strong>"{{ request('search') }}"</strong>
                        <span class="badge bg-primary ms-2">{{ $categories->total() }} results found</span>
                        <a href="{{ route('admin.categories') }}" class="btn btn-sm btn-outline-secondary ms-2">
                            <i class="fas fa-times"></i> Clear Search
                        </a>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif
            </div>

            <!-- ============================================ -->
            <!-- CATEGORIES TABLE -->
            <!-- ============================================ -->
            <div class="card">
                <div class="card-body">
                    <div id="categoriesTable">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Theses Count</th>
                                        <th>Created Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tableBody">
                                    @forelse($categories as $category)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td><strong>{{ $category->name }}</strong></td>
                                            <td>{{ Str::limit($category->description ?? 'N/A', 50) }}</td>
                                            <td>
                                                <span class="badge bg-info">{{ $category->theses->count() }}</span>
                                            </td>
                                            <td>{{ $category->created_at->format('d/m/Y') }}</td>
                                            <td>
                                                <a href="{{ route('admin.categories.edit', $category) }}" class="btn btn-sm btn-primary" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="{{ route('admin.categories.destroy', $category) }}" method="POST" class="d-inline">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this category?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center text-muted py-4">
                                                <i class="fas fa-folder-open fa-3x d-block mb-3"></i>
                                                <h5>No categories found</h5>
                                                @if(request('search'))
                                                    <p class="mb-0">No results found for "<strong>{{ request('search') }}</strong>"</p>
                                                    <a href="{{ route('admin.categories') }}" class="btn btn-sm btn-primary mt-2">
                                                        <i class="fas fa-undo"></i> Clear Search
                                                    </a>
                                                @else
                                                    <p class="mb-0">Click "Add Category" to create your first category.</p>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        @if($categories->hasPages() || $categories->total() > 0)
                            <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mt-3 pt-2 border-top">
                                <div class="pagination-info">
                                    <i class="fas fa-info-circle"></i>
                                    Showing 
                                    <strong>{{ $categories->firstItem() ?? 0 }}</strong> 
                                    to 
                                    <strong>{{ $categories->lastItem() ?? 0 }}</strong> 
                                    of 
                                    <strong>{{ $categories->total() }}</strong> 
                                    results
                                    @if(request('search'))
                                        <span class="text-muted">(filtered)</span>
                                    @endif
                                </div>
                                <div>
                                    {{ $categories->links('pagination::bootstrap-5') }}
                                </div>
                            </div>
                        @else
                            <div class="text-center text-muted mt-3">
                                <small>Total: <strong>{{ $categories->total() }}</strong> categories</small>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- LOADING SPINNER -->
<!-- ============================================ -->
<div id="loadingSpinner" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999;">
    <div class="spinner-border text-primary" role="status" style="width: 50px; height: 50px;">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        const tableContainer = document.getElementById('categoriesTable');
        const searchInfo = document.getElementById('searchInfo');
        const spinner = document.getElementById('loadingSpinner');
        let searchTimeout;

        if (!searchInput) {
            console.error('Search input not found!');
            return;
        }

        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const search = this.value;
            
            // Show spinner
            spinner.style.display = 'block';
            
            searchTimeout = setTimeout(function() {
                performSearch(search);
            }, 500);
        });

        function performSearch(search) {
            let url = "{{ route('admin.categories') }}";
            if (search.length > 0) {
                url += '?search=' + encodeURIComponent(search);
            }
            
            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.text())
            .then(html => {
                spinner.style.display = 'none';
                
                // Create temporary element to parse HTML
                const temp = document.createElement('div');
                temp.innerHTML = html;
                
                // Update table
                const newTable = temp.querySelector('#categoriesTable');
                if (newTable) {
                    tableContainer.innerHTML = newTable.innerHTML;
                }
                
                // Update search info
                const newInfo = temp.querySelector('#searchInfo');
                if (newInfo) {
                    searchInfo.innerHTML = newInfo.innerHTML;
                }
                
                // Update URL
                if (search.length > 0) {
                    window.history.pushState({}, '', '?search=' + encodeURIComponent(search));
                } else {
                    window.history.pushState({}, '', '{{ route('admin.categories') }}');
                }
            })
            .catch(error => {
                console.error('Search error:', error);
                spinner.style.display = 'none';
            });
        }

        // Handle back/forward buttons
        window.addEventListener('popstate', function() {
            location.reload();
        });
    });
</script>
@endpush