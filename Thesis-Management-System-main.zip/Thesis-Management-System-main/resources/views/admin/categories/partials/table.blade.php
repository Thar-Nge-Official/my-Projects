<!-- ============================================ -->
<!-- SEARCH RESULTS INFO -->
<!-- ============================================ -->
@if(request('search'))
    <div id="searchInfo">
        <div class="alert alert-info alert-dismissible fade show">
            <i class="fas fa-info-circle"></i> 
            Showing results for: <strong>"{{ request('search') }}"</strong>
            <span class="badge bg-primary ms-2">{{ $categories->total() }} results found</span>
            <a href="{{ route('admin.categories') }}" class="btn btn-sm btn-outline-secondary ms-2">
                <i class="fas fa-times"></i> Clear Search
            </a>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
@else
    <div id="searchInfo"></div>
@endif

<!-- ============================================ -->
<!-- CATEGORIES TABLE -->
<!-- ============================================ -->
<div id="categoriesTable">
    <div class="table-responsive">
        <table class="table table-hover" id="categoryTable">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Theses Count</th>
                    <th>Created Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="tableBody">
                @forelse($categories as $category)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td><strong>{{ $category->name }}</strong></td>
                        <td>{{ Str::limit($category->description ?? 'N/A', 50) }}</td>
                        <td>
                            <span class="badge bg-info">{{ $category->theses->count() }}</span>
                        </td>
                        <td>{{ $category->created_at->format('d/m/Y') }}</td>
                        <td>
                            <a href="{{ route('admin.categories.edit', $category) }}" class="btn btn-sm btn-primary" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="{{ route('admin.categories.destroy', $category) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this category?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="fas fa-folder-open fa-3x d-block mb-3"></i>
                            <h5>No categories found</h5>
                            @if(request('search'))
                                <p class="mb-0">No results found for "<strong>{{ request('search') }}</strong>"</p>
                                <a href="{{ route('admin.categories') }}" class="btn btn-sm btn-primary mt-2">
                                    <i class="fas fa-undo"></i> Clear Search
                                </a>
                            @else
                                <p class="mb-0">Click "Add Category" to create your first category.</p>
                            @endif
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    @if($categories->hasPages() || $categories->total() > 0)
        <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mt-3 pt-2 border-top">
            <div class="pagination-info">
                <i class="fas fa-info-circle"></i>
                Showing 
                <strong>{{ $categories->firstItem() ?? 0 }}</strong> 
                to 
                <strong>{{ $categories->lastItem() ?? 0 }}</strong> 
                of 
                <strong>{{ $categories->total() }}</strong> 
                results
                @if(request('search'))
                    <span class="text-muted">(filtered)</span>
                @endif
            </div>
            <div id="paginationLinks">
                {{ $categories->links('pagination::bootstrap-5') }}
            </div>
        </div>
    @else
        <div class="text-center text-muted mt-3">
            <small>Total: <strong>{{ $categories->total() }}</strong> categories</small>
        </div>
    @endif
</div>