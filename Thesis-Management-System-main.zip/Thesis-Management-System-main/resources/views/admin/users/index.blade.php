@extends('layouts.app')

@section('title', 'Manage Users')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- HEADER -->
            <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mb-4">
                <div>
                    <h2><i class="fas fa-users"></i> Manage Users</h2>
                    <p class="text-muted mb-0">Manage all users in the system</p>
                </div>
                
                <div class="d-flex gap-2 mt-2 mt-sm-0">
                    <!-- Search -->
                    <div class="input-group" style="width: 250px;">
                        <span class="input-group-text bg-white">
                            <i class="fas fa-search text-primary"></i>
                        </span>
                        <input type="text" 
                               class="form-control" 
                               id="searchInput" 
                               placeholder="Search users..." 
                               value="{{ request('search') }}"
                               style="border-left: none;">
                        @if(request('search'))
                            <a href="{{ route('admin.users') }}" class="btn btn-outline-secondary" title="Clear search">
                                <i class="fas fa-times"></i>
                            </a>
                        @endif
                    </div>
                    
                    <a href="{{ route('admin.users.create') }}" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add User
                    </a>
                </div>
            </div>

            <!-- ROLE FILTER -->
            <div class="card mb-4">
                <div class="card-body py-2">
                    <div class="d-flex flex-wrap gap-2 align-items-center">
                        <span class="fw-bold me-2">Filter by Role:</span>
                        <a href="{{ route('admin.users') }}" class="btn btn-sm {{ !request('role') ? 'btn-primary' : 'btn-outline-secondary' }}">
                            All
                        </a>
                        <a href="{{ route('admin.users', ['role' => 'student']) }}" class="btn btn-sm {{ request('role') == 'student' ? 'btn-primary' : 'btn-outline-secondary' }}">
                            <i class="fas fa-user-graduate"></i> Students
                        </a>
                        <a href="{{ route('admin.users', ['role' => 'supervisor']) }}" class="btn btn-sm {{ request('role') == 'supervisor' ? 'btn-primary' : 'btn-outline-secondary' }}">
                            <i class="fas fa-chalkboard-teacher"></i> Supervisors
                        </a>
                        <a href="{{ route('admin.users', ['role' => 'admin']) }}" class="btn btn-sm {{ request('role') == 'admin' ? 'btn-primary' : 'btn-outline-secondary' }}">
                            <i class="fas fa-user-shield"></i> Admins
                        </a>
                    </div>
                </div>
            </div>

            @if(isset($selectedSupervisor) && $selectedSupervisor)
                <div class="alert alert-info alert-dismissible fade show border-0 shadow-sm mb-4">
                    <i class="fas fa-users me-2"></i>
                    Showing students supervised by
                    <strong>{{ $selectedSupervisor->firstname }} {{ $selectedSupervisor->lastname }}</strong>
                    <span class="badge bg-primary ms-2">{{ $users->total() }} student(s)</span>
                    <a href="{{ route('admin.users', ['role' => 'supervisor']) }}" class="btn btn-sm btn-outline-secondary ms-2">
                        <i class="fas fa-arrow-left"></i> Back to Supervisors
                    </a>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            <!-- SEARCH INFO -->
            <div id="searchInfo">
                @if(request('search'))
                    <div class="alert alert-info alert-dismissible fade show">
                        <i class="fas fa-info-circle"></i> 
                        Showing results for: <strong>"{{ request('search') }}"</strong>
                        <span class="badge bg-primary ms-2">{{ $users->total() }} results found</span>
                        <a href="{{ route('admin.users') }}" class="btn btn-sm btn-outline-secondary ms-2">
                            <i class="fas fa-times"></i> Clear Search
                        </a>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif
            </div>

            <!-- USERS TABLE -->
            <div class="card">
                <div class="card-body">
                    <div id="usersTable">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Avatar</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Students</th>
                                        <th>Rank</th>
                                        <th>Roll No</th>
                                        <th>Class</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($users as $user)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>
                                                <div class="avatar-container" style="width: 40px; height: 40px; border-radius: 50%; overflow: hidden; border: 2px solid #e9ecef;">
                                                    @php
                                                        $avatarUrl = ($user->avatar && $user->avatar != 'no-image-available.png') ? ('/storage/avatars/' . rawurlencode($user->avatar)) : null;
                                                    @endphp
                                                    @if($avatarUrl)
                                                        <img src="{{ $avatarUrl }}" 
                                                             alt="{{ $user->firstname }}" 
                                                             style="width: 100%; height: 100%; object-fit: cover;">
                                                    @else
                                                        <div class="avatar-placeholder" style="width: 100%; height: 100%; background: #0d6efd; display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 16px;">
                                                            {{ strtoupper(substr($user->firstname, 0, 1)) }}
                                                        </div>
                                                    @endif
                                                </div>
                                            </td>
                                            <td>
                                                <strong>{{ $user->firstname }} {{ $user->lastname }}</strong>
                                            </td>
                                            <td>{{ $user->email }}</td>
                                            <td>
                                                <span class="badge bg-{{ $user->type == 'admin' ? 'danger' : ($user->type == 'supervisor' ? 'warning' : 'info') }}">
                                                    {{ ucfirst($user->type) }}
                                                </span>
                                            </td>
                                            <td>
                                                @if($user->type === 'supervisor')
                                                    @if(($user->supervised_students_count ?? 0) > 0)
                                                        <a href="{{ route('admin.users', ['role' => 'student', 'supervisor_id' => $user->id]) }}"
                                                           class="fw-bold text-decoration-none"
                                                           title="View supervised students">
                                                            {{ $user->supervised_students_count }}
                                                        </a>
                                                    @else
                                                        <strong>0</strong>
                                                    @endif
                                                @else
                                                    <span class="text-muted">—</span>
                                                @endif
                                            </td>
                                            <td>
                                                @if($user->type === 'student')
                                                    <span class="text-muted">N/A</span>
                                                @elseif($user->type === 'admin')
                                                    <span class="text-primary">{{ $user->rank ?? 'Professor and Head' }}</span>
                                                @else
                                                    <span>{{ $user->rank ?? 'N/A' }}</span>
                                                @endif
                                            </td>
                                            <td>{{ $user->roll_no ?? 'N/A' }}</td>
                                            <td>{{ $user->class ?? 'N/A' }}</td>
                                            <td>{{ $user->created_at->format('d/m/Y') }}</td>
                                            <td>
                                                <a href="{{ route('admin.users.edit', $user) }}" class="btn btn-sm btn-primary" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>

                                                

                                                <form action="{{ route('admin.users.delete', $user) }}" method="POST" class="d-inline">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="11" class="text-center text-muted py-4">
                                                <i class="fas fa-users fa-3x d-block mb-3"></i>
                                                <h5>No users found</h5>
                                                @if(request('search'))
                                                    <p class="mb-0">No results found for "<strong>{{ request('search') }}</strong>"</p>
                                                    <a href="{{ route('admin.users') }}" class="btn btn-sm btn-primary mt-2">
                                                        <i class="fas fa-undo"></i> Clear Search
                                                    </a>
                                                @else
                                                    <p class="mb-0">Click "Add User" to create your first user.</p>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        @if($users->hasPages() || $users->total() > 0)
                            <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mt-3 pt-2 border-top">
                                <div class="pagination-info">
                                    <i class="fas fa-info-circle"></i>
                                    Showing 
                                    <strong>{{ $users->firstItem() ?? 0 }}</strong> 
                                    to 
                                    <strong>{{ $users->lastItem() ?? 0 }}</strong> 
                                    of 
                                    <strong>{{ $users->total() }}</strong> 
                                    results
                                    @if(request('search'))
                                        <span class="text-muted">(filtered)</span>
                                    @endif
                                </div>
                                <div>
                                    {{ $users->appends(request()->query())->links('pagination::bootstrap-5') }}
                                </div>
                            </div>
                        @else
                            <div class="text-center text-muted mt-3">
                                <small>Total: <strong>{{ $users->total() }}</strong> users</small>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Loading Spinner -->
<div id="loadingSpinner" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999;">
    <div class="spinner-border text-primary" role="status" style="width: 50px; height: 50px;">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
@endsection

<!-- Regenerate QR Modal -->
<div class="modal fade" id="regenerateQrModal" tabindex="-1">
    <div class="modal-dialog">
        <form id="regenerateQrForm" method="POST" action="">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Generate QR Again</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Provide a new temporary password to regenerate the user's QR code. This will update the user's password.</p>

                    <div class="mb-3">
                        <label class="form-label">User</label>
                        <input type="text" id="regenerateUserName" class="form-control" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">New Password <span class="text-danger">*</span></label>
                        <input type="password" name="new_password" id="new_password" class="form-control" required minlength="8">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Confirm Password <span class="text-danger">*</span></label>
                        <input type="password" name="new_password_confirmation" id="new_password_confirmation" class="form-control" required minlength="8">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Regenerate QR &amp; Update Password</button>
                </div>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        let searchTimeout;

        if (searchInput) {
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                
                searchTimeout = setTimeout(function() {
                    const search = this.value;
                    const currentUrl = new URL(window.location.href);
                    const role = currentUrl.searchParams.get('role') || '';
                    const supervisorId = currentUrl.searchParams.get('supervisor_id') || '';
                    
                    let url = "{{ route('admin.users') }}";
                    const params = new URLSearchParams();
                    
                    if (search && search.trim() !== '') {
                        params.set('search', search.trim());
                    }
                    if (role) {
                        params.set('role', role);
                    }
                    if (supervisorId) {
                        params.set('supervisor_id', supervisorId);
                    }
                    
                    if (params.toString()) {
                        url += '?' + params.toString();
                    }
                    
                    window.location.href = url;
                }.bind(this), 500);
            });
        }

        // Role filter buttons - preserve search
        document.querySelectorAll('.btn-filter').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const role = this.dataset.role || '';
                const search = searchInput ? searchInput.value : '';
                
                let url = "{{ route('admin.users') }}";
                const params = new URLSearchParams();
                if (search && search.trim() !== '') params.set('search', search.trim());
                if (role) params.set('role', role);
                if (params.toString()) url += '?' + params.toString();
                
                window.location.href = url;
            });
        });

        // Regenerate QR button handler
        const regenerateButtons = document.querySelectorAll('.btn-regenerate-qr');
        const modal = new bootstrap.Modal(document.getElementById('regenerateQrModal'));
        const form = document.getElementById('regenerateQrForm');
        const userNameInput = document.getElementById('regenerateUserName');

        regenerateButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const userId = this.dataset.userId;
                const userName = this.dataset.userName;

                // Set form action
                form.action = "{{ url('/admin/users') }}" + '/' + userId + '/regenerate-qr';

                // Set user name in modal
                userNameInput.value = userName;

                // Show modal
                modal.show();
            });
        });
    });
</script>
@endpush
