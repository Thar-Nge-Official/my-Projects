@extends('layouts.app')

@section('title', 'Edit User')

@section('content')
@php
    $currentRole = old('type', $user->type);
    $status = $user->registration_status ?? 'active';
    $avatarUrl = ($user->avatar && $user->avatar != 'no-image-available.png')
        ? asset('storage/avatars/' . rawurlencode($user->avatar))
        : null;
    $initial = strtoupper(substr($user->firstname ?? 'U', 0, 1));
    $roleBadge = $user->type == 'admin' ? 'danger' : ($user->type == 'supervisor' ? 'warning' : 'info');
    $statusBadge = $status == 'approved' || $status == 'active' ? 'success' : ($status == 'pending' ? 'warning' : 'secondary');
@endphp

<div class="admin-user-edit-page">
    <div class="container-fluid px-4 py-4">
        <div class="page-header mb-4">
            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">
                <div>
                    <h1 class="h3 mb-1 fw-bold text-dark">
                        <i class="fas fa-user-edit text-primary me-2"></i>Edit User
                    </h1>
                    <p class="text-muted mb-0">Update account details, role information, and profile photo.</p>
                </div>
                <a href="{{ route('admin.users') }}" class="btn btn-outline-secondary rounded-pill px-4">
                    <i class="fas fa-arrow-left me-2"></i>Back to Users
                </a>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-xl-4">
                <div class="profile-summary-card glassmorphism h-100 overflow-hidden">
                    <div class="profile-cover bg-gradient-primary"></div>
                    <div class="profile-content text-center px-4 pb-4">
                        <div class="profile-avatar-wrapper">
                            <div class="profile-avatar">
                                @if($avatarUrl)
                                    <img src="{{ $avatarUrl }}" alt="{{ $user->firstname }}" class="avatar-img">
                                @else
                                    <span>{{ $initial }}</span>
                                @endif
                            </div>
                        </div>

                        <h2 class="h4 fw-bold text-dark mb-1">{{ $user->full_name }}</h2>
                        <p class="text-muted mb-3">{{ $user->email }}</p>

                        <div class="d-flex justify-content-center flex-wrap gap-2 mb-4">
                            <span class="badge bg-{{ $roleBadge }} rounded-pill px-3 py-2">{{ ucfirst($user->type) }}</span>
                            <span class="badge bg-{{ $statusBadge }} rounded-pill px-3 py-2">{{ ucfirst($status) }}</span>
                        </div>

                        <div class="user-detail-list text-start">
                            <div class="detail-item">
                                <div class="detail-icon bg-gradient-info">
                                    <i class="fas fa-id-card"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">User ID</small>
                                    <strong>#{{ $user->id }}</strong>
                                </div>
                            </div>

                            @if($user->type == 'student')
                                <div class="detail-item">
                                    <div class="detail-icon bg-gradient-success">
                                        <i class="fas fa-graduation-cap"></i>
                                    </div>
                                    <div>
                                        <small class="text-muted d-block">Student Info</small>
                                        <strong>{{ $user->roll_no ?: 'No roll number' }}</strong>
                                        <span class="text-muted small d-block">{{ $user->class ?: 'No class assigned' }}</span>
                                    </div>
                                </div>
                            @endif

                            @if($user->type == 'supervisor')
                                <div class="detail-item">
                                    <div class="detail-icon bg-gradient-warning">
                                        <i class="fas fa-user-tie"></i>
                                    </div>
                                    <div>
                                        <small class="text-muted d-block">Supervisor Rank</small>
                                        <strong>{{ $user->rank ?: 'No rank assigned' }}</strong>
                                    </div>
                                </div>
                            @endif

                            <div class="detail-item">
                                <div class="detail-icon bg-gradient-primary">
                                    <i class="fas fa-calendar-alt"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Created</small>
                                    <strong>{{ optional($user->created_at)->format('M d, Y') ?: 'Unknown' }}</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-8">
                <form action="{{ route('admin.users.update', $user) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')

                    <div class="glassmorphism form-card mb-4">
                        <div class="card-header-custom">
                            <div class="header-icon bg-gradient-primary">
                                <i class="fas fa-address-card"></i>
                            </div>
                            <div>
                                <h3 class="h5 fw-bold mb-1">Account Information</h3>
                                <p class="text-muted mb-0">Primary user profile and login identity.</p>
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control @error('firstname') is-invalid @enderror"
                                           id="firstname" name="firstname" value="{{ old('firstname', $user->firstname) }}"
                                           placeholder="First Name" required>
                                    <label for="firstname">First Name *</label>
                                    @error('firstname')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control @error('lastname') is-invalid @enderror"
                                           id="lastname" name="lastname" value="{{ old('lastname', $user->lastname) }}"
                                           placeholder="Last Name" required>
                                    <label for="lastname">Last Name *</label>
                                    @error('lastname')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="email" class="form-control @error('email') is-invalid @enderror"
                                           id="email" name="email" value="{{ old('email', $user->email) }}"
                                           placeholder="Email Address" required>
                                    <label for="email">Email Address *</label>
                                    @error('email')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12">
                                <label for="avatar" class="form-label fw-semibold text-dark">Profile Picture</label>
                                <input type="file" class="form-control custom-file-input @error('avatar') is-invalid @enderror"
                                       id="avatar" name="avatar" accept="image/*">
                                @error('avatar')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <div class="form-text">Upload a new profile picture up to 2MB.</div>
                            </div>
                        </div>
                    </div>

                    <div class="glassmorphism form-card mb-4">
                        <div class="card-header-custom">
                            <div class="header-icon bg-gradient-info">
                                <i class="fas fa-user-shield"></i>
                            </div>
                            <div>
                                <h3 class="h5 fw-bold mb-1">Role Details</h3>
                                <p class="text-muted mb-0">Control the dashboard access and role-specific fields.</p>
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-12">
                                <div class="form-floating">
                                    <select class="form-select @error('type') is-invalid @enderror" id="type" name="type" required>
                                        <option value="student" {{ $currentRole == 'student' ? 'selected' : '' }}>Student</option>
                                        <option value="supervisor" {{ $currentRole == 'supervisor' ? 'selected' : '' }}>Supervisor</option>
                                        <option value="admin" {{ $currentRole == 'admin' ? 'selected' : '' }}>Admin</option>
                                    </select>
                                    <label for="type">Role *</label>
                                    @error('type')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-12" id="studentFields" style="{{ $currentRole == 'student' ? 'display: block;' : 'display: none;' }}">
                                <div class="role-panel">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="text" class="form-control" id="roll_no" name="roll_no"
                                                       value="{{ old('roll_no', $user->roll_no) }}" placeholder="Roll Number">
                                                <label for="roll_no">Roll Number</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="text" class="form-control" id="class" name="class"
                                                       value="{{ old('class', $user->class) }}" placeholder="Class">
                                                <label for="class">Class</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12" id="supervisorFields" style="{{ $currentRole == 'supervisor' ? 'display: block;' : 'display: none;' }}">
                                <div class="role-panel">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="rank" name="rank"
                                               value="{{ old('rank', $user->rank) }}"
                                               placeholder="e.g., Professor, Associate Professor">
                                        <label for="rank">Rank</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="glassmorphism form-card">
                        <div class="card-header-custom">
                            <div class="header-icon bg-gradient-warning">
                                <i class="fas fa-lock"></i>
                            </div>
                            <div>
                                <h3 class="h5 fw-bold mb-1">Password</h3>
                                <p class="text-muted mb-0">Leave both password fields blank to keep the current password.</p>
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="password" class="form-control @error('password') is-invalid @enderror"
                                           id="password" name="password" placeholder="New Password">
                                    <label for="password">New Password</label>
                                    @error('password')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="password" class="form-control" id="password_confirmation"
                                           name="password_confirmation" placeholder="Confirm Password">
                                    <label for="password_confirmation">Confirm Password</label>
                                </div>
                            </div>
                        </div>

                        <div class="action-bar d-flex flex-column flex-sm-row justify-content-sm-end gap-2 mt-4">
                            <a href="{{ route('admin.users') }}" class="btn btn-light rounded-pill px-4">
                                <i class="fas fa-times me-2"></i>Cancel
                            </a>
                            <button type="reset" class="btn btn-outline-secondary rounded-pill px-4">
                                <i class="fas fa-undo me-2"></i>Reset
                            </button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4">
                                <i class="fas fa-save me-2"></i>Update User
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .admin-user-edit-page {
        background: linear-gradient(135deg, #f8fafc 0%, #eef3f8 100%);
        min-height: calc(100vh - 70px);
    }

    .admin-user-edit-page .glassmorphism {
        background: rgba(255, 255, 255, 0.88);
        backdrop-filter: blur(14px);
        border: 1px solid rgba(255, 255, 255, 0.55);
        border-radius: 18px;
        box-shadow: 0 18px 45px rgba(15, 23, 42, 0.08);
    }

    .admin-user-edit-page .page-header {
        background: rgba(255, 255, 255, 0.72);
        border: 1px solid rgba(226, 232, 240, 0.8);
        border-radius: 18px;
        padding: 1.5rem;
        box-shadow: 0 10px 30px rgba(15, 23, 42, 0.05);
    }

    .admin-user-edit-page .profile-summary-card {
        position: sticky;
        top: 1rem;
    }

    .admin-user-edit-page .profile-cover {
        height: 130px;
    }

    .admin-user-edit-page .profile-content {
        margin-top: -58px;
    }

    .admin-user-edit-page .profile-avatar-wrapper {
        display: flex;
        justify-content: center;
        margin-bottom: 1rem;
    }

    .admin-user-edit-page .profile-avatar {
        align-items: center;
        background: #fff;
        border: 5px solid #fff;
        border-radius: 50%;
        box-shadow: 0 12px 30px rgba(15, 23, 42, 0.18);
        color: #fff;
        display: flex;
        font-size: 2.4rem;
        font-weight: 800;
        height: 116px;
        justify-content: center;
        overflow: hidden;
        width: 116px;
    }

    .admin-user-edit-page .profile-avatar span {
        align-items: center;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        height: 100%;
        justify-content: center;
        width: 100%;
    }

    .admin-user-edit-page .avatar-img {
        height: 100%;
        object-fit: cover;
        width: 100%;
    }

    .admin-user-edit-page .user-detail-list {
        display: grid;
        gap: 0.9rem;
    }

    .admin-user-edit-page .detail-item {
        align-items: center;
        background: rgba(248, 250, 252, 0.78);
        border: 1px solid rgba(226, 232, 240, 0.8);
        border-radius: 14px;
        display: flex;
        gap: 0.85rem;
        padding: 0.9rem;
    }

    .admin-user-edit-page .detail-icon,
    .admin-user-edit-page .header-icon {
        align-items: center;
        border-radius: 14px;
        color: #fff;
        display: inline-flex;
        flex-shrink: 0;
        height: 44px;
        justify-content: center;
        width: 44px;
    }

    .admin-user-edit-page .form-card {
        padding: 1.5rem;
    }

    .admin-user-edit-page .card-header-custom {
        align-items: center;
        border-bottom: 1px solid rgba(226, 232, 240, 0.9);
        display: flex;
        gap: 1rem;
        margin-bottom: 1.5rem;
        padding-bottom: 1.25rem;
    }

    .admin-user-edit-page .form-floating > .form-control,
    .admin-user-edit-page .form-floating > .form-select,
    .admin-user-edit-page .custom-file-input {
        border: 1px solid rgba(203, 213, 225, 0.9);
        border-radius: 14px;
        box-shadow: none;
    }

    .admin-user-edit-page .form-floating > .form-control:focus,
    .admin-user-edit-page .form-floating > .form-select:focus,
    .admin-user-edit-page .custom-file-input:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.16);
    }

    .admin-user-edit-page .role-panel {
        background: rgba(248, 250, 252, 0.74);
        border: 1px solid rgba(226, 232, 240, 0.86);
        border-radius: 16px;
        padding: 1rem;
    }

    .admin-user-edit-page .btn {
        font-weight: 700;
        min-height: 42px;
    }

    .admin-user-edit-page .btn-primary {
        background: linear-gradient(135deg, #667eea 0%, #5b6fe6 100%);
        border: none;
        box-shadow: 0 10px 24px rgba(102, 126, 234, 0.24);
    }

    .admin-user-edit-page .btn-primary:hover {
        box-shadow: 0 12px 28px rgba(102, 126, 234, 0.32);
        transform: translateY(-1px);
    }

    .admin-user-edit-page .bg-gradient-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    }

    .admin-user-edit-page .bg-gradient-success {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%) !important;
    }

    .admin-user-edit-page .bg-gradient-info {
        background: linear-gradient(135deg, #2193b0 0%, #6dd5ed 100%) !important;
    }

    .admin-user-edit-page .bg-gradient-warning {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%) !important;
    }

    @media (max-width: 1199.98px) {
        .admin-user-edit-page .profile-summary-card {
            position: static;
        }
    }

    @media (max-width: 575.98px) {
        .admin-user-edit-page .container-fluid {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
        }

        .admin-user-edit-page .page-header,
        .admin-user-edit-page .form-card {
            padding: 1.1rem;
        }

        .admin-user-edit-page .card-header-custom {
            align-items: flex-start;
        }
    }
</style>

@push('scripts')
<script>
    document.getElementById('type').addEventListener('change', function() {
        const studentFields = document.getElementById('studentFields');
        const supervisorFields = document.getElementById('supervisorFields');

        if (this.value === 'student') {
            studentFields.style.display = 'block';
            supervisorFields.style.display = 'none';
        } else if (this.value === 'supervisor') {
            studentFields.style.display = 'none';
            supervisorFields.style.display = 'block';
        } else {
            studentFields.style.display = 'none';
            supervisorFields.style.display = 'none';
        }
    });
</script>
@endpush
@endsection
