@extends('layouts.app')

@section('title', 'Add User')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-user-plus"></i> Add New User</h4>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.users.store') }}" method="POST">
                        @csrf

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="firstname" class="form-label">First Name *</label>
                                <input type="text" class="form-control @error('firstname') is-invalid @enderror" 
                                       id="firstname" name="firstname" value="{{ old('firstname') }}" required>
                                @error('firstname')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="lastname" class="form-label">Last Name *</label>
                                <input type="text" class="form-control @error('lastname') is-invalid @enderror" 
                                       id="lastname" name="lastname" value="{{ old('lastname') }}" required>
                                @error('lastname')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email *</label>
                            <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                   id="email" name="email" value="{{ old('email') }}" required>
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="password" class="form-label">Password *</label>
                                <input type="password" class="form-control @error('password') is-invalid @enderror" 
                                       id="password" name="password" required>
                                @error('password')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="password_confirmation" class="form-label">Confirm Password *</label>
                                <input type="password" class="form-control" 
                                       id="password_confirmation" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="type" class="form-label">Role *</label>
                            <select class="form-select @error('type') is-invalid @enderror" id="type" name="type" required>
                                <option value="">Select Role</option>
                                <option value="student" {{ old('type') == 'student' ? 'selected' : '' }}>Student</option>
                                <option value="supervisor" {{ old('type') == 'supervisor' ? 'selected' : '' }}>Supervisor</option>
                                <option value="admin" {{ old('type') == 'admin' ? 'selected' : '' }}>Admin</option>
                            </select>
                            @error('type')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div id="studentFields" style="{{ old('type') == 'student' ? 'display: block;' : 'display: none;' }}">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="roll_no" class="form-label">Roll Number</label>
                                    <input type="text" class="form-control" id="roll_no" name="roll_no" value="{{ old('roll_no') }}">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="class" class="form-label">Class</label>
                                    <input type="text" class="form-control" id="class" name="class" value="{{ old('class') }}">
                                </div>
                            </div>
                        </div>

                        <div id="supervisorFields" style="{{ old('type') == 'supervisor' ? 'display: block;' : 'display: none;' }}">
                            <div class="mb-3">
                                <label for="rank" class="form-label">Rank</label>
                                <input type="text" class="form-control" id="rank" name="rank" value="{{ old('rank') }}" placeholder="e.g., Professor, Associate Professor">
                            </div>
                        </div>

                        <!-- ============================================ -->
                        <!-- ADMIN FIELDS -->
                        <!-- ============================================ -->
                        <div id="adminFields" style="{{ old('type') == 'admin' ? 'display: block;' : 'display: none;' }}">
                            <div class="mb-3">
                                <label for="rank" class="form-label">Rank</label>
                                <input type="text" class="form-control" id="admin_rank" name="rank" value="{{ old('rank', 'Professor and Head') }}" placeholder="Professor and Head">
                                <small class="text-muted text-primary">
                                    <i class="fas fa-info-circle"></i> Default rank for Admin is "Professor and Head"
                                </small>
                            </div>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="{{ route('admin.users') }}" class="btn btn-secondary me-2">Cancel</a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Create User
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
    document.getElementById('type').addEventListener('change', function() {
        const studentFields = document.getElementById('studentFields');
        const supervisorFields = document.getElementById('supervisorFields');
        const adminFields = document.getElementById('adminFields');
        
        if (this.value === 'student') {
            studentFields.style.display = 'block';
            supervisorFields.style.display = 'none';
            adminFields.style.display = 'none';
        } else if (this.value === 'supervisor') {
            studentFields.style.display = 'none';
            supervisorFields.style.display = 'block';
            adminFields.style.display = 'none';
        } else if (this.value === 'admin') {
            studentFields.style.display = 'none';
            supervisorFields.style.display = 'none';
            adminFields.style.display = 'block';
        } else {
            studentFields.style.display = 'none';
            supervisorFields.style.display = 'none';
            adminFields.style.display = 'none';
        }
    });
</script>
@endpush
@endsection