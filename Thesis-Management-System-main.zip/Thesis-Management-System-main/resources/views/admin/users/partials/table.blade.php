<!-- SEARCH INFO -->
<div id="searchInfo">
    @if(request('search'))
        <div class="alert alert-info alert-dismissible fade show">
            <i class="fas fa-info-circle"></i> 
            Showing results for: <strong>"{{ request('search') }}"</strong>
            <span class="badge bg-primary ms-2">{{ $users->total() }} results found</span>
            <a href="{{ route('admin.users') }}" class="btn btn-sm btn-outline-secondary ms-2">
                <i class="fas fa-times"></i> Clear Search
            </a>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
</div>

<!-- USERS TABLE -->
<div id="usersTableContainer">
    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Rank</th>
                    <th>Roll No</th>
                    <th>Class</th>
                    <th>Created Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $user)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="avatar-circle me-2" style="width: 32px; height: 32px; background: #e9ecef; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: #6c757d;">
                                    {{ strtoupper(substr($user->firstname, 0, 1)) }}
                                </div>
                                <strong>{{ $user->firstname }} {{ $user->lastname }}</strong>
                            </div>
                        </td>
                        <td>{{ $user->email }}</td>
                        <td>
                            <span class="badge bg-{{ $user->type == 'admin' ? 'danger' : ($user->type == 'supervisor' ? 'warning' : 'info') }}">
                                {{ ucfirst($user->type) }}
                            </span>
                        </td>
                        <td>{{ $user->rank ?? 'N/A' }}</td>
                        <td>{{ $user->roll_no ?? 'N/A' }}</td>
                        <td>{{ $user->class ?? 'N/A' }}</td>
                        <td>{{ $user->created_at->format('d/m/Y') }}</td>
                        <td>
                            <a href="{{ route('admin.users.edit', $user) }}" class="btn btn-sm btn-primary" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="{{ route('admin.users.delete', $user) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="9" class="text-center text-muted py-4">
                            <i class="fas fa-users fa-3x d-block mb-3"></i>
                            <h5>No users found</h5>
                            @if(request('search'))
                                <p class="mb-0">No results found for "<strong>{{ request('search') }}</strong>"</p>
                                <a href="{{ route('admin.users') }}" class="btn btn-sm btn-primary mt-2">
                                    <i class="fas fa-undo"></i> Clear Search
                                </a>
                            @else
                                <p class="mb-0">Click "Add User" to create your first user.</p>
                            @endif
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    @if($users->hasPages() || $users->total() > 0)
        <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mt-3 pt-2 border-top">
            <div class="pagination-info">
                <i class="fas fa-info-circle"></i>
                Showing 
                <strong>{{ $users->firstItem() ?? 0 }}</strong> 
                to 
                <strong>{{ $users->lastItem() ?? 0 }}</strong> 
                of 
                <strong>{{ $users->total() }}</strong> 
                results
                @if(request('search'))
                    <span class="text-muted">(filtered)</span>
                @endif
            </div>
            <div>
                {{ $users->links('pagination::bootstrap-5') }}
            </div>
        </div>
    @else
        <div class="text-center text-muted mt-3">
            <small>Total: <strong>{{ $users->total() }}</strong> users</small>
        </div>
    @endif
</div>