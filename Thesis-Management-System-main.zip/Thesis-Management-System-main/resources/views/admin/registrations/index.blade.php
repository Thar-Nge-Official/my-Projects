@extends('layouts.app')

@section('title', 'Registration Lists')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mb-4">
                <div>
                    <h2><i class="fas fa-user-plus"></i> Registration Lists</h2>
                    <p class="text-muted mb-0">Manage pending and rejected registrations</p>
                </div>
                
                <div class="d-flex gap-2 mt-2 mt-sm-0">
                    <a href="{{ route('admin.registrations') }}" class="btn btn-outline-secondary">
                        <i class="fas fa-sync"></i> Refresh
                    </a>
                </div>
            </div>

            <!-- Status Summary -->
            @php
                $pendingCount = \App\Models\User::where('registration_status', 'pending')->count();
                $rejectedCount = \App\Models\User::where('registration_status', 'rejected')->count();
            @endphp
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card bg-warning text-dark">
                        <div class="card-body text-center">
                            <h3>{{ $pendingCount }}</h3>
                            <span>Pending Registrations</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-danger text-white">
                        <div class="card-body text-center">
                            <h3>{{ $rejectedCount }}</h3>
                            <span>Rejected Registrations</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Search and Filter -->
            <div class="card mb-4">
                <div class="card-body">
                    <form action="{{ route('admin.registrations') }}" method="GET" class="row g-3 align-items-end">
                        <div class="col-md-5">
                            <label class="form-label fw-bold">
                                <i class="fas fa-search"></i> Search
                            </label>
                            <input type="text" 
                                   class="form-control" 
                                   name="search" 
                                   placeholder="Search by name or email..." 
                                   value="{{ request('search') }}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">
                                <i class="fas fa-filter"></i> Status
                            </label>
                            <select class="form-select" name="status">
                                <option value="">All Status</option>
                                <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                                <option value="rejected" {{ request('status') == 'rejected' ? 'selected' : '' }}>Rejected</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-filter"></i> Filter
                                </button>
                                @if(request('search') || request('status'))
                                    <a href="{{ route('admin.registrations') }}" class="btn btn-outline-danger" title="Clear all filters">
                                        <i class="fas fa-times"></i>
                                    </a>
                                @endif
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            
            <!-- Registration Table -->
            <div class="card">
                <div class="card-body">
                    @if(request('search') || request('status'))
                        <div class="alert alert-info alert-dismissible fade show">
                            <i class="fas fa-info-circle"></i> 
                            @if(request('search'))
                                Showing results for: <strong>"{{ request('search') }}"</strong>
                            @endif
                            @if(request('status'))
                                @if(request('search')) & @endif
                                Status: <strong>{{ ucfirst(request('status')) }}</strong>
                            @endif
                            <span class="badge bg-primary ms-2">{{ $registrations->total() }} results</span>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th>Registered Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($registrations as $registration)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>
                                            <strong>{{ $registration->firstname }} {{ $registration->lastname }}</strong>
                                        </td>
                                        <td>{{ $registration->email }}</td>
                                        <td>
                                            <span class="badge bg-{{ $registration->type == 'admin' ? 'danger' : ($registration->type == 'supervisor' ? 'warning' : 'info') }}">
                                                {{ ucfirst($registration->type) }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-{{ $registration->registration_status == 'pending' ? 'warning' : 'danger' }}">
                                                {{ ucfirst($registration->registration_status) }}
                                            </span>
                                            @if($registration->rejection_reason)
                                                <br>
                                                <small class="text-muted" title="{{ $registration->rejection_reason }}">
                                                    <i class="fas fa-info-circle"></i> {{ Str::limit($registration->rejection_reason, 30) }}
                                                </small>
                                            @endif
                                        </td>
                                        <td>
                                            {{ $registration->created_at->format('d/m/Y') }}
                                            <br>
                                            <small class="text-muted">{{ $registration->created_at->format('H:i') }}</small>
                                        </td>
                                        <td>
                                            @if($registration->registration_status === 'pending')
                                                <!-- Pending: Accept or Deny -->
                                                <div class="d-flex flex-wrap gap-1">
                                                    <form action="{{ route('admin.registrations.approve', $registration) }}" method="POST" class="d-inline">
                                                        @csrf
                                                        <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Are you sure you want to approve this user?')">
                                                            <i class="fas fa-check"></i> Accept
                                                        </button>
                                                    </form>
                                                    <form action="{{ route('admin.registrations.reject', $registration) }}" method="POST" class="d-inline">
                                                        @csrf
                                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to reject this registration?')">
                                                            <i class="fas fa-times"></i> Deny
                                                        </button>
                                                    </form>
                                                </div>
                                            @elseif($registration->registration_status === 'rejected')
                                                <!-- Rejected: Approve Again or Delete -->
                                                <div class="d-flex flex-wrap gap-1">
                                                    <form action="{{ route('admin.registrations.approve', $registration) }}" method="POST" class="d-inline">
                                                        @csrf
                                                        <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Are you sure you want to approve this previously rejected user?')">
                                                            <i class="fas fa-undo"></i> Approve Again
                                                        </button>
                                                    </form>
                                                    <form action="{{ route('admin.registrations.delete-rejected', $registration) }}" method="POST" class="d-inline">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this rejected user? They can register again.')">
                                                            <i class="fas fa-trash"></i> Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            @else
                                                <span class="text-muted">Already {{ $registration->registration_status }}</span>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">
                                            <i class="fas fa-users fa-3x d-block mb-3"></i>
                                            <h5>No registrations found</h5>
                                            @if(request('search'))
                                                <p class="mb-0">No results found for "<strong>{{ request('search') }}</strong>"</p>
                                                <a href="{{ route('admin.registrations') }}" class="btn btn-sm btn-primary mt-2">
                                                    <i class="fas fa-undo"></i> Clear Search
                                                </a>
                                            @else
                                                <p class="mb-0">All registrations have been reviewed.</p>
                                            @endif
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    @if($registrations->hasPages() || $registrations->total() > 0)
                        <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mt-3 pt-2 border-top">
                            <div class="pagination-info">
                                <i class="fas fa-info-circle"></i>
                                Showing 
                                <strong>{{ $registrations->firstItem() ?? 0 }}</strong> 
                                to 
                                <strong>{{ $registrations->lastItem() ?? 0 }}</strong> 
                                of 
                                <strong>{{ $registrations->total() }}</strong> 
                                results
                                @if(request('search') || request('status'))
                                    <span class="text-muted">(filtered)</span>
                                @endif
                            </div>
                            <div>
                                {{ $registrations->links('pagination::bootstrap-5') }}
                            </div>
                        </div>
                    @else
                        <div class="text-center text-muted mt-3">
                            <small>Total: <strong>{{ $registrations->total() }}</strong> registrations</small>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection