@extends('layouts.app')

@section('title', '404 - Page Not Found')

@section('content')
<div class="container">
    <div class="row justify-content-center align-items-center" style="min-height: 70vh;">
        <div class="col-md-6 text-center">
            <div class="error-page">
                <div class="error-code mb-4">
                    <h1 style="font-size: 120px; font-weight: 700; color: #0d6efd;">404</h1>
                </div>
                <div class="error-icon mb-4">
                    <i class="fas fa-exclamation-triangle" style="font-size: 60px; color: #ffc107;"></i>
                </div>
                <h2 class="mb-3">Page Not Found</h2>
                <p class="text-muted mb-4">
                    Sorry, the page you are looking for does not exist or has been moved.
                </p>
                <div class="d-flex gap-3 justify-content-center">
                    <a href="{{ url('/') }}" class="btn btn-primary">
                        <i class="fas fa-home"></i> Go Home
                    </a>
                    <a href="{{ url()->previous() }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Go Back
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .error-page {
        background: white;
        padding: 60px 40px;
        border-radius: 16px;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
        border: 1px solid #e9ecef;
    }
    .error-code h1 {
        background: linear-gradient(135deg, #0d6efd, #0a58ca);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    .error-icon i {
        opacity: 0.5;
    }
</style>
@endsection