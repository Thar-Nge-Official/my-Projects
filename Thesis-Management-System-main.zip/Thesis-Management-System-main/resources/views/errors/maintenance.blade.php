<!doctype html>
<html lang="en">
<head>
    @php
        $systemName = trim((string) ($settings->system_name ?? '')) ?: 'Academic Information System';
        $universityName = trim((string) ($settings->university_name ?? ''));
        $departmentName = trim((string) ($settings->department_name ?? ''));
        $email = trim((string) ($settings->email ?? ''));
        $phone = trim((string) ($settings->phone ?? ''));
        $address = trim((string) ($settings->address ?? ''));
        $institutionLine = trim($universityName . ($universityName && $departmentName ? ' - ' : '') . $departmentName);
    @endphp
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>System Maintenance - {{ $systemName }}</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        html,body{height:100%;margin:0;font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial}
        body{background:linear-gradient(180deg,#071125 0%,#0b1726 100%);display:flex;align-items:center;justify-content:center}
        .maintenance-card{width:760px;max-width:92%;padding:48px;border-radius:28px;background:linear-gradient(180deg,rgba(255,255,255,0.02),rgba(255,255,255,0.01));box-shadow: 0 10px 30px rgba(2,6,23,0.6), inset 0 1px 0 rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.03);text-align:center;color:#e6eef8}
        .maintenance-icon{width:72px;height:72px;margin:0 auto 18px;display:flex;align-items:center;justify-content:center;border-radius:18px;background:linear-gradient(180deg,#243048,#122033);box-shadow:0 4px 18px rgba(2,6,23,0.6)}
        .maintenance-title{font-size:32px;margin:8px 0 10px;font-weight:700}
        .maintenance-desc{color:rgba(230,238,248,0.85);line-height:1.8;max-width:600px;margin:0 auto 22px}
        .maintenance-meta{color:rgba(230,238,248,0.72);font-size:14px;line-height:1.8;margin:0 auto 22px;max-width:600px}
        .btn-admin{display:inline-flex;align-items:center;gap:10px;padding:12px 28px;border-radius:999px;background:rgba(255,255,255,0.06);color:#f5f9ff;border:1px solid rgba(255,255,255,0.05);text-decoration:none;font-weight:600}
        .btn-admin:hover{background:rgba(255,255,255,0.09)}
    </style>
</head>
<body>
    <div class="maintenance-card" role="main">
        <div class="maintenance-icon">🔧</div>
        <h1 class="maintenance-title">System Maintenance Notice</h1>
        <p class="maintenance-desc">{{ $systemName }} is temporarily unavailable due to scheduled maintenance by the university administration. Please try again later or contact your department for further assistance.</p>
        @if($institutionLine || $email || $phone || $address)
            <div class="maintenance-meta">
                @if($institutionLine)<div>{{ $institutionLine }}</div>@endif
                @if($address)<div>{{ $address }}</div>@endif
                @if($email || $phone)<div>{{ collect([$email, $phone])->filter()->implode(' | ') }}</div>@endif
            </div>
        @endif
        <a href="{{ route('login') }}" class="btn-admin">Admin Login</a>
    </div>
</body>
</html>
