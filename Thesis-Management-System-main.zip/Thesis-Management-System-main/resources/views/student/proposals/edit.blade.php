{{-- resources/views/student/proposals/edit.blade.php --}}

@extends('layouts.app')

@section('title', 'Edit Proposal')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex align-items-center gap-3">
                <a href="{{ route('student.proposals.index') }}" class="btn btn-light btn-sm rounded-circle shadow-sm" style="width: 42px; height: 42px; padding: 0;">
                    <i class="fas fa-arrow-left text-primary"></i>
                </a>
                <div>
                    <h3 class="fw-bold mb-0 text-dark">Edit Proposal</h3>
                    <p class="text-muted small mb-0">
                        <i class="fas fa-info-circle me-1"></i>
                        Update your proposal details
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-body p-4">
                    <div class="alert alert-info border-0 rounded-3 mb-4">
                        <i class="fas fa-info-circle me-2"></i>
                        Status: <strong>{{ $proposal->status_label }}</strong>
                        @if($proposal->status == 'draft')
                            <span class="text-muted">(You can edit this proposal)</span>
                        @endif
                    </div>

                    @if($errors->any())
                        <div class="alert alert-danger border-0 rounded-3 mb-4">
                            <div class="d-flex align-items-start gap-2">
                                <i class="fas fa-circle-exclamation mt-1"></i>
                                <div>
                                    <strong>Please fix the following errors:</strong>
                                    <ul class="mb-0 mt-1 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endif

                    <form action="{{ route('student.proposals.update', $proposal) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="row g-3">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="title" class="form-label fw-semibold">
                                        <i class="fas fa-heading text-primary me-1"></i> Proposal Title <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" class="form-control form-control-lg @error('title') is-invalid @enderror" 
                                           id="title" name="title" value="{{ old('title', $proposal->title) }}" 
                                           placeholder="Enter a clear and concise proposal title" required>
                                    @error('title')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="category_id" class="form-label fw-semibold">
                                        <i class="fas fa-tags text-primary me-1"></i> Category <span class="text-danger">*</span>
                                    </label>
                                    <select class="form-select form-select-lg @error('category_id') is-invalid @enderror" 
                                            id="category_id" name="category_id" required>
                                        <option value="">Select Category</option>
                                        @foreach($categories as $category)
                                            <option value="{{ $category->id }}" {{ old('category_id', $proposal->category_id) == $category->id ? 'selected' : '' }}>
                                                {{ $category->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('category_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="thesis_type" class="form-label fw-semibold">
                                        <i class="fas fa-tag text-primary me-1"></i> Thesis Type
                                    </label>
                                    <select class="form-select form-select-lg @error('thesis_type') is-invalid @enderror" 
                                            id="thesis_type" name="thesis_type">
                                        <option value="">Select Type</option>
                                        <option value="Web-based System" {{ old('thesis_type', $proposal->thesis_type) == 'Web-based System' ? 'selected' : '' }}>🌐 Web-based System</option>
                                        <option value="Desktop Application" {{ old('thesis_type', $proposal->thesis_type) == 'Desktop Application' ? 'selected' : '' }}>🖥️ Desktop Application</option>
                                        <option value="Mobile Application" {{ old('thesis_type', $proposal->thesis_type) == 'Mobile Application' ? 'selected' : '' }}>📱 Mobile Application</option>
                                        <option value="Research Paper" {{ old('thesis_type', $proposal->thesis_type) == 'Research Paper' ? 'selected' : '' }}>📄 Research Paper</option>
                                        <option value="System Development" {{ old('thesis_type', $proposal->thesis_type) == 'System Development' ? 'selected' : '' }}>⚙️ System Development</option>
                                    </select>
                                    @error('thesis_type')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="from_year" class="form-label fw-semibold">
                                        <i class="fas fa-calendar-start text-primary me-1"></i> From Year
                                    </label>
                                    <input type="number" class="form-control form-control-lg @error('from_year') is-invalid @enderror" 
                                           id="from_year" name="from_year" value="{{ old('from_year', $proposal->from_year) }}" 
                                           min="2000" max="{{ date('Y') + 5 }}">
                                    @error('from_year')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="to_year" class="form-label fw-semibold">
                                        <i class="fas fa-calendar-end text-primary me-1"></i> To Year
                                    </label>
                                    <input type="number" class="form-control form-control-lg @error('to_year') is-invalid @enderror" 
                                           id="to_year" name="to_year" value="{{ old('to_year', $proposal->to_year) }}" 
                                           min="2000" max="{{ date('Y') + 6 }}">
                                    @error('to_year')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group">
                                    <label for="abstract" class="form-label fw-semibold">
                                        <i class="fas fa-align-left text-primary me-1"></i> Abstract <span class="text-danger">*</span>
                                    </label>
                                    <textarea class="form-control form-control-lg @error('abstract') is-invalid @enderror" 
                                              id="abstract" name="abstract" rows="5" 
                                              placeholder="Write a comprehensive summary of your proposal..." 
                                              style="min-height: 150px;" required>{{ old('abstract', $proposal->abstract) }}</textarea>
                                    @error('abstract')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group">
                                    <label for="keywords" class="form-label fw-semibold">
                                        <i class="fas fa-hashtag text-primary me-1"></i> Keywords
                                    </label>
                                    <input type="text" class="form-control form-control-lg @error('keywords') is-invalid @enderror" 
                                           id="keywords" name="keywords" value="{{ old('keywords', $proposal->keywords) }}" 
                                           placeholder="e.g., Machine Learning, NLP, Education, Web Development">
                                    @error('keywords')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Separate keywords with commas
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex flex-wrap gap-3 justify-content-end pt-3 border-top mt-4">
                            <a href="{{ route('student.proposals.index') }}" class="btn btn-outline-secondary rounded-pill px-4 py-2">
                                <i class="fas fa-times me-2"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary rounded-pill px-5 py-2 shadow-sm">
                                <i class="fas fa-save me-2"></i> Update Proposal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .form-control-lg, .form-select-lg {
        border-radius: 0.75rem;
        border: 2px solid #e9ecef;
        padding: 0.75rem 1rem;
        font-size: 0.95rem;
        transition: all 0.3s ease;
    }
    .form-control-lg:focus, .form-select-lg:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1);
    }
    .card {
        border-radius: 16px !important;
        overflow: hidden;
    }
</style>
@endsection