@extends('layouts.app')

@section('title', 'Submit Three Proposals')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex align-items-center gap-3">
                <a href="{{ route('student.proposals.index') }}" class="btn btn-light btn-sm rounded-circle shadow-sm" style="width: 42px; height: 42px; padding: 0;">
                    <i class="fas fa-arrow-left text-primary"></i>
                </a>
                <div>
                    <h3 class="fw-bold mb-0 text-dark">Submit Three Proposals</h3>
                    <p class="text-muted small mb-0">
                        <i class="fas fa-info-circle me-1"></i>
                        Fill in all three proposals below, then submit them together for admin review.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-xl-10">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-body p-4">
                    @if($errors->any())
                        <div class="alert alert-danger border-0 rounded-3 mb-4">
                            <div class="d-flex align-items-start gap-2">
                                <i class="fas fa-circle-exclamation mt-1"></i>
                                <div>
                                    <strong>Please fix the following errors:</strong>
                                    <ul class="mb-0 mt-1 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endif

                    <form action="{{ route('student.proposals.store') }}" method="POST">
                        @csrf

                        <div class="alert alert-primary border-0 rounded-3 d-flex gap-2 mb-4" role="alert">
                            <i class="fas fa-layer-group mt-1"></i>
                            <div>
                                <strong>One submission, three proposals.</strong><br>
                                <span class="small">All three sections are required. Admin will approve one proposal and automatically reject the other two.</span>
                            </div>
                        </div>

                        <div class="accordion" id="proposalAccordion">
                            @for($index = 0; $index < 3; $index++)
                                @php
                                    $number = $index + 1;
                                    $fieldPrefix = "proposals.$index";
                                    $collapseId = "proposal-$number";
                                @endphp
                                <div class="accordion-item border rounded-4 mb-3 overflow-hidden">
                                    <h2 class="accordion-header" id="heading-{{ $number }}">
                                        <button class="accordion-button {{ $index === 0 ? '' : 'collapsed' }} fw-bold" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#{{ $collapseId }}"
                                                aria-expanded="{{ $index === 0 ? 'true' : 'false' }}" aria-controls="{{ $collapseId }}">
                                            <span class="proposal-number me-3">{{ $number }}</span>
                                            Proposal {{ $number }}
                                            <span class="ms-2 text-danger small">* Required</span>
                                        </button>
                                    </h2>
                                    <div id="{{ $collapseId }}" class="accordion-collapse collapse {{ $index === 0 ? 'show' : '' }}" aria-labelledby="heading-{{ $number }}" data-bs-parent="#proposalAccordion">
                                        <div class="accordion-body p-4">
                                            <div class="row g-3">
                                                <div class="col-12">
                                                    <label for="title-{{ $number }}" class="form-label fw-semibold">
                                                        <i class="fas fa-heading text-primary me-1"></i> Proposal Title <span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" class="form-control form-control-lg @error("$fieldPrefix.title") is-invalid @enderror"
                                                           id="title-{{ $number }}" name="proposals[{{ $index }}][title]" value="{{ old("$fieldPrefix.title") }}"
                                                           placeholder="Enter a clear and concise proposal title" required>
                                                    @error("$fieldPrefix.title")<div class="invalid-feedback">{{ $message }}</div>@enderror
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="category-{{ $number }}" class="form-label fw-semibold">
                                                        <i class="fas fa-tags text-primary me-1"></i> Category <span class="text-danger">*</span>
                                                    </label>
                                                    <select class="form-select form-select-lg @error("$fieldPrefix.category_id") is-invalid @enderror"
                                                            id="category-{{ $number }}" name="proposals[{{ $index }}][category_id]" required>
                                                        <option value="">Select Category</option>
                                                        @foreach($categories as $category)
                                                            <option value="{{ $category->id }}" {{ old("$fieldPrefix.category_id") == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                                                        @endforeach
                                                    </select>
                                                    @error("$fieldPrefix.category_id")<div class="invalid-feedback">{{ $message }}</div>@enderror
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="type-{{ $number }}" class="form-label fw-semibold">
                                                        <i class="fas fa-tag text-primary me-1"></i> Thesis Type
                                                    </label>
                                                    <select class="form-select form-select-lg @error("$fieldPrefix.thesis_type") is-invalid @enderror"
                                                            id="type-{{ $number }}" name="proposals[{{ $index }}][thesis_type]">
                                                        <option value="">Select Type</option>
                                                        @foreach(['Web-based System', 'Desktop Application', 'Mobile Application', 'Research Paper', 'System Development'] as $type)
                                                            <option value="{{ $type }}" {{ old("$fieldPrefix.thesis_type") === $type ? 'selected' : '' }}>{{ $type }}</option>
                                                        @endforeach
                                                    </select>
                                                    @error("$fieldPrefix.thesis_type")<div class="invalid-feedback">{{ $message }}</div>@enderror
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="from-year-{{ $number }}" class="form-label fw-semibold"><i class="fas fa-calendar-start text-primary me-1"></i> From Year</label>
                                                    <input type="number" class="form-control form-control-lg @error("$fieldPrefix.from_year") is-invalid @enderror"
                                                           id="from-year-{{ $number }}" name="proposals[{{ $index }}][from_year]" value="{{ old("$fieldPrefix.from_year", date('Y')) }}" min="1900" max="{{ date('Y') + 10 }}">
                                                    @error("$fieldPrefix.from_year")<div class="invalid-feedback">{{ $message }}</div>@enderror
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="to-year-{{ $number }}" class="form-label fw-semibold"><i class="fas fa-calendar-end text-primary me-1"></i> To Year</label>
                                                    <input type="number" class="form-control form-control-lg @error("$fieldPrefix.to_year") is-invalid @enderror"
                                                           id="to-year-{{ $number }}" name="proposals[{{ $index }}][to_year]" value="{{ old("$fieldPrefix.to_year", date('Y') + 1) }}" min="1900" max="{{ date('Y') + 10 }}">
                                                    @error("$fieldPrefix.to_year")<div class="invalid-feedback">{{ $message }}</div>@enderror
                                                </div>

                                                <div class="col-12">
                                                    <label for="abstract-{{ $number }}" class="form-label fw-semibold">
                                                        <i class="fas fa-align-left text-primary me-1"></i> Abstract <span class="text-danger">*</span>
                                                    </label>
                                                    <textarea class="form-control form-control-lg @error("$fieldPrefix.abstract") is-invalid @enderror"
                                                              id="abstract-{{ $number }}" name="proposals[{{ $index }}][abstract]" rows="5"
                                                              placeholder="Write a comprehensive summary of your proposal..." required>{{ old("$fieldPrefix.abstract") }}</textarea>
                                                    @error("$fieldPrefix.abstract")<div class="invalid-feedback">{{ $message }}</div>@enderror
                                                </div>

                                                <div class="col-12">
                                                    <label for="keywords-{{ $number }}" class="form-label fw-semibold"><i class="fas fa-hashtag text-primary me-1"></i> Keywords</label>
                                                    <input type="text" class="form-control form-control-lg @error("$fieldPrefix.keywords") is-invalid @enderror"
                                                           id="keywords-{{ $number }}" name="proposals[{{ $index }}][keywords]" value="{{ old("$fieldPrefix.keywords") }}"
                                                           placeholder="e.g., Machine Learning, NLP, Education, Web Development">
                                                    @error("$fieldPrefix.keywords")<div class="invalid-feedback">{{ $message }}</div>@enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endfor
                        </div>

                        <div class="d-flex flex-wrap gap-3 justify-content-end pt-3 border-top mt-4">
                            <a href="{{ route('student.proposals.index') }}" class="btn btn-outline-secondary rounded-pill px-4 py-2"><i class="fas fa-times me-2"></i> Cancel</a>
                            <button type="submit" class="btn btn-primary rounded-pill px-5 py-2 shadow-sm"><i class="fas fa-paper-plane me-2"></i> Submit All Three Proposals</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .form-control-lg, .form-select-lg { border-radius: .75rem; border: 2px solid #e9ecef; padding: .75rem 1rem; font-size: .95rem; transition: all .3s ease; }
    .form-control-lg:focus, .form-select-lg:focus { border-color: #0d6efd; box-shadow: 0 0 0 4px rgba(13, 110, 253, .1); }
    .card { border-radius: 16px !important; overflow: hidden; }
    .accordion-button:not(.collapsed) { color: #0d6efd; background-color: #eef5ff; box-shadow: none; }
    .proposal-number { display: inline-flex; align-items: center; justify-content: center; width: 2rem; height: 2rem; border-radius: 50%; background: #0d6efd; color: #fff; }
</style>
@endsection
