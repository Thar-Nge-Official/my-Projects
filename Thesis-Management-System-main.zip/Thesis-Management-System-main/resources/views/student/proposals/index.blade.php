{{-- resources/views/student/proposals/index.blade.php --}}

@extends('layouts.app')

@section('title', 'My Thesis Proposals')

@section('content')
<div class="container-fluid">
    <!-- ============================================ -->
    <!-- HEADER -->
    <!-- ============================================ -->
    <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">
                <i class="fas fa-file-alt text-primary me-2"></i>My Thesis Proposals
            </h2>
            <p class="text-muted mb-0">Submit all <strong>3 proposals</strong> together for admin review</p>
        </div>
        @if(!$hasActiveThesis && !$hasOpenProposals)
            <a href="{{ route('student.proposals.create') }}" class="btn btn-primary btn-lg rounded-pill px-4 shadow-sm">
                <i class="fas fa-layer-group me-2"></i>Submit Three Proposals
            </a>
        @endif
    </div>

    <!-- ============================================ -->
    <!-- ACTIVE THESIS WARNING -->
    <!-- ============================================ -->
    @if($hasActiveThesis)
        <div class="alert alert-info border-0 shadow-sm mb-4">
            <i class="fas fa-info-circle me-2"></i>
            You already have an active thesis. Please complete it before creating new proposals.
        </div>
    @elseif($hasOpenProposals)
        <div class="alert alert-info border-0 shadow-sm mb-4">
            <i class="fas fa-info-circle me-2"></i>
            Please complete or remove your existing active proposal set before creating a new set.
        </div>
    @endif

    <!-- ============================================ -->
    <!-- ALERTS -->
    <!-- ============================================ -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm">
            <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm">
            <i class="fas fa-exclamation-circle me-2"></i> {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if(!$hasActiveThesis && $proposals->where('status', 'submitted')->isNotEmpty())
        <div class="alert alert-info border-0 shadow-sm mb-4">
            <i class="fas fa-clock me-2"></i>
            Your proposals have been submitted and are waiting for admin review.
        </div>
    @endif

    <!-- ============================================ -->
    <!-- STATISTICS -->
    <!-- ============================================ -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center py-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="fas fa-pencil-alt text-secondary" style="font-size: 24px;"></i>
                        <div>
                            <h5 class="mb-0 fw-bold">{{ $proposals->where('status', 'draft')->count() }}</h5>
                            <small class="text-muted">Draft</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center py-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="fas fa-clock text-warning" style="font-size: 24px;"></i>
                        <div>
                            <h5 class="mb-0 fw-bold">{{ $proposals->where('status', 'submitted')->count() }}</h5>
                            <small class="text-muted">Submitted</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center py-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="fas fa-check-circle text-success" style="font-size: 24px;"></i>
                        <div>
                            <h5 class="mb-0 fw-bold">{{ $proposals->where('status', 'approved')->count() }}</h5>
                            <small class="text-muted">Approved</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center py-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="fas fa-times-circle text-danger" style="font-size: 24px;"></i>
                        <div>
                            <h5 class="mb-0 fw-bold">{{ $proposals->where('status', 'rejected')->count() }}</h5>
                            <small class="text-muted">Rejected</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- SUBMIT ALL BUTTON -->
    <!-- ============================================ -->
    @php
        $draftProposals = $proposals->where('status', 'draft');
    @endphp
    @if(!$hasActiveThesis && $draftProposals->count() >= 3)
        <div class="mb-4">
            <form action="{{ route('student.proposals.submit-all') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-success rounded-pill px-5 py-2 shadow-sm" 
                        onclick="return confirm('Are you sure you want to submit all {{ $draftProposals->count() }} proposals for review?')">
                    <i class="fas fa-paper-plane me-2"></i> Submit All Proposals ({{ $draftProposals->count() }}/3)
                </button>
                <small class="text-muted d-block mt-2">
                    <i class="fas fa-info-circle me-1"></i>
                    You have {{ $draftProposals->count() }}/3 proposals ready.
                </small>
            </form>
        </div>
    @elseif(!$hasActiveThesis && $draftProposals->count() > 0 && $draftProposals->count() < 3)
        <div class="alert alert-warning border-0 shadow-sm mb-4">
            <i class="fas fa-info-circle me-2"></i>
            You have {{ $draftProposals->count() }} legacy draft proposal(s). Delete these drafts, then submit a new set of three proposals together.
        </div>
    @endif

    <!-- ============================================ -->
    <!-- PROPOSALS LIST -->
    <!-- ============================================ -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4 py-3" style="width: 50px;">#</th>
                            <th class="py-3">Title</th>
                            <th class="py-3">Category</th>
                            <th class="py-3 text-center">Status</th>
                            <th class="py-3 text-center">Date</th>
                            <th class="py-3 pe-4 text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($proposals as $proposal)
                            <tr>
                                <td class="ps-4 fw-semibold text-muted">{{ $loop->iteration }}</td>
                                <td>
                                    <div>
                                        <div class="fw-semibold">{{ Str::limit($proposal->title, 40) }}</div>
                                        @if($proposal->is_selected)
                                            <span class="badge bg-success">⭐ Selected</span>
                                        @endif
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark px-3 py-2 rounded-pill">
                                        {{ $proposal->category->name ?? 'N/A' }}
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-{{ $proposal->status_color }} px-3 py-2 rounded-pill">
                                        {{ $proposal->status_label }}
                                    </span>
                                </td>
                                <td class="text-center text-muted">
                                    <div>{{ $proposal->created_at->format('d/m/Y') }}</div>
                                    <small>{{ $proposal->created_at->format('H:i') }}</small>
                                </td>
                                <td class="pe-4 text-end">
                                    <div class="d-flex justify-content-end gap-1">
                                        <a href="{{ route('student.proposals.show', $proposal) }}" 
                                           class="btn btn-sm btn-outline-info rounded-circle" 
                                           title="View Details" 
                                           style="width: 32px; height: 32px; padding: 0;">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        @if($proposal->status == 'draft')
                                            <a href="{{ route('student.proposals.edit', $proposal) }}" 
                                               class="btn btn-sm btn-outline-primary rounded-circle" 
                                               title="Edit" 
                                               style="width: 32px; height: 32px; padding: 0;">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="{{ route('student.proposals.destroy', $proposal) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" 
                                                        class="btn btn-sm btn-outline-danger rounded-circle" 
                                                        title="Delete" 
                                                        style="width: 32px; height: 32px; padding: 0;"
                                                        onclick="return confirm('Are you sure you want to delete this proposal?')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center py-5">
                                    <div class="empty-state">
                                        <i class="fas fa-file-alt text-muted" style="font-size: 64px;"></i>
                                        <h5 class="mt-3 text-muted">No proposals found</h5>
                                        <p class="text-muted mb-0">Submit your three proposals together to get started.</p>
                                        @if(!$hasActiveThesis && !$hasOpenProposals)
                                            <a href="{{ route('student.proposals.create') }}" class="btn btn-primary mt-3">
                                                <i class="fas fa-layer-group me-2"></i>Submit Three Proposals
                                            </a>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
    .empty-state {
        padding: 40px 20px;
    }
    .card {
        border-radius: 16px !important;
        overflow: hidden;
    }
    .table tbody tr {
        transition: all 0.2s ease;
    }
    .table tbody tr:hover {
        background-color: rgba(13, 110, 253, 0.03);
    }
</style>
@endsection
