<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #1a1a2e, #0d6efd);
            padding: 30px 40px;
            text-align: center;
        }
        .header h1 {
            color: white;
            font-size: 24px;
            margin: 0;
            font-weight: 700;
        }
        .header p {
            color: rgba(255, 255, 255, 0.8);
            margin: 5px 0 0;
            font-size: 14px;
        }
        .body {
            padding: 40px;
        }
        .body h2 {
            color: #1a1a2e;
            font-size: 20px;
            margin-top: 0;
        }
        .body p {
            color: #555;
            font-size: 15px;
            line-height: 1.6;
            margin: 10px 0;
        }
        .body .highlight {
            background: #e8f0fe;
            padding: 15px 20px;
            border-radius: 8px;
            border-left: 4px solid #0d6efd;
            margin: 20px 0;
        }
        .btn {
            display: inline-block;
            background: #0d6efd;
            color: white;
            padding: 12px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 15px;
        }
        .btn:hover {
            background: #0a58ca;
        }
        .btn-container {
            text-align: center;
        }
        .footer {
            background: #f8f9fa;
            padding: 20px 40px;
            text-align: center;
            border-top: 1px solid #e9ecef;
        }
        .footer p {
            color: #888;
            font-size: 13px;
            margin: 0;
        }
        .footer .system-name {
            color: #0d6efd;
            font-weight: 600;
        }
        .expiry-note {
            color: #888;
            font-size: 13px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>🔐 Password Reset Request</h1>
            <p>{{ $settings->system_name ?? 'Thesis Management System' }}</p>
        </div>

        <!-- Body -->
        <div class="body">
            <h2>Dear User,</h2>
            
            <p>We received a request to reset the password for your account associated with this email address.</p>

            <div class="highlight">
                <p><strong>Email:</strong> {{ $email }}</p>
            </div>

            <p>Click the button below to reset your password. This link will expire in <strong>60 minutes</strong>.</p>

            <div class="btn-container">
                <a href="{{ route('password.reset', ['token' => $token]) }}" class="btn">
                    <i class="fas fa-key"></i> Reset Password
                </a>
            </div>

            <p class="expiry-note">If you did not request a password reset, please ignore this email. Your password will not be changed unless you click the link above.</p>

            <p style="margin-top: 20px;">If you have any questions, please contact the system administrator.</p>
            
            <p style="margin-top: 20px;">Best regards,<br>
            <strong>{{ $settings->system_name ?? 'Thesis Management System' }}</strong><br>
            {{ $settings->university_name ?? 'University of Yangon' }}</p>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>&copy; {{ date('Y') }} <span class="system-name">{{ $settings->system_name ?? 'Thesis Management System' }}</span></p>
            <p>{{ $settings->address ?? 'University of Yangon, Kamayut, Yangon' }}</p>
        </div>
    </div>
</body>
</html>