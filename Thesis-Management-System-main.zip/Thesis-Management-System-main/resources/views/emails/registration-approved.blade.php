<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>အသိပေးချက် - အကောင့်ခွင့်ပြုခြင်း</title>
    <style>
        body {
            font-family: 'Segoe UI', 'Noto Sans Myanmar', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #1a1a2e, #0d6efd);
            padding: 30px 40px;
            text-align: center;
        }
        .header h1 {
            color: white;
            font-size: 24px;
            margin: 0;
            font-weight: 700;
        }
        .header p {
            color: rgba(255, 255, 255, 0.8);
            margin: 5px 0 0;
            font-size: 14px;
        }
        .body {
            padding: 40px;
        }
        .body h2 {
            color: #1a1a2e;
            font-size: 20px;
            margin-top: 0;
        }
        .body p {
            color: #555;
            font-size: 15px;
            line-height: 1.7;
            margin: 10px 0;
        }
        .body .highlight {
            background: #e8f0fe;
            padding: 15px 20px;
            border-radius: 8px;
            border-left: 4px solid #0d6efd;
            margin: 20px 0;
        }
        .body .highlight strong {
            color: #0d6efd;
        }
        .btn {
            display: inline-block;
            background: #0d6efd;
            color: white;
            padding: 12px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 15px;
        }
        .btn:hover {
            background: #0a58ca;
        }
        .footer {
            background: #f8f9fa;
            padding: 20px 40px;
            text-align: center;
            border-top: 1px solid #e9ecef;
        }
        .footer p {
            color: #888;
            font-size: 13px;
            margin: 0;
        }
        .footer .system-name {
            color: #0d6efd;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>✅ အကောင့်ဝင်ခွင့် ခွင့်ပြုလိုက်ပါပြီ</h1>
            <p>{{ $settings->system_name ?? 'Thesis Management System' }}</p>
        </div>

        <div class="body">
            <h2>လူကြီးမင်း/မိန်းကလေး {{ $user->firstname }} {{ $user->lastname }}၊</h2>

            <p>တောင်းဆိုချက်ကို စနစ်စီမံခန့်ခွဲသူက အတည်ပြုပြီးဖြစ်သောကြောင့်၊ သင်၏ အကောင့်ဝင်ခွင့်ကို အတည်ပြုလိုက်ပါပြီ။</p>
            <p>ဤအကောင့်ဖြင့် အကောင့်သို့ ဝင်ရောက်ကာ စနစ်အတွင်းရှိ အလုပ်များကို ဆက်လက်လုပ်ဆောင်နိုင်ပါမည်။</p>

            <div class="highlight">
                <p><strong>အကောင့်အသေးစိတ်:</strong></p>
                <p style="margin: 5px 0;"><strong>အီးမေးလ်:</strong> {{ $user->email }}</p>
                <p style="margin: 5px 0;"><strong>ရာထူး:</strong> {{ ucfirst($user->type) }}</p>
                <p style="margin: 5px 0;"><strong>မှတ်ပုံတင်သည့်နေ့:</strong> {{ $user->created_at->format('d M, Y') }}</p>
            </div>

            <p>ယခုမှစ၍ အီးမေးလ်နှင့် စကားဝှက်ဖြင့် စနစ်ထဲ ဝင်ရောက်အသုံးပြုနိုင်ပါသည်။</p>

            <div style="text-align: center;">
                <a href="{{ url('/login') }}" class="btn">ဝင်ရောက်ပါ</a>
            </div>

            <p style="margin-top: 20px;">မေးခွန်းများရှိပါက စနစ်စီမံခန့်ခွဲသူထံ ဆက်သွယ်နိုင်ပါသည်။</p>

            <p style="margin-top: 20px;">နောက်ဆုံးအနေဖြင့်<br>
            <strong>{{ $settings->system_name ?? 'Thesis Management System' }}</strong><br>
            {{ $settings->university_name ?? 'University of Yangon' }}</p>
        </div>

        <div class="footer">
            <p>&copy; {{ date('Y') }} <span class="system-name">{{ $settings->system_name ?? 'Thesis Management System' }}</span></p>
            <p>{{ $settings->address ?? 'University of Yangon, Kamayut, Yangon' }}</p>
        </div>
    </div>
</body>
</html>