<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>အသိပေးချက် - အကောင့်ငြင်းပယ်ခြင်း</title>
    <style>
        body {
            font-family: 'Segoe UI', 'Noto Sans Myanmar', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #1a1a2e, #dc3545);
            padding: 30px 40px;
            text-align: center;
        }
        .header h1 {
            color: white;
            font-size: 24px;
            margin: 0;
            font-weight: 700;
        }
        .header p {
            color: rgba(255, 255, 255, 0.8);
            margin: 5px 0 0;
            font-size: 14px;
        }
        .body {
            padding: 40px;
        }
        .body h2 {
            color: #1a1a2e;
            font-size: 20px;
            margin-top: 0;
        }
        .body p {
            color: #555;
            font-size: 15px;
            line-height: 1.7;
            margin: 10px 0;
        }
        .body .highlight {
            background: #fde8e8;
            padding: 15px 20px;
            border-radius: 8px;
            border-left: 4px solid #dc3545;
            margin: 20px 0;
        }
        .body .highlight strong {
            color: #dc3545;
        }
        .body .highlight .reason {
            background: white;
            padding: 10px 15px;
            border-radius: 6px;
            margin-top: 10px;
            border: 1px solid #f5c6cb;
        }
        .btn {
            display: inline-block;
            background: #6c757d;
            color: white;
            padding: 12px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 15px;
        }
        .btn:hover {
            background: #5a6268;
        }
        .footer {
            background: #f8f9fa;
            padding: 20px 40px;
            text-align: center;
            border-top: 1px solid #e9ecef;
        }
        .footer p {
            color: #888;
            font-size: 13px;
            margin: 0;
        }
        .footer .system-name {
            color: #0d6efd;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>❌ အကောင့်ဝင်ခွင့် ငြင်းပယ်လိုက်ပါပြီ</h1>
            <p>{{ $settings->system_name ?? 'Thesis Management System' }}</p>
        </div>

        <div class="body">
            <h2>လူကြီးမင်း/မိန်းကလေး {{ $user->firstname }} {{ $user->lastname }}၊</h2>

            <p>စနစ်စီမံခန့်ခွဲသူမှ သင်၏ မှတ်ပုံတင်တောင်းဆိုချက်ကို ငြင်းပယ်လိုက်ပြီးဖြစ်သောကြောင့် အသိပေးလိုက်ပါသည်။</p>
            <p>ထို့ကြောင့် ယခုတောင်းဆိုချက်အရ အကောင့်ဝင်ခွင့်ကို သတ်မှတ်မပေးတော့ပါ။</p>

            <div class="highlight">
                <p><strong>အကောင့်အသေးစိတ်:</strong></p>
                <p style="margin: 5px 0;"><strong>အီးမေးလ်:</strong> {{ $user->email }}</p>
                <p style="margin: 5px 0;"><strong>ရာထူး:</strong> {{ ucfirst($user->type) }}</p>
                <p style="margin: 5px 0;"><strong>မှတ်ပုံတင်သည့်နေ့:</strong> {{ $user->created_at->format('d M, Y') }}</p>
                @if($reason)
                    <div class="reason">
                        <strong>ငြင်းပယ်ရခြင်းအကြောင်းပြချက်:</strong>
                        <p style="margin: 5px 0 0;">{{ $reason }}</p>
                    </div>
                @endif
            </div>

            <p>အမှားအယွင်းတစ်ခုခု ဖြစ်နေပါက သို့မဟုတ် နောက်တစ်ကြိမ် ပြန်လည်တောင်းဆိုလိုပါက စနစ်စီမံခန့်ခွဲသူကို ဆက်သွယ်ပေးပါ။</p>

            <div style="text-align: center;">
                <a href="{{ url('/register') }}" class="btn">ပြန်လည်တောင်းဆိုမည်</a>
            </div>

            <p style="margin-top: 20px;">မေးခွန်းများရှိပါက စနစ်စီမံခန့်ခွဲသူကို ဆက်သွယ်နိုင်ပါသည်။</p>

            <p style="margin-top: 20px;">မင်္ဂလာပါ<br>
            <strong>{{ $settings->system_name ?? 'Thesis Management System' }}</strong><br>
            {{ $settings->university_name ?? 'University of Yangon' }}</p>
        </div>

        <div class="footer">
            <p>&copy; {{ date('Y') }} <span class="system-name">{{ $settings->system_name ?? 'Thesis Management System' }}</span></p>
            <p>{{ $settings->address ?? 'University of Yangon, Kamayut, Yangon' }}</p>
        </div>
    </div>
</body>
</html>