{{-- resources/views/welcome.blade.php --}}

@php
    $systemName = trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System';
    $universityName = trim((string) ($appSettings->university_name ?? ''));
    $departmentName = trim((string) ($appSettings->department_name ?? ''));
    $institutionLine = trim($universityName . ($universityName && $departmentName ? ' - ' : '') . $departmentName);
@endphp

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $systemName }}</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@700;800;900&display=swap" rel="stylesheet">
    
    <style>
        /* ============================================ */
        /* RESET */
        /* ============================================ */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow: hidden;
        }

        /* ============================================ */
        /* ANIMATED BACKGROUND (Same as before) */
        /* ============================================ */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(ellipse at 20% 50%, rgba(108, 99, 255, 0.1), transparent 60%),
                radial-gradient(ellipse at 80% 50%, rgba(0, 210, 255, 0.08), transparent 60%),
                radial-gradient(ellipse at 50% 100%, rgba(255, 107, 107, 0.05), transparent 50%);
            animation: gradientShift 10s ease-in-out infinite alternate;
            pointer-events: none;
        }

        @keyframes gradientShift {
            0% { opacity: 0.5; }
            50% { opacity: 1; }
            100% { opacity: 0.5; }
        }

        /* ============================================ */
        /* SPARKLES (Same as before) */
        /* ============================================ */
        .sparkles-container {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            overflow: hidden;
            pointer-events: none;
            z-index: 0;
        }

        .sparkle {
            position: absolute;
            border-radius: 50%;
            animation: floatSparkle var(--duration) ease-in-out infinite alternate;
            opacity: 0;
        }

        .sparkle::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border-radius: 50%;
            background: inherit;
            box-shadow: 0 0 20px 5px rgba(255, 255, 255, 0.3);
        }

        @keyframes floatSparkle {
            0% { transform: translate(0, 0) scale(0.5); opacity: 0; }
            20% { opacity: 0.8; }
            80% { opacity: 0.8; }
            100% { transform: translate(var(--tx), var(--ty)) scale(1.2); opacity: 0; }
        }

        .sparkle-1 { width: 6px; height: 6px; background: #6c63ff; left: 5%; top: 15%; --duration: 6s; --tx: 120px; --ty: -80px; animation-delay: 0s; }
        .sparkle-2 { width: 10px; height: 10px; background: #00d2ff; left: 15%; top: 70%; --duration: 8s; --tx: -150px; --ty: -100px; animation-delay: 1s; }
        .sparkle-3 { width: 4px; height: 4px; background: #ff6b6b; left: 25%; top: 30%; --duration: 7s; --tx: 80px; --ty: 120px; animation-delay: 2s; }
        .sparkle-4 { width: 8px; height: 8px; background: #2ed573; left: 35%; top: 85%; --duration: 9s; --tx: -100px; --ty: -60px; animation-delay: 0.5s; }
        .sparkle-5 { width: 5px; height: 5px; background: #f9ca24; left: 45%; top: 10%; --duration: 6.5s; --tx: 150px; --ty: 90px; animation-delay: 1.5s; }
        .sparkle-6 { width: 12px; height: 12px; background: #e056a0; left: 55%; top: 60%; --duration: 8.5s; --tx: -130px; --ty: 100px; animation-delay: 3s; }
        .sparkle-7 { width: 3px; height: 3px; background: #7ed6df; left: 65%; top: 25%; --duration: 7.5s; --tx: 90px; --ty: -130px; animation-delay: 0.8s; }
        .sparkle-8 { width: 7px; height: 7px; background: #ff7979; left: 75%; top: 80%; --duration: 9.5s; --tx: -80px; --ty: -110px; animation-delay: 2.5s; }
        .sparkle-9 { width: 9px; height: 9px; background: #a29bfe; left: 85%; top: 40%; --duration: 6.8s; --tx: 130px; --ty: -70px; animation-delay: 1.8s; }
        .sparkle-10 { width: 4px; height: 4px; background: #55efc4; left: 92%; top: 20%; --duration: 7.2s; --tx: -110px; --ty: 80px; animation-delay: 3.5s; }
        .sparkle-11 { width: 11px; height: 11px; background: #fd79a8; left: 8%; top: 45%; --duration: 8.2s; --tx: 160px; --ty: -90px; animation-delay: 4s; }
        .sparkle-12 { width: 5px; height: 5px; background: #74b9ff; left: 48%; top: 50%; --duration: 6.3s; --tx: -140px; --ty: 110px; animation-delay: 2.2s; }
        .sparkle-13 { width: 8px; height: 8px; background: #fdcb6e; left: 70%; top: 55%; --duration: 9.8s; --tx: 100px; --ty: -120px; animation-delay: 0.3s; }
        .sparkle-14 { width: 6px; height: 6px; background: #00cec9; left: 30%; top: 5%; --duration: 7.8s; --tx: -90px; --ty: 130px; animation-delay: 2.8s; }
        .sparkle-15 { width: 10px; height: 10px; background: #e17055; left: 88%; top: 75%; --duration: 8.8s; --tx: 110px; --ty: -100px; animation-delay: 1.2s; }
        .sparkle-16 { width: 4px; height: 4px; background: #81ecec; left: 12%; top: 92%; --duration: 6.1s; --tx: 140px; --ty: -50px; animation-delay: 3.8s; }
        .sparkle-17 { width: 7px; height: 7px; background: #ffeaa7; left: 42%; top: 38%; --duration: 9.2s; --tx: -120px; --ty: 90px; animation-delay: 0.6s; }
        .sparkle-18 { width: 5px; height: 5px; background: #dfe6e9; left: 78%; top: 10%; --duration: 7.4s; --tx: 80px; --ty: 140px; animation-delay: 4.2s; }
        .sparkle-19 { width: 9px; height: 9px; background: #b8e994; left: 58%; top: 78%; --duration: 8.0s; --tx: -160px; --ty: -80px; animation-delay: 1.6s; }
        .sparkle-20 { width: 3px; height: 3px; background: #d980fa; left: 95%; top: 60%; --duration: 6.9s; --tx: -70px; --ty: 120px; animation-delay: 3.2s; }

        .twinkle-sparkle {
            position: absolute;
            border-radius: 50%;
            animation: twinkle 3s ease-in-out infinite;
            pointer-events: none;
        }

        @keyframes twinkle {
            0%, 100% { opacity: 0.1; transform: scale(0.8); }
            50% { opacity: 0.4; transform: scale(1.2); }
        }

        .twinkle-1 { width: 80px; height: 80px; background: radial-gradient(circle, rgba(108, 99, 255, 0.08), transparent); left: 10%; top: 25%; animation-delay: 0s; }
        .twinkle-2 { width: 100px; height: 100px; background: radial-gradient(circle, rgba(0, 210, 255, 0.06), transparent); left: 50%; top: 60%; animation-delay: 1s; }
        .twinkle-3 { width: 60px; height: 60px; background: radial-gradient(circle, rgba(255, 107, 107, 0.07), transparent); left: 80%; top: 30%; animation-delay: 2s; }
        .twinkle-4 { width: 90px; height: 90px; background: radial-gradient(circle, rgba(46, 213, 115, 0.06), transparent); left: 30%; top: 80%; animation-delay: 0.5s; }
        .twinkle-5 { width: 120px; height: 120px; background: radial-gradient(circle, rgba(249, 202, 36, 0.05), transparent); left: 70%; top: 50%; animation-delay: 1.5s; }

        /* ============================================ */
        /* WELCOME CONTAINER - FIXED */
        /* ============================================ */
        .welcome-container {
            width: 100%;
            max-width: 1200px;
            padding: 20px;
            position: relative;
            z-index: 1;
        }

        .welcome-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(30px);
            border-radius: 32px;
            padding: 50px 50px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 40px 100px rgba(0, 0, 0, 0.08);
            position: relative;
            overflow: hidden;
            min-height: auto;
        }

        /* ============================================ */
        /* CONTENT SIDE - FIXED */
        /* ============================================ */
        .content-side {
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            z-index: 1;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            background: rgba(108, 99, 255, 0.08);
            padding: 8px 20px;
            border-radius: 50px;
            border: 1px solid rgba(108, 99, 255, 0.1);
            width: fit-content;
            margin-bottom: 24px;
        }

        .badge i {
            color: #6c63ff;
            font-size: 16px;
        }

        .badge span {
            color: rgba(0, 0, 0, 0.5);
            font-size: 14px;
            font-weight: 500;
            letter-spacing: 0.5px;
        }

        .main-title {
            font-family: 'Playfair Display', serif;
            font-size: 56px;
            font-weight: 900;
            line-height: 1.08;
            color: #1a1a2e;
            margin-bottom: 14px;
        }

        .main-title .highlight {
            background: linear-gradient(135deg, #6c63ff, #00d2ff, #6c63ff);
            background-size: 200% 200%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .subtitle {
            color: rgba(0, 0, 0, 0.5);
            font-size: 18px;
            font-weight: 300;
            line-height: 1.7;
            margin-bottom: 24px;
            max-width: 460px;
        }

        /* ============================================ */
        /* INFO CARDS - FIXED */
        /* ============================================ */
        .project-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 28px;
            max-width: 480px;
        }

        .info-card {
            background: rgba(255, 255, 255, 0.6);
            border: 2px solid rgba(0, 0, 0, 0.06);
            border-radius: 12px;
            padding: 14px 18px;
            transition: all 0.4s ease;
        }

        .info-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(108, 99, 255, 0.1);
        }

        .info-card .label {
            color: rgba(0, 0, 0, 0.3);
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            display: block;
            margin-bottom: 3px;
        }

        .info-card .value {
            color: rgba(0, 0, 0, 0.85);
            font-size: 15px;
            font-weight: 500;
        }

        .info-card .value .highlight-text {
            color: #6c63ff;
            font-weight: 600;
        }

        .info-card .value .badge-role {
            display: inline-block;
            background: rgba(108, 99, 255, 0.1);
            color: #6c63ff;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 10px;
            border-radius: 50px;
            margin-left: 6px;
        }

        .info-card .value .badge-roll {
            display: inline-block;
            background: rgba(0, 210, 255, 0.1);
            color: #00d2ff;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 10px;
            border-radius: 50px;
            margin-left: 6px;
        }

        .info-card .value i {
            font-size: 13px;
            margin-right: 4px;
            color: rgba(0, 0, 0, 0.2);
        }

        /* ============================================ */
        /* BUTTONS */
        /* ============================================ */
        .action-buttons {
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
        }

        .btn-custom {
            padding: 14px 32px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 16px;
            font-family: 'Inter', sans-serif;
            transition: all 0.4s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            border: none;
            cursor: pointer;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, #6c63ff, #5a52d5);
            color: #ffffff;
            box-shadow: 0 4px 25px rgba(108, 99, 255, 0.25);
        }

        .btn-primary-custom:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 40px rgba(108, 99, 255, 0.4);
            color: #ffffff;
        }

        .btn-secondary-custom {
            background: rgba(255, 255, 255, 0.5);
            color: rgba(0, 0, 0, 0.7);
            border: 2px solid rgba(0, 0, 0, 0.08);
        }

        .btn-secondary-custom:hover {
            background: rgba(255, 255, 255, 0.7);
            color: #1a1a2e;
            transform: translateY(-3px);
            border-color: rgba(108, 99, 255, 0.3);
        }

        /* ============================================ */
        /* FEATURES SIDE - FIXED */
        /* ============================================ */
        .features-side {
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            z-index: 1;
        }

        .features-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .feature-card {
            background: rgba(255, 255, 255, 0.5);
            border: 2px solid rgba(0, 0, 0, 0.06);
            border-radius: 16px;
            padding: 20px 20px;
            transition: all 0.4s ease;
            cursor: default;
        }

        .feature-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 30px rgba(108, 99, 255, 0.1);
        }

        .feature-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            font-size: 20px;
        }

        .feature-icon.purple { background: rgba(108, 99, 255, 0.1); color: #6c63ff; }
        .feature-icon.blue { background: rgba(0, 210, 255, 0.1); color: #00d2ff; }
        .feature-icon.green { background: rgba(46, 213, 115, 0.1); color: #2ed573; }
        .feature-icon.orange { background: rgba(255, 107, 107, 0.1); color: #ff6b6b; }

        .feature-title {
            color: #1a1a2e;
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 3px;
        }

        .feature-desc {
            color: rgba(0, 0, 0, 0.4);
            font-size: 13px;
            font-weight: 300;
            line-height: 1.4;
        }

        /* ============================================ */
        /* RESPONSIVE - FIXED */
        /* ============================================ */

        /* Tablet */
        @media (max-width: 992px) {
            .welcome-wrapper {
                grid-template-columns: 1fr;
                padding: 35px 30px;
                gap: 30px;
                border-radius: 24px;
            }

            .main-title {
                font-size: 44px;
            }

            .content-side {
                text-align: center;
            }

            .subtitle {
                max-width: 100%;
                margin-left: auto;
                margin-right: auto;
            }

            .project-info {
                max-width: 100%;
                margin-left: auto;
                margin-right: auto;
            }

            .badge {
                margin-left: auto;
                margin-right: auto;
            }

            .action-buttons {
                justify-content: center;
            }

            .features-side {
                order: -1;
            }
        }

        /* Mobile L */
        @media (max-width: 768px) {
            .welcome-wrapper {
                padding: 28px 20px;
                border-radius: 20px;
                gap: 24px;
            }

            .main-title {
                font-size: 36px;
            }

            .subtitle {
                font-size: 16px;
            }

            .project-info {
                grid-template-columns: 1fr;
                gap: 10px;
            }

            .badge {
                padding: 6px 16px;
                font-size: 12px;
            }

            .badge span {
                font-size: 12px;
            }

            .features-grid {
                grid-template-columns: 1fr 1fr;
                gap: 12px;
            }

            .feature-card {
                padding: 16px 16px;
                border-radius: 14px;
            }

            .feature-icon {
                width: 40px;
                height: 40px;
                font-size: 17px;
                margin-bottom: 10px;
            }

            .feature-title {
                font-size: 14px;
            }

            .feature-desc {
                font-size: 12px;
            }

            .info-card {
                padding: 12px 14px;
            }

            .info-card .value {
                font-size: 14px;
            }

            .btn-custom {
                padding: 12px 24px;
                font-size: 14px;
            }

            .action-buttons {
                gap: 10px;
            }
        }

        /* Mobile S */
        @media (max-width: 576px) {
            body {
                padding: 10px;
            }

            .welcome-container {
                padding: 10px;
            }

            .welcome-wrapper {
                padding: 20px 16px;
                border-radius: 16px;
                gap: 20px;
            }

            .main-title {
                font-size: 28px;
            }

            .subtitle {
                font-size: 14px;
                margin-bottom: 18px;
            }

            .badge {
                padding: 4px 12px;
                gap: 8px;
                margin-bottom: 16px;
            }

            .badge i {
                font-size: 13px;
            }

            .badge span {
                font-size: 11px;
            }

            .features-grid {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
            }

            .feature-card {
                padding: 14px 12px;
                border-radius: 12px;
            }

            .feature-icon {
                width: 36px;
                height: 36px;
                font-size: 15px;
                margin-bottom: 8px;
                border-radius: 10px;
            }

            .feature-title {
                font-size: 13px;
            }

            .feature-desc {
                font-size: 11px;
            }

            .project-info {
                gap: 8px;
                margin-bottom: 20px;
            }

            .info-card {
                padding: 10px 12px;
                border-radius: 10px;
            }

            .info-card .label {
                font-size: 10px;
            }

            .info-card .value {
                font-size: 13px;
            }

            .info-card .value .badge-role,
            .info-card .value .badge-roll {
                font-size: 9px;
                padding: 1px 8px;
            }

            .btn-custom {
                padding: 10px 20px;
                font-size: 13px;
                border-radius: 10px;
                gap: 8px;
                width: 100%;
                justify-content: center;
            }

            .action-buttons {
                flex-direction: column;
                gap: 8px;
            }

            .sparkle {
                display: none !important;
            }

            .twinkle-sparkle {
                display: none !important;
            }

            body::before {
                opacity: 0.3;
            }
        }

        /* Extra Small */
        @media (max-width: 400px) {
            .welcome-wrapper {
                padding: 16px 12px;
                border-radius: 14px;
            }

            .main-title {
                font-size: 24px;
            }

            .subtitle {
                font-size: 13px;
            }

            .features-grid {
                grid-template-columns: 1fr;
                gap: 8px;
            }

            .feature-card {
                padding: 12px 14px;
            }

            .feature-title {
                font-size: 14px;
            }

            .feature-desc {
                font-size: 12px;
            }

            .info-card .value {
                font-size: 12px;
            }

            .btn-custom {
                font-size: 12px;
                padding: 10px 16px;
            }
        }
    </style>
</head>
<body>

<!-- Sparkles -->
<div class="sparkles-container">
    <div class="sparkle sparkle-1"></div>
    <div class="sparkle sparkle-2"></div>
    <div class="sparkle sparkle-3"></div>
    <div class="sparkle sparkle-4"></div>
    <div class="sparkle sparkle-5"></div>
    <div class="sparkle sparkle-6"></div>
    <div class="sparkle sparkle-7"></div>
    <div class="sparkle sparkle-8"></div>
    <div class="sparkle sparkle-9"></div>
    <div class="sparkle sparkle-10"></div>
    <div class="sparkle sparkle-11"></div>
    <div class="sparkle sparkle-12"></div>
    <div class="sparkle sparkle-13"></div>
    <div class="sparkle sparkle-14"></div>
    <div class="sparkle sparkle-15"></div>
    <div class="sparkle sparkle-16"></div>
    <div class="sparkle sparkle-17"></div>
    <div class="sparkle sparkle-18"></div>
    <div class="sparkle sparkle-19"></div>
    <div class="sparkle sparkle-20"></div>
    
    <div class="twinkle-sparkle twinkle-1"></div>
    <div class="twinkle-sparkle twinkle-2"></div>
    <div class="twinkle-sparkle twinkle-3"></div>
    <div class="twinkle-sparkle twinkle-4"></div>
    <div class="twinkle-sparkle twinkle-5"></div>
</div>

<!-- Main Content -->
<div class="welcome-container">
    <div class="welcome-wrapper">
        
        <!-- LEFT SIDE -->
        <div class="content-side">
            <div class="badge">
                <i class="fas fa-graduation-cap"></i>
                <span>{{ $institutionLine ?: $systemName }}</span>
            </div>
            
            <h1 class="main-title">
                {{ $systemName }}
            </h1>
            
            <p class="subtitle">
                Web-Based Digital Thesis Management System using MVC Architecture
            </p>
            
            <!-- Info Cards -->
            <div class="project-info">
                <div class="info-card">
                    <span class="label"><i class="fas fa-user-tie"></i> Supervisor</span>
                    <span class="value">
                        <span class="highlight-text">Dr. Su Myat Thwin</span>
                        <span class="badge-role">Associate Professor</span>
                    </span>
                </div>
                
                <div class="info-card">
                    <span class="label"><i class="fas fa-user-graduate"></i> Student</span>
                    <span class="value">
                        <span class="highlight-text">Mg Than Win Aung</span>
                        <span class="badge-roll">Roll: 2MCS-2</span>
                    </span>
                </div>
                
                <div class="info-card">
                    <span class="label"><i class="fas fa-calendar-alt"></i> Academic Year</span>
                    <span class="value">2025 - 2026</span>
                </div>
                
                <div class="info-card">
                    <span class="label"><i class="fas fa-code"></i> Project Type</span>
                    <span class="value">Web-based System</span>
                </div>
            </div>
            
            <!-- Buttons -->
            <div class="action-buttons">
                <a href="{{ route('login') }}" class="btn-custom btn-primary-custom">
                    <i class="fas fa-sign-in-alt"></i> Sign In
                </a>
                <a href="{{ route('register') }}" class="btn-custom btn-secondary-custom">
                    <i class="fas fa-user-plus"></i> Create Account
                </a>
            </div>
        </div>
        
        <!-- RIGHT SIDE - FEATURES -->
        <div class="features-side">
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon purple">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="feature-title">Proposal Submission</div>
                    <div class="feature-desc">Submit and track thesis proposals</div>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon blue">
                        <i class="fas fa-book"></i>
                    </div>
                    <div class="feature-title">Chapter Management</div>
                    <div class="feature-desc">Upload and manage chapters easily</div>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon green">
                        <i class="fas fa-comments"></i>
                    </div>
                    <div class="feature-title">Real-time Feedback</div>
                    <div class="feature-desc">Get instant feedback and reviews</div>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon orange">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="feature-title">Secure Workflow</div>
                    <div class="feature-desc">Organized and secure process</div>
                </div>
            </div>
        </div>
        
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
