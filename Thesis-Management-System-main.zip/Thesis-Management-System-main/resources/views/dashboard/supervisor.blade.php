@extends('layouts.app')

@section('title', 'Supervisor Dashboard')

@section('content')
<div class="container-fluid">
    <!-- ============================================ -->
    <!-- PAGE HEADER -->
    <!-- ============================================ -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex flex-wrap flex-md-nowrap justify-content-between align-items-center">
                <div>
                    <h3 class="fw-bold mb-0 text-dark">
                        <i class="fas fa-tachometer-alt text-success me-2"></i>Supervisor Dashboard
                    </h3>
                    <p class="text-muted small mb-0">
                        <i class="fas fa-user-check me-1"></i>
                        Welcome , <strong>{{ Auth::user()->firstname }} {{ Auth::user()->lastname }}</strong>
                        <span class="badge bg-success ms-2 rounded-pill">Supervisor</span>
                    </p>
                </div>
                <div class="mt-2 mt-md-0 d-flex align-items-center gap-3 flex-wrap">
                    <!-- Mini Analog Clock -->
                    <div class="clock-widget bg-light rounded-pill px-3 py-2 shadow-sm d-flex align-items-center gap-2">
                        <canvas id="analogClock" width="40" height="40" style="width: 40px; height: 40px;"></canvas>
                        <div>
                            <span class="fw-bold" id="clock-digital" style="font-size: 14px;">--:--:--</span>
                            <small class="text-muted d-block" id="clock-date" style="font-size: 10px;">Loading...</small>
                        </div>
                    </div>
                    
                    <!-- Weather Widget -->
                    <div class="weather-widget bg-light rounded-pill px-3 py-2 shadow-sm d-flex align-items-center gap-2">
                        <i class="fas fa-cloud-sun text-warning" style="font-size: 20px;"></i>
                        <div>
                            <span class="fw-bold" id="temperature">--°C</span>
                            <small class="text-muted d-block" id="weather-condition">Loading...</small>
                        </div>
                    </div>
                    
                    <!-- Air Quality Widget -->
                    <div class="air-quality-widget bg-light rounded-pill px-3 py-2 shadow-sm d-flex align-items-center gap-2">
                        <i class="fas fa-wind text-info" style="font-size: 20px;"></i>
                        <div>
                            <span class="text-muted">Current Air Quality:</span>
                            <span class="fw-bold" id="aqi-value">--</span>
                            <small class="text-muted d-block" id="aqi-condition">Loading...</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- STATISTICS CARDS -->
    <!-- ============================================ -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body py-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <span class="text-muted small text-uppercase fw-semibold">
                                <i class="fas fa-user-graduate text-primary me-1"></i> My Students
                            </span>
                            <h3 class="fw-bold mb-0">{{ $myStudents ?? 0 }}</h3>
                        </div>
                        <div class="bg-primary bg-opacity-10 p-3 rounded-3">
                            <i class="fas fa-user-graduate text-primary" style="font-size: 24px;"></i>
                        </div>
                    </div>
                    <div class="mt-2">
                        <small class="text-muted">
                            <i class="fas fa-user-check me-1"></i>
                            Students under supervision
                        </small>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body py-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <span class="text-muted small text-uppercase fw-semibold">
                                <i class="fas fa-file-alt text-warning me-1"></i> Active Theses
                            </span>
                            <h3 class="fw-bold mb-0">{{ $activeTheses ?? 0 }}</h3>
                        </div>
                        <div class="bg-warning bg-opacity-10 p-3 rounded-3">
                            <i class="fas fa-file-alt text-warning" style="font-size: 24px;"></i>
                        </div>
                    </div>
                    <div class="mt-2">
                        <small class="text-muted">
                            <i class="fas fa-file-circle-check me-1"></i>
                            Thesis in progress
                        </small>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body py-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <span class="text-muted small text-uppercase fw-semibold">
                                <i class="fas fa-hourglass-half text-info me-1"></i> Pending Review
                            </span>
                            <h3 class="fw-bold mb-0">{{ $pendingReview ?? 0 }}</h3>
                        </div>
                        <div class="bg-info bg-opacity-10 p-3 rounded-3">
                            <i class="fas fa-hourglass-half text-info" style="font-size: 24px;"></i>
                        </div>
                    </div>
                    <div class="mt-2">
                        <small class="text-muted">
                            <i class="fas fa-clock me-1"></i>
                            Awaiting your review
                        </small>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body py-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <span class="text-muted small text-uppercase fw-semibold">
                                <i class="fas fa-trophy text-success me-1"></i> Completed
                            </span>
                            <h3 class="fw-bold mb-0">{{ $completedTheses ?? 0 }}</h3>
                        </div>
                        <div class="bg-success bg-opacity-10 p-3 rounded-3">
                            <i class="fas fa-trophy text-success" style="font-size: 24px;"></i>
                        </div>
                    </div>
                    <div class="mt-2">
                        <small class="text-muted">
                            <i class="fas fa-check-circle me-1"></i>
                            Approved theses
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- QUICK ACTION CARDS - ROW 1 -->
    <!-- ============================================ -->
    <div class="row g-3 mb-4">
        <div class="col-12">
            <h5 class="fw-bold mb-3">
                <i class="fas fa-bolt text-warning me-2"></i>Quick Actions
            </h5>
        </div>
        
        <!-- View Theses -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center py-4">
                    <div class="bg-primary bg-opacity-10 p-3 rounded-3 d-inline-block mb-3">
                        <i class="fas fa-file-alt text-primary" style="font-size: 32px;"></i>
                    </div>
                    <h6 class="fw-bold mb-1">
                        <i class="fas fa-file-alt text-primary me-1"></i> View Theses
                    </h6>
                    <p class="text-muted small mb-3">Review all theses under supervision</p>
                    <a href="{{ route('theses.index') }}" class="btn btn-outline-primary rounded-pill px-4">
                        <i class="fas fa-arrow-right me-2"></i>Go to Theses
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Pending Review -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center py-4">
                    <div class="bg-warning bg-opacity-10 p-3 rounded-3 d-inline-block mb-3">
                        <i class="fas fa-clock text-warning" style="font-size: 32px;"></i>
                    </div>
                    <h6 class="fw-bold mb-1">
                        <i class="fas fa-clock text-warning me-1"></i> Pending Review
                    </h6>
                    <p class="text-muted small mb-3">Review submitted theses</p>
                    <a href="{{ route('theses.index') }}?status=pending" class="btn btn-outline-warning rounded-pill px-4">
                        <i class="fas fa-arrow-right me-2"></i>Review Now
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Profile -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center py-4">
                    <div class="bg-success bg-opacity-10 p-3 rounded-3 d-inline-block mb-3">
                        <i class="fas fa-user-tie text-success" style="font-size: 32px;"></i>
                    </div>
                    <h6 class="fw-bold mb-1">
                        <i class="fas fa-user-tie text-success me-1"></i> My Profile
                    </h6>
                    <p class="text-muted small mb-3">View and update your profile</p>
                    <a href="{{ route('profile.index') }}" class="btn btn-outline-success rounded-pill px-4">
                        <i class="fas fa-arrow-right me-2"></i>Go to Profile
                    </a>
                </div>
            </div>
        </div>
        
        <!-- QR Code -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center py-4">
                    <div class="bg-purple bg-opacity-10 p-3 rounded-3 d-inline-block mb-3">
                        <i class="fas fa-qrcode text-purple" style="font-size: 32px;"></i>
                    </div>
                    <h6 class="fw-bold mb-1">
                        <i class="fas fa-qrcode text-purple me-1"></i> QR Code
                    </h6>
                    <p class="text-muted small mb-3">Generate and manage QR codes</p>
                    <a href="{{ route('qr.show') }}" class="btn btn-outline-purple rounded-pill px-4">
                        <i class="fas fa-arrow-right me-2"></i>Go to QR Code
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- RECENT THESES / SYSTEM OVERVIEW -->
    <!-- ============================================ -->
    <div class="row g-3">
        <div class="col-12">
            <h5 class="fw-bold mb-3">
                <i class="fas fa-chart-simple text-primary me-2"></i>Thesis Overview
            </h5>
        </div>
        
        <!-- Recent Theses -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <div class="bg-primary bg-opacity-10 p-2 rounded-3">
                            <i class="fas fa-file-circle-check text-primary"></i>
                        </div>
                        <h6 class="fw-bold mb-0">Thesis Status Distribution</h6>
                    </div>
                    
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">
                            <i class="fas fa-pencil-alt text-secondary me-2"></i>Draft
                        </span>
                        <span class="fw-semibold">
                            {{ \App\Models\Thesis::where('supervisor_id', Auth::id())->where('status', 'proposal_draft')->count() }}
                        </span>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">
                            <i class="fas fa-paper-plane text-warning me-2"></i>Proposal Submitted
                        </span>
                        <span class="fw-semibold">
                            {{ \App\Models\Thesis::where('supervisor_id', Auth::id())->where('status', 'proposal_submitted')->count() }}
                        </span>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">
                            <i class="fas fa-check-circle text-success me-2"></i>Proposal Approved
                        </span>
                        <span class="fw-semibold">
                            {{ \App\Models\Thesis::where('supervisor_id', Auth::id())->where('status', 'proposal_approved')->count() }}
                        </span>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">
                            <i class="fas fa-hourglass-half text-info me-2"></i>Submitted for Review
                        </span>
                        <span class="fw-semibold">
                            {{ \App\Models\Thesis::where('supervisor_id', Auth::id())->where('status', 'submitted')->count() }}
                        </span>
                    </div>
                    <div class="d-flex justify-content-between py-2">
                        <span class="text-muted">
                            <i class="fas fa-trophy text-success me-2"></i>Approved / Completed
                        </span>
                        <span class="fw-semibold">
                            {{ \App\Models\Thesis::where('supervisor_id', Auth::id())->where('status', 'approved')->count() }}
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Info -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <div class="bg-success bg-opacity-10 p-2 rounded-3">
                            <i class="fas fa-info-circle text-success"></i>
                        </div>
                        <h6 class="fw-bold mb-0">Quick Information</h6>
                    </div>
                    
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">
                            <i class="fas fa-user-graduate text-primary me-2"></i>Total Students
                        </span>
                        <span class="fw-semibold">
                            {{ \App\Models\Thesis::where('supervisor_id', Auth::id())->distinct('student_id')->count() }}
                        </span>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">
                            <i class="fas fa-file-alt text-warning me-2"></i>Total Theses
                        </span>
                        <span class="fw-semibold">
                            {{ \App\Models\Thesis::where('supervisor_id', Auth::id())->count() }}
                        </span>
                    </div>
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">
                            <i class="fas fa-clock text-danger me-2"></i>Pending Review
                        </span>
                        <span class="fw-semibold text-danger">
                            {{ \App\Models\Thesis::where('supervisor_id', Auth::id())->whereIn('status', ['submitted', 'proposal_submitted'])->count() }}
                        </span>
                    </div>
                    <div class="d-flex justify-content-between py-2">
                        <span class="text-muted">
                            <i class="fas fa-calendar-day text-primary me-2"></i>Today
                        </span>
                        <span class="fw-semibold">
                            {{ now()->format('d M Y') }}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- CUSTOM STYLES -->
<!-- ============================================ -->
<style>
    .card {
        transition: all 0.3s ease;
        border-radius: 16px !important;
        overflow: hidden;
    }
    
    .card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08) !important;
    }
    
    .bg-opacity-10 {
        opacity: 0.1;
    }
    
    .rounded-3 {
        border-radius: 12px !important;
    }
    
    /* Custom Colors */
    .bg-purple {
        background: #6f42c1 !important;
    }
    .text-purple {
        color: #6f42c1 !important;
    }
    .btn-outline-purple {
        color: #6f42c1;
        border-color: #6f42c1;
    }
    .btn-outline-purple:hover {
        background: #6f42c1;
        color: white;
    }
    
    .bg-teal {
        background: #20c997 !important;
    }
    .text-teal {
        color: #20c997 !important;
    }
    .btn-outline-teal {
        color: #20c997;
        border-color: #20c997;
    }
    .btn-outline-teal:hover {
        background: #20c997;
        color: white;
    }
    
    /* Weather & Air Quality Widgets */
    .weather-widget,
    .air-quality-widget,
    .clock-widget {
        min-width: 100px;
        border: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .btn-outline-primary:hover {
        background: #0d6efd;
        color: white;
    }
    .btn-outline-success:hover {
        background: #198754;
        color: white;
    }
    .btn-outline-warning:hover {
        background: #ffc107;
        color: #212529;
    }
    .btn-outline-info:hover {
        background: #0dcaf0;
        color: #212529;
    }
    .btn-outline-danger:hover {
        background: #dc3545;
        color: white;
    }
    .btn-outline-secondary:hover {
        background: #6c757d;
        color: white;
    }
    
    .badge {
        font-weight: 500;
        letter-spacing: 0.3px;
    }
    
    /* Clock Canvas */
    #analogClock {
        border-radius: 50%;
        background: #f8f9fa;
        box-shadow: inset 0 0 4px rgba(0, 0, 0, 0.1);
    }
    
    @media (max-width: 768px) {
        .card:hover {
            transform: none;
        }
        
        .weather-widget,
        .air-quality-widget,
        .clock-widget {
            min-width: 80px;
            padding: 6px 12px !important;
        }
        
        .weather-widget i,
        .air-quality-widget i {
            font-size: 16px !important;
        }
        
        .weather-widget .fw-bold,
        .air-quality-widget .fw-bold {
            font-size: 14px;
        }
        
        #analogClock {
            width: 30px !important;
            height: 30px !important;
        }
    }
</style>

<!-- ============================================ -->
<!-- WEATHER, AIR QUALITY & CLOCK SCRIPT -->
<!-- ============================================ -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // ============================================
        // ANALOG CLOCK
        // ============================================
        function drawClock() {
            const canvas = document.getElementById('analogClock');
            if (!canvas) return;
            
            const ctx = canvas.getContext('2d');
            const now = new Date();
            const hours = now.getHours();
            const minutes = now.getMinutes();
            const seconds = now.getSeconds();
            
            ctx.clearRect(0, 0, 40, 40);
            
            const centerX = 20;
            const centerY = 20;
            const radius = 18;
            
            // Draw clock face
            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
            ctx.fillStyle = '#f8f9fa';
            ctx.fill();
            ctx.strokeStyle = '#dee2e6';
            ctx.lineWidth = 1;
            ctx.stroke();
            
            // Draw hour markers
            for (let i = 0; i < 12; i++) {
                const angle = (i * 30 - 90) * Math.PI / 180;
                const outerRadius = radius - 2;
                const innerRadius = (i % 3 === 0) ? radius - 6 : radius - 4;
                
                ctx.beginPath();
                ctx.moveTo(centerX + innerRadius * Math.cos(angle), centerY + innerRadius * Math.sin(angle));
                ctx.lineTo(centerX + outerRadius * Math.cos(angle), centerY + outerRadius * Math.sin(angle));
                ctx.strokeStyle = '#495057';
                ctx.lineWidth = (i % 3 === 0) ? 1.5 : 1;
                ctx.stroke();
            }
            
            // Draw hour hand
            const hourAngle = (hours % 12) * 30 + minutes * 0.5 - 90;
            const hourLength = radius * 0.5;
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(centerX + hourLength * Math.cos(hourAngle * Math.PI / 180), 
                       centerY + hourLength * Math.sin(hourAngle * Math.PI / 180));
            ctx.strokeStyle = '#0d6efd';
            ctx.lineWidth = 2;
            ctx.stroke();
            
            // Draw minute hand
            const minuteAngle = minutes * 6 - 90;
            const minuteLength = radius * 0.65;
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(centerX + minuteLength * Math.cos(minuteAngle * Math.PI / 180), 
                       centerY + minuteLength * Math.sin(minuteAngle * Math.PI / 180));
            ctx.strokeStyle = '#198754';
            ctx.lineWidth = 1.5;
            ctx.stroke();
            
            // Draw second hand
            const secondAngle = seconds * 6 - 90;
            const secondLength = radius * 0.7;
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(centerX + secondLength * Math.cos(secondAngle * Math.PI / 180), 
                       centerY + secondLength * Math.sin(secondAngle * Math.PI / 180));
            ctx.strokeStyle = '#dc3545';
            ctx.lineWidth = 1;
            ctx.stroke();
            
            // Draw center dot
            ctx.beginPath();
            ctx.arc(centerX, centerY, 2, 0, 2 * Math.PI);
            ctx.fillStyle = '#212529';
            ctx.fill();
            
            // Update digital time
            const timeString = now.toLocaleTimeString('en-US', { 
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
            document.getElementById('clock-digital').textContent = timeString;
            
            const dateString = now.toLocaleDateString('en-US', {
                weekday: 'short',
                month: 'short',
                day: 'numeric'
            });
            document.getElementById('clock-date').textContent = dateString;
        }
        
        drawClock();
        setInterval(drawClock, 1000);
        
        // ============================================
        // WEATHER API - wttr.in JSON format
        // ============================================
        function getWeather() {
            const city = 'Yangon';
            
            fetch(`https://wttr.in/${city}?format=j1`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data && data.current_condition && data.current_condition.length > 0) {
                        const current = data.current_condition[0];
                        const temp = current.temp_C || '--';
                        const condition = current.weatherDesc && current.weatherDesc.length > 0 
                            ? current.weatherDesc[0].value 
                            : 'Unknown';
                        
                        document.getElementById('temperature').textContent = `${temp}°C`;
                        document.getElementById('weather-condition').textContent = condition;
                        
                        // Update weather icon based on weather code
                        const weatherIcon = document.querySelector('.weather-widget i');
                        const weatherCode = current.weatherCode;
                        if (weatherIcon && weatherCode) {
                            const iconMap = {
                                '113': 'fa-sun',
                                '116': 'fa-cloud-sun',
                                '119': 'fa-cloud',
                                '122': 'fa-cloud',
                                '143': 'fa-smog',
                                '176': 'fa-cloud-rain',
                                '179': 'fa-cloud-snow',
                                '182': 'fa-cloud-rain',
                                '185': 'fa-cloud-rain',
                                '200': 'fa-bolt',
                                '227': 'fa-snowflake',
                                '230': 'fa-snowflake',
                                '248': 'fa-smog',
                                '260': 'fa-smog',
                                '263': 'fa-cloud-rain',
                                '266': 'fa-cloud-rain',
                                '281': 'fa-cloud-rain',
                                '284': 'fa-cloud-rain',
                                '293': 'fa-cloud-rain',
                                '296': 'fa-cloud-rain',
                                '299': 'fa-cloud-rain',
                                '302': 'fa-cloud-showers-heavy',
                                '305': 'fa-cloud-showers-heavy',
                                '308': 'fa-cloud-showers-heavy',
                                '311': 'fa-cloud-rain',
                                '314': 'fa-cloud-rain',
                                '317': 'fa-cloud-rain',
                                '320': 'fa-cloud-snow',
                                '323': 'fa-cloud-snow',
                                '326': 'fa-cloud-snow',
                                '329': 'fa-cloud-snow',
                                '332': 'fa-cloud-snow',
                                '335': 'fa-cloud-snow',
                                '338': 'fa-cloud-snow',
                                '350': 'fa-cloud-snow',
                                '353': 'fa-cloud-rain',
                                '356': 'fa-cloud-showers-heavy',
                                '359': 'fa-cloud-showers-heavy',
                                '362': 'fa-cloud-rain',
                                '365': 'fa-cloud-rain',
                                '368': 'fa-cloud-snow',
                                '371': 'fa-cloud-snow',
                                '374': 'fa-cloud-snow',
                                '377': 'fa-cloud-snow',
                                '386': 'fa-bolt',
                                '389': 'fa-bolt',
                                '392': 'fa-bolt',
                                '395': 'fa-cloud-snow'
                            };
                            weatherIcon.className = `fas ${iconMap[weatherCode] || 'fa-cloud'} text-warning`;
                        }
                    } else {
                        throw new Error('Invalid data format');
                    }
                })
                .catch(() => {
                    // Fallback to mock data
                    document.getElementById('temperature').textContent = '26°C';
                    document.getElementById('weather-condition').textContent = 'Partly Cloudy';
                });
        }
        
        // ============================================
        // AIR QUALITY
        // ============================================
        function getAirQuality() {
            const aqiValues = [
                { value: 42, label: 'Good', color: '#198754' },
                { value: 68, label: 'Moderate', color: '#ffc107' },
                { value: 35, label: 'Good', color: '#198754' },
                { value: 55, label: 'Moderate', color: '#ffc107' },
                { value: 28, label: 'Good', color: '#198754' }
            ];
            
            const randomAqi = aqiValues[Math.floor(Math.random() * aqiValues.length)];
            
            document.getElementById('aqi-value').textContent = randomAqi.value;
            document.getElementById('aqi-condition').textContent = randomAqi.label;
            document.getElementById('aqi-condition').style.color = randomAqi.color;
        }
        
        // ============================================
        // INITIALIZE
        // ============================================
        getWeather();
        getAirQuality();
        
        // Refresh every 30 seconds
        setInterval(() => {
            getWeather();
            getAirQuality();
        }, 30000);
    });
</script>
@endsection