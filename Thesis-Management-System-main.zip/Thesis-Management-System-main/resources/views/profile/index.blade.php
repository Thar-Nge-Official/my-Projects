{{-- resources/views/profile/index.blade.php --}}

@extends('layouts.app')

@section('title', 'My Profile')

@section('content')
<div class="container-fluid">
    <!-- ============================================ -->
    <!-- PAGE HEADER -->
    <!-- ============================================ -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center">
                <div>
                    <h2 class="fw-bold mb-1 text-dark">
                        <i class="fas fa-user-circle text-primary me-2"></i>My Profile
                    </h2>
                    <p class="text-muted mb-0">Manage your profile information and account settings</p>
                </div>
                <div class="mt-2 mt-sm-0">
                    <span class="badge bg-{{ Auth::user()->type == 'admin' ? 'danger' : (Auth::user()->type == 'supervisor' ? 'warning' : 'info') }} fs-6 px-4 py-2 rounded-pill shadow-sm">
                        <i class="fas fa-{{ Auth::user()->type == 'admin' ? 'user-shield' : (Auth::user()->type == 'supervisor' ? 'user-tie' : 'user-graduate') }} me-1"></i>
                        {{ ucfirst(Auth::user()->type) }}
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- STATISTICS / QUICK INFO CARDS -->
    <!-- ============================================ -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100 rounded-4 bg-gradient-primary text-white">
                <div class="card-body text-center py-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="fas fa-user-graduate" style="font-size: 24px;"></i>
                        <div>
                            <h6 class="mb-0 fw-bold">{{ ucfirst($user->type) }}</h6>
                            <small class="opacity-75">Role</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100 rounded-4 bg-gradient-success text-white">
                <div class="card-body text-center py-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="fas fa-calendar-alt" style="font-size: 24px;"></i>
                        <div>
                            <h6 class="mb-0 fw-bold">{{ $user->created_at->format('d M Y') }}</h6>
                            <small class="opacity-75">Member Since</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100 rounded-4 bg-gradient-info text-white">
                <div class="card-body text-center py-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="fas fa-envelope" style="font-size: 24px;"></i>
                        <div>
                            <h6 class="mb-0 fw-bold text-truncate" style="max-width: 120px;">{{ $user->email }}</h6>
                            <small class="opacity-75">Email</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm h-100 rounded-4 bg-gradient-warning text-dark">
                <div class="card-body text-center py-3">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="fas fa-circle-check" style="font-size: 24px;"></i>
                        <div>
                            <h6 class="mb-0 fw-bold">Active</h6>
                            <small class="opacity-75">Status</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- MAIN CONTENT -->
    <!-- ============================================ -->
    <div class="row g-4">
        <!-- ============================================ -->
        <!-- LEFT COLUMN - PROFILE CARD -->
        <!-- ============================================ -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden glassmorphism">
                <div class="card-body p-4 text-center">
                    <!-- Cover Image -->
                    <div class="cover-image mb-4" style="height: 80px; background: linear-gradient(135deg, #0d6efd, #6c63ff); border-radius: 12px 12px 0 0; margin: -24px -24px 0 -24px;"></div>
                    
                    <!-- Profile Picture -->
                    <div class="position-relative" style="margin-top: -50px;">
                        <div class="position-relative d-inline-block">
                            @php
                                $avatarUrl = ($user->avatar && $user->avatar != 'no-image-available.png') 
                                    ? asset('storage/avatars/' . rawurlencode($user->avatar)) 
                                    : null;
                            @endphp
                            
                            @if($avatarUrl)
                                <img src="{{ $avatarUrl }}" 
                                     alt="{{ $user->firstname }}" 
                                     class="rounded-circle border border-4 border-white shadow-lg avatar-clickable"
                                     style="width: 120px; height: 120px; object-fit: cover; cursor: pointer;"
                                     loading="lazy"
                                     onclick="openAvatarModal()">
                            @else
                                <div class="rounded-circle bg-gradient-primary d-flex align-items-center justify-content-center mx-auto border border-4 border-white shadow-lg"
                                     style="width: 120px; height: 120px; font-size: 48px; color: white; cursor: pointer;"
                                     onclick="openAvatarModal()">
                                    {{ strtoupper(substr($user->firstname, 0, 1)) }}
                                </div>
                            @endif
                            
                            <!-- Edit Badge -->
                            <div class="position-absolute bottom-0 end-0 bg-primary rounded-circle p-1 shadow-sm" 
                                 style="width: 32px; height: 32px; border: 2px solid white; cursor: pointer;"
                                 onclick="document.getElementById('avatarInput').click()">
                                <i class="fas fa-camera text-white" style="font-size: 12px; margin-top: 3px;"></i>
                            </div>
                        </div>
                    </div>

                    <h4 class="fw-bold mt-3 mb-0">{{ $user->firstname }} {{ $user->lastname }}</h4>
                    <p class="text-muted mb-2">{{ $user->email }}</p>

                    <div class="d-flex justify-content-center gap-2 mb-3">
                        <span class="badge bg-{{ $user->type == 'admin' ? 'danger' : ($user->type == 'supervisor' ? 'warning' : 'info') }} rounded-pill px-3 py-2">
                            <i class="fas fa-{{ $user->type == 'admin' ? 'user-shield' : ($user->type == 'supervisor' ? 'user-tie' : 'user-graduate') }} me-1"></i>
                            {{ ucfirst($user->type) }}
                        </span>
                        @if($user->rank)
                            <span class="badge bg-secondary rounded-pill px-3 py-2">
                                <i class="fas fa-user-tie me-1"></i> {{ $user->rank }}
                            </span>
                        @endif
                    </div>

                    <hr>

                    <!-- User Details -->
                    <div class="text-start">
                        <div class="detail-item d-flex align-items-center gap-3 py-2 border-bottom">
                            <div class="detail-icon bg-primary bg-opacity-10 rounded-3 p-2">
                                <i class="fas fa-id-badge text-primary"></i>
                            </div>
                            <div>
                                <small class="text-muted d-block">Role</small>
                                <span class="fw-semibold">{{ ucfirst($user->type) }}</span>
                            </div>
                        </div>
                        @if($user->roll_no)
                            <div class="detail-item d-flex align-items-center gap-3 py-2 border-bottom">
                                <div class="detail-icon bg-info bg-opacity-10 rounded-3 p-2">
                                    <i class="fas fa-id-card text-info"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Roll Number</small>
                                    <span class="fw-semibold">{{ $user->roll_no }}</span>
                                </div>
                            </div>
                        @endif
                        @if($user->class)
                            <div class="detail-item d-flex align-items-center gap-3 py-2 border-bottom">
                                <div class="detail-icon bg-success bg-opacity-10 rounded-3 p-2">
                                    <i class="fas fa-chalkboard-user text-success"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Class</small>
                                    <span class="fw-semibold">{{ $user->class }}</span>
                                </div>
                            </div>
                        @endif
                        @if($user->rank)
                            <div class="detail-item d-flex align-items-center gap-3 py-2">
                                <div class="detail-icon bg-warning bg-opacity-10 rounded-3 p-2">
                                    <i class="fas fa-user-tie text-warning"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Rank</small>
                                    <span class="fw-semibold">{{ $user->rank }}</span>
                                </div>
                            </div>
                        @endif
                        <div class="detail-item d-flex align-items-center gap-3 py-2 border-top mt-2 pt-2">
                            <div class="detail-icon bg-secondary bg-opacity-10 rounded-3 p-2">
                                <i class="fas fa-calendar-alt text-secondary"></i>
                            </div>
                            <div>
                                <small class="text-muted d-block">Member Since</small>
                                <span class="fw-semibold">{{ $user->created_at->format('d M, Y') }}</span>
                            </div>
                        </div>
                    </div>

                    <!-- Hidden file input -->
                    <form action="{{ route('profile.update') }}" method="POST" enctype="multipart/form-data" id="avatarForm" style="display: none;">
                        @csrf
                        @method('PUT')
                        <input type="file" id="avatarInput" name="avatar" accept="image/*" onchange="document.getElementById('avatarForm').submit()">
                    </form>
                </div>
            </div>
        </div>

        <!-- ============================================ -->
        <!-- RIGHT COLUMN - FORMS -->
        <!-- ============================================ -->
        <div class="col-lg-8">
            <!-- ============================================ -->
            <!-- PROFILE INFORMATION -->
            <!-- ============================================ -->
            <div class="card border-0 shadow-sm rounded-4 mb-4 glassmorphism">
                <div class="card-header bg-transparent border-0 p-4 pb-0">
                    <div class="d-flex align-items-center gap-3">
                        <div class="bg-primary bg-opacity-10 p-3 rounded-3">
                            <i class="fas fa-edit text-primary" style="font-size: 24px;"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0">Profile Information</h5>
                            <p class="text-muted small mb-0">Update your personal information</p>
                        </div>
                    </div>
                </div>
                <div class="card-body p-4">
                    @if($errors->any())
                        <div class="alert alert-danger border-0 rounded-3 mb-4">
                            <div class="d-flex align-items-start gap-2">
                                <i class="fas fa-circle-exclamation mt-1"></i>
                                <div>
                                    <strong>Please fix the following errors:</strong>
                                    <ul class="mb-0 mt-1 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endif

                    <form action="{{ route('profile.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" 
                                           class="form-control @error('firstname') is-invalid @enderror" 
                                           id="firstname" 
                                           name="firstname" 
                                           value="{{ old('firstname', $user->firstname) }}" 
                                           placeholder="First Name"
                                           required>
                                    <label for="firstname">
                                        <i class="fas fa-user text-primary me-1"></i> First Name <span class="text-danger">*</span>
                                    </label>
                                    @error('firstname')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" 
                                           class="form-control @error('lastname') is-invalid @enderror" 
                                           id="lastname" 
                                           name="lastname" 
                                           value="{{ old('lastname', $user->lastname) }}" 
                                           placeholder="Last Name"
                                           required>
                                    <label for="lastname">
                                        <i class="fas fa-user text-primary me-1"></i> Last Name <span class="text-danger">*</span>
                                    </label>
                                    @error('lastname')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="email" 
                                           class="form-control @error('email') is-invalid @enderror" 
                                           id="email" 
                                           name="email" 
                                           value="{{ old('email', $user->email) }}" 
                                           placeholder="Email"
                                           required>
                                    <label for="email">
                                        <i class="fas fa-envelope text-primary me-1"></i> Email <span class="text-danger">*</span>
                                    </label>
                                    @error('email')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" 
                                           class="form-control @error('phone') is-invalid @enderror" 
                                           id="phone" 
                                           name="phone" 
                                           value="{{ old('phone', $user->phone ?? '') }}" 
                                           placeholder="Phone Number">
                                    <label for="phone">
                                        <i class="fas fa-phone text-primary me-1"></i> Phone Number
                                    </label>
                                    @error('phone')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control @error('address') is-invalid @enderror" 
                                              id="address" 
                                              name="address" 
                                              placeholder="Address"
                                              style="height: 100px;">{{ old('address', $user->address ?? '') }}</textarea>
                                    <label for="address">
                                        <i class="fas fa-location-dot text-primary me-1"></i> Address
                                    </label>
                                    @error('address')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            @if($user->isStudent())
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text"
                                               class="form-control @error('roll_no') is-invalid @enderror"
                                               id="roll_no"
                                               name="roll_no"
                                               value="{{ old('roll_no', $user->roll_no) }}"
                                               placeholder="Roll Number">
                                        <label for="roll_no">
                                            <i class="fas fa-id-card text-primary me-1"></i> Roll Number
                                        </label>
                                        @error('roll_no')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text"
                                               class="form-control @error('class') is-invalid @enderror"
                                               id="class"
                                               name="class"
                                               value="{{ old('class', $user->class) }}"
                                               placeholder="Class">
                                        <label for="class">
                                            <i class="fas fa-chalkboard-user text-primary me-1"></i> Class
                                        </label>
                                        @error('class')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="number"
                                               class="form-control @error('fromY') is-invalid @enderror"
                                               id="fromY"
                                               name="fromY"
                                               value="{{ old('fromY', $user->fromY) }}"
                                               placeholder="From Year"
                                               min="1900"
                                               max="{{ date('Y') + 10 }}">
                                        <label for="fromY">
                                            <i class="fas fa-calendar text-primary me-1"></i> From Year
                                        </label>
                                        @error('fromY')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="number"
                                               class="form-control @error('toY') is-invalid @enderror"
                                               id="toY"
                                               name="toY"
                                               value="{{ old('toY', $user->toY) }}"
                                               placeholder="To Year"
                                               min="1900"
                                               max="{{ date('Y') + 15 }}">
                                        <label for="toY">
                                            <i class="fas fa-calendar-check text-primary me-1"></i> To Year
                                        </label>
                                        @error('toY')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            @elseif($user->isSupervisor())
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text"
                                               class="form-control @error('rank') is-invalid @enderror"
                                               id="rank"
                                               name="rank"
                                               value="{{ old('rank', $user->rank) }}"
                                               placeholder="Rank">
                                        <label for="rank">
                                            <i class="fas fa-user-tie text-primary me-1"></i> Rank
                                        </label>
                                        @error('rank')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            @endif
                        </div>

                        <div class="d-grid d-md-flex justify-content-md-end gap-2 mt-4 pt-3 border-top">
                            <button type="reset" class="btn btn-outline-secondary rounded-pill px-4 py-2">
                                <i class="fas fa-undo me-2"></i> Reset
                            </button>
                            <button type="submit" class="btn btn-primary rounded-pill px-5 py-2 shadow-sm">
                                <i class="fas fa-save me-2"></i> Update Profile
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- ============================================ -->
            <!-- CHANGE PASSWORD -->
            <!-- ============================================ -->
            <div class="card border-0 shadow-sm rounded-4 glassmorphism">
                <div class="card-header bg-transparent border-0 p-4 pb-0">
                    <div class="d-flex align-items-center gap-3">
                        <div class="bg-warning bg-opacity-10 p-3 rounded-3">
                            <i class="fas fa-key text-warning" style="font-size: 24px;"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0">Change Password</h5>
                            <p class="text-muted small mb-0">Update your password to keep your account secure</p>
                        </div>
                    </div>
                </div>
                <div class="card-body p-4">
                    <form action="{{ route('profile.change-password') }}" method="POST">
                        @csrf

                        <div class="row g-3">
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="password" 
                                           class="form-control @error('current_password') is-invalid @enderror" 
                                           id="current_password" 
                                           name="current_password" 
                                           placeholder="Current Password"
                                           required>
                                    <label for="current_password">
                                        <i class="fas fa-lock text-primary me-1"></i> Current Password <span class="text-danger">*</span>
                                    </label>
                                    @error('current_password')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="password" 
                                           class="form-control @error('password') is-invalid @enderror" 
                                           id="password" 
                                           name="password" 
                                           placeholder="New Password"
                                           required>
                                    <label for="password">
                                        <i class="fas fa-key text-primary me-1"></i> New Password <span class="text-danger">*</span>
                                    </label>
                                    @error('password')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="password" 
                                           class="form-control" 
                                           id="password_confirmation" 
                                           name="password_confirmation" 
                                           placeholder="Confirm Password"
                                           required>
                                    <label for="password_confirmation">
                                        <i class="fas fa-check-circle text-primary me-1"></i> Confirm Password <span class="text-danger">*</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="alert alert-info border-0 rounded-3 d-flex align-items-center gap-2">
                                    <i class="fas fa-info-circle"></i>
                                    <span>Password must be at least 8 characters long and include a mix of letters, numbers, and symbols.</span>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid d-md-flex justify-content-md-end gap-2 mt-4 pt-3 border-top">
                            <button type="reset" class="btn btn-outline-secondary rounded-pill px-4 py-2">
                                <i class="fas fa-undo me-2"></i> Reset
                            </button>
                            <button type="submit" class="btn btn-warning rounded-pill px-5 py-2 shadow-sm">
                                <i class="fas fa-key me-2"></i> Change Password
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- AVATAR MODAL -->
<!-- ============================================ -->
<div class="modal fade" id="avatarModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-4 border-0 shadow-lg">
            <div class="modal-header border-0">
                <h5 class="modal-title fw-bold">
                    <i class="fas fa-user-circle text-primary me-2"></i>Profile Picture
                </h5>
                <button type="button" class="btn-close" onclick="closeAvatarModal()" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-4">
                @php
                    $avatarUrl = ($user->avatar && $user->avatar != 'no-image-available.png') 
                        ? asset('storage/avatars/' . rawurlencode($user->avatar)) 
                        : null;
                @endphp
                @if($avatarUrl)
                    <img src="{{ $avatarUrl }}" 
                         alt="{{ $user->firstname }}" 
                         class="img-fluid rounded-3 shadow-sm"
                         style="max-height: 70vh; object-fit: contain;"
                         loading="lazy">
                @else
                    <div class="py-5">
                        <div class="rounded-circle bg-gradient-primary d-flex align-items-center justify-content-center mx-auto shadow-lg"
                             style="width: 200px; height: 200px; font-size: 80px; color: white;">
                            {{ strtoupper(substr($user->firstname, 0, 1)) }}
                        </div>
                        <p class="text-muted mt-3">No profile picture uploaded</p>
                        <button class="btn btn-primary rounded-pill px-4" onclick="document.getElementById('avatarInput').click(); closeAvatarModal();">
                            <i class="fas fa-upload me-2"></i> Upload Picture
                        </button>
                    </div>
                @endif
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-secondary rounded-pill px-4" onclick="closeAvatarModal()">
                    <i class="fas fa-times me-2"></i> Close
                </button>
                @if($avatarUrl)
                    <form action="{{ route('profile.remove-avatar') }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger rounded-pill px-4" onclick="return confirm('Are you sure you want to remove your profile picture?')">
                            <i class="fas fa-trash me-2"></i> Remove
                        </button>
                    </form>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- CUSTOM STYLES -->
<!-- ============================================ -->
<style>
    /* ============================================ */
    /* GLASSMORPHISM EFFECT */
    /* ============================================ */
    .glassmorphism {
        background: rgba(255, 255, 255, 0.7);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
    }
    
    /* ============================================ */
    /* GRADIENT BACKGROUNDS */
    /* ============================================ */
    .bg-gradient-primary {
        background: linear-gradient(135deg, #0d6efd, #0a58ca) !important;
    }
    
    .bg-gradient-success {
        background: linear-gradient(135deg, #198754, #157347) !important;
    }
    
    .bg-gradient-info {
        background: linear-gradient(135deg, #0dcaf0, #0aa5c4) !important;
    }
    
    .bg-gradient-warning {
        background: linear-gradient(135deg, #ffc107, #e0a800) !important;
    }
    
    /* ============================================ */
    /* STAT CARDS */
    /* ============================================ */
    .card.bg-gradient-primary,
    .card.bg-gradient-success,
    .card.bg-gradient-info,
    .card.bg-gradient-warning {
        transition: all 0.3s ease;
    }
    
    .card.bg-gradient-primary:hover,
    .card.bg-gradient-success:hover,
    .card.bg-gradient-info:hover,
    .card.bg-gradient-warning:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15) !important;
    }
    
    /* ============================================ */
    /* DETAIL ITEMS */
    /* ============================================ */
    .detail-item {
        transition: all 0.3s ease;
        border-radius: 8px;
        padding: 8px 12px;
        margin: 0 -12px;
    }
    
    .detail-item:hover {
        background: rgba(13, 110, 253, 0.04);
    }
    
    .detail-icon {
        width: 38px;
        height: 38px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        transition: all 0.3s ease;
    }
    
    .detail-item:hover .detail-icon {
        transform: scale(1.05);
    }
    
    /* ============================================ */
    /* FORM FLOATING */
    /* ============================================ */
    .form-floating > .form-control {
        border-radius: 0.75rem;
        border: 2px solid #e9ecef;
        transition: all 0.3s ease;
        height: calc(3.5rem + 2px);
        padding: 1rem 0.75rem;
    }
    
    .form-floating > .form-control:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1);
    }
    
    .form-floating > .form-control.is-invalid {
        border-color: #dc3545;
        box-shadow: 0 0 0 4px rgba(220, 53, 69, 0.1);
    }
    
    .form-floating > label {
        padding: 1rem 0.75rem;
        font-weight: 500;
    }
    
    .form-floating > textarea.form-control {
        height: auto;
        min-height: 100px;
        padding-top: 1.5rem;
    }
    
    /* ============================================ */
    /* COVER IMAGE */
    /* ============================================ */
    .cover-image {
        position: relative;
        overflow: hidden;
    }
    
    .cover-image::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.1) 100%);
    }
    
    /* ============================================ */
    /* BUTTONS */
    /* ============================================ */
    .btn {
        font-weight: 600;
        font-size: 14px;
        transition: all 0.3s ease;
    }
    
    .btn-primary {
        background: linear-gradient(135deg, #0d6efd, #0a58ca);
        border: none;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(13, 110, 253, 0.3);
    }
    
    .btn-warning {
        background: linear-gradient(135deg, #ffc107, #e0a800);
        border: none;
        color: #212529;
    }
    
    .btn-warning:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(255, 193, 7, 0.3);
        color: #212529;
    }
    
    .btn-outline-secondary:hover {
        transform: translateY(-2px);
    }
    
    /* ============================================ */
    /* MODAL */
    /* ============================================ */
    .modal-content {
        border: none;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
    }
    
    .modal-backdrop {
        display: none !important;
    }
    
    .modal.show {
        display: block !important;
        background: rgba(0, 0, 0, 0.5);
    }
    
    .modal.fade .modal-dialog {
        transform: scale(0.9);
        transition: transform 0.3s ease;
    }
    
    .modal.show .modal-dialog {
        transform: scale(1);
    }
    
    .alert {
        border-radius: 12px;
    }
    
    /* ============================================ */
    /* RESPONSIVE */
    /* ============================================ */
    @media (max-width: 768px) {
        .glassmorphism {
            background: rgba(255, 255, 255, 0.9);
        }
        
        .card.bg-gradient-primary:hover,
        .card.bg-gradient-success:hover,
        .card.bg-gradient-info:hover,
        .card.bg-gradient-warning:hover {
            transform: none;
        }
        
        .btn-primary:hover,
        .btn-warning:hover {
            transform: none;
        }
        
        .form-floating > .form-control {
            font-size: 14px;
            height: calc(3rem + 2px);
            padding: 0.75rem 0.75rem;
        }
        
        .form-floating > label {
            padding: 0.75rem 0.75rem;
            font-size: 13px;
        }
        
        .cover-image {
            height: 60px;
        }
        
        .detail-item {
            padding: 6px 10px;
            margin: 0 -10px;
        }
        
        .detail-icon {
            width: 32px;
            height: 32px;
        }
    }
    
    @media (max-width: 576px) {
        .card-body {
            padding: 16px !important;
        }
        
        .cover-image {
            height: 50px;
            margin: -16px -16px 0 -16px !important;
        }
        
        .position-relative[style*="margin-top: -50px;"] {
            margin-top: -40px !important;
        }
        
        img[style*="width: 120px;"],
        div[style*="width: 120px;"] {
            width: 90px !important;
            height: 90px !important;
            font-size: 36px !important;
        }
        
        .position-absolute[style*="width: 32px;"] {
            width: 26px !important;
            height: 26px !important;
        }
        
        .position-absolute[style*="width: 32px;"] i {
            font-size: 10px !important;
        }
    }
</style>

<!-- ============================================ -->
<!-- SCRIPTS -->
<!-- ============================================ -->
@push('scripts')
<script>
    // ============================================
    // AVATAR MODAL CONTROLLER
    // ============================================
    var avatarModal = null;

    function openAvatarModal() {
        var backdrops = document.querySelectorAll('.modal-backdrop');
        backdrops.forEach(function(el) {
            el.remove();
        });
        
        var modalElement = document.getElementById('avatarModal');
        if (modalElement) {
            modalElement.classList.remove('show');
            modalElement.style.display = 'none';
            
            if (avatarModal) {
                avatarModal.dispose();
                avatarModal = null;
            }
            
            avatarModal = new bootstrap.Modal(modalElement, {
                backdrop: true,
                keyboard: true
            });
            
            avatarModal.show();
            
            modalElement.addEventListener('hidden.bs.modal', function() {
                var backdrops = document.querySelectorAll('.modal-backdrop');
                backdrops.forEach(function(el) {
                    el.remove();
                });
                document.body.classList.remove('modal-open');
                document.body.style.overflow = '';
            });
        }
    }

    function closeAvatarModal() {
        if (avatarModal) {
            avatarModal.hide();
        }
        setTimeout(function() {
            var backdrops = document.querySelectorAll('.modal-backdrop');
            backdrops.forEach(function(el) {
                el.remove();
            });
            document.body.classList.remove('modal-open');
            document.body.style.overflow = '';
        }, 100);
    }

    // Clean up on page load
    document.addEventListener('DOMContentLoaded', function() {
        var backdrops = document.querySelectorAll('.modal-backdrop');
        backdrops.forEach(function(el) {
            el.remove();
        });
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';
    });
</script>
@endpush
@endsection
