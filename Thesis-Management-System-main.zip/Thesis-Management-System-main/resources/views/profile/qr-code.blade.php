{{-- resources/views/profile/qr-code.blade.php --}}

@extends('layouts.app')

@section('title', 'My Permanent QR Code')

@section('content')
<div class="container-fluid">
    <!-- ============================================ -->
    <!-- PAGE HEADER -->
    <!-- ============================================ -->
    <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">
                <i class="fas fa-qrcode text-primary me-2"></i>QR Code
            </h2>
            <p class="text-muted mb-0">Generate and manage your permanent login QR Code</p>
        </div>
        <div>
            <span class="badge bg-success rounded-pill px-3 py-2">
                <i class="fas fa-check-circle me-1"></i> Permanent
            </span>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- MAIN CONTENT -->
    <!-- ============================================ -->
    <div class="row justify-content-center">
        <div class="col-lg-8 col-xl-7">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-4 p-md-5">
                    
                    <!-- ============================================ -->
                    <!-- USER INFO -->
                    <!-- ============================================ -->
                    <div class="d-flex align-items-center gap-3 pb-3 mb-4 border-bottom">
                        <div class="user-avatar rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; font-size: 18px; font-weight: 600; flex-shrink: 0;">
                            {{ strtoupper(substr(Auth::user()->firstname, 0, 1)) }}
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0">{{ Auth::user()->firstname }} {{ Auth::user()->lastname }}</h6>
                            <small class="text-muted">{{ Auth::user()->email }}</small>
                        </div>
                    </div>

                    <!-- ============================================ -->
                    <!-- QR CODE DISPLAY -->
                    <!-- ============================================ -->
                    @if(isset($qrCode) && $qrCode)
                        <div class="text-center">
                            <!-- QR Code -->
                            <div class="qr-wrapper d-inline-block p-4 bg-white rounded-3 shadow-sm border" style="border-color: #e9ecef !important;">
                                <div class="qr-container">
                                    {!! $qrCode !!}
                                </div>
                            </div>

                            <!-- Status Badges -->
                            <div class="d-flex flex-wrap gap-2 justify-content-center mt-4">
                                <span class="badge bg-success rounded-pill px-3 py-2">
                                    <i class="fas fa-check-circle me-1"></i> Permanent
                                </span>
                                <span class="badge bg-info rounded-pill px-3 py-2">
                                    <i class="fas fa-lock me-1"></i> Encrypted
                                </span>
                                <span class="badge bg-secondary rounded-pill px-3 py-2">
                                    <i class="fas fa-sync-alt me-1"></i> Auto-updates
                                </span>
                            </div>

                            <!-- Buttons -->
                            <div class="d-flex flex-wrap gap-2 justify-content-center mt-4">
                                <a href="{{ route('qr.download') }}" class="btn btn-primary rounded-pill px-4">
                                    <i class="fas fa-download me-2"></i> Download
                                </a>
                                <a href="{{ route('profile.index') }}" class="btn btn-outline-secondary rounded-pill px-4">
                                    <i class="fas fa-arrow-left me-2"></i> Back
                                </a>
                            </div>
                        </div>
                    @else
                        <!-- ============================================ -->
                        <!-- GENERATE QR CODE FORM -->
                        <!-- ============================================ -->
                        <div class="text-center py-3">
                            <div class="qr-placeholder mb-4">
                                <div class="bg-light rounded-3 p-5 d-inline-block">
                                    <i class="fas fa-qrcode text-secondary" style="font-size: 64px; opacity: 0.4;"></i>
                                </div>
                            </div>

                            <h5 class="fw-bold mb-2">Generate QR Code</h5>
                            <p class="text-muted mb-4">Enter your password to generate your permanent login QR Code.</p>

                            @if($errors->any())
                                <div class="alert alert-danger border-0 rounded-3 mb-3">
                                    @foreach($errors->all() as $error)
                                        <i class="fas fa-exclamation-circle me-2"></i> {{ $error }}
                                    @endforeach
                                </div>
                            @endif

                            <form action="{{ route('qr.show') }}" method="POST" class="mx-auto" style="max-width: 420px;">
                                @csrf
                                <div class="input-group mb-3">
                                    <span class="input-group-text bg-white border-end-0">
                                        <i class="fas fa-lock text-primary"></i>
                                    </span>
                                    <input type="password" 
                                           class="form-control form-control-lg border-start-0 @error('password') is-invalid @enderror" 
                                           name="password" 
                                           placeholder="Enter your password" 
                                           required>
                                </div>
                                @error('password')
                                    <div class="text-danger small text-start mb-2">{{ $message }}</div>
                                @enderror
                                <button type="submit" class="btn btn-primary btn-lg w-100 rounded-pill">
                                    <i class="fas fa-qrcode me-2"></i> Generate QR Code
                                </button>
                            </form>

                            <div class="mt-4 text-start">
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Your QR Code will be permanently valid and auto-updated when you change your password.
                                </small>
                            </div>
                        </div>
                    @endif

                    <hr class="my-4">

                    <!-- ============================================ -->
                    <!-- HOW TO USE -->
                    <!-- ============================================ -->
                    <div>
                        <h6 class="fw-bold mb-3">
                            <i class="fas fa-info-circle text-primary me-2"></i>How to Use
                        </h6>
                        <div class="row g-2">
                            <div class="col-md-3 col-6">
                                <div class="step-item text-center p-2">
                                    <div class="step-circle bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-1" style="width: 30px; height: 30px; font-size: 13px; font-weight: 700;">1</div>
                                    <small class="text-muted">Generate</small>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="step-item text-center p-2">
                                    <div class="step-circle bg-success text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-1" style="width: 30px; height: 30px; font-size: 13px; font-weight: 700;">2</div>
                                    <small class="text-muted">Download</small>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="step-item text-center p-2">
                                    <div class="step-circle bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center mx-auto mb-1" style="width: 30px; height: 30px; font-size: 13px; font-weight: 700;">3</div>
                                    <small class="text-muted">Scan</small>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="step-item text-center p-2">
                                    <div class="step-circle bg-danger text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-1" style="width: 30px; height: 30px; font-size: 13px; font-weight: 700;">4</div>
                                    <small class="text-muted">Login</small>
                                </div>
                            </div>
                        </div>
                        <div class="mt-3 text-center">
                            <a href="{{ route('qr.scanner') }}" class="btn btn-sm btn-outline-primary rounded-pill">
                                <i class="fas fa-camera me-1"></i> Go to QR Scanner
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- CUSTOM STYLES -->
<!-- ============================================ -->
<style>
    /* ============================================ */
    /* QR WRAPPER */
    /* ============================================ */
    .qr-wrapper {
        transition: all 0.3s ease;
    }
    
    .qr-wrapper:hover {
        border-color: #0d6efd !important;
        box-shadow: 0 4px 20px rgba(13, 110, 253, 0.08);
    }
    
    .qr-container {
        background: white;
        padding: 10px;
        border-radius: 12px;
        display: inline-block;
    }
    
    .qr-container svg {
        max-width: 100%;
        height: auto;
    }
    
    /* ============================================ */
    /* USER AVATAR */
    /* ============================================ */
    .user-avatar {
        background: linear-gradient(135deg, #0d6efd, #0a58ca) !important;
        color: white !important;
    }
    
    /* ============================================ */
    /* STEP ITEMS */
    /* ============================================ */
    .step-item {
        transition: all 0.3s ease;
        border-radius: 8px;
    }
    
    .step-item:hover {
        background: rgba(13, 110, 253, 0.05);
    }
    
    .step-item:hover .step-circle {
        transform: scale(1.1);
    }
    
    .step-circle {
        transition: all 0.3s ease;
        font-weight: 700;
    }
    
    /* ============================================ */
    /* QR PLACEHOLDER */
    /* ============================================ */
    .qr-placeholder .bg-light {
        transition: all 0.3s ease;
    }
    
    .qr-placeholder .bg-light:hover {
        background: rgba(13, 110, 253, 0.05) !important;
    }
    
    /* ============================================ */
    /* FORM */
    /* ============================================ */
    .input-group .form-control {
        border-radius: 0 0.75rem 0.75rem 0;
        border: 2px solid #e9ecef;
        border-left: none;
        padding: 0.75rem 1rem;
        font-size: 1rem;
        transition: all 0.3s ease;
    }
    
    .input-group .form-control:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1);
    }
    
    .input-group .form-control.is-invalid {
        border-color: #dc3545;
        box-shadow: 0 0 0 4px rgba(220, 53, 69, 0.1);
    }
    
    .input-group .input-group-text {
        border-radius: 0.75rem 0 0 0.75rem;
        border: 2px solid #e9ecef;
        border-right: none;
        background: white;
    }
    
    /* ============================================ */
    /* BUTTONS */
    /* ============================================ */
    .btn-primary {
        background: linear-gradient(135deg, #0d6efd, #0a58ca);
        border: none;
        transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(13, 110, 253, 0.3);
    }
    
    .btn-outline-secondary:hover {
        transform: translateY(-2px);
    }
    
    .btn-lg {
        font-weight: 600;
    }
    
    /* ============================================ */
    /* CARD */
    /* ============================================ */
    .card {
        border-radius: 16px !important;
    }
    
    .card-body {
        padding: 2rem !important;
    }
    
    /* ============================================ */
    /* ALERT */
    /* ============================================ */
    .alert {
        border-radius: 12px;
        padding: 0.75rem 1rem;
    }
    
    /* ============================================ */
    /* RESPONSIVE */
    /* ============================================ */
    @media (max-width: 768px) {
        .card-body {
            padding: 1.25rem !important;
        }
        
        .qr-wrapper {
            padding: 1rem !important;
        }
        
        .qr-container {
            padding: 8px;
        }
        
        .qr-container svg {
            width: 200px !important;
            height: 200px !important;
        }
        
        .qr-placeholder .bg-light {
            padding: 2rem !important;
        }
        
        .qr-placeholder i {
            font-size: 40px !important;
        }
        
        .step-item small {
            font-size: 11px !important;
        }
        
        .step-circle {
            width: 26px !important;
            height: 26px !important;
            font-size: 11px !important;
        }
        
        .btn-lg {
            font-size: 0.95rem;
            padding: 0.6rem 1rem;
        }
        
        .user-avatar {
            width: 40px !important;
            height: 40px !important;
            font-size: 15px !important;
        }
    }
    
    @media (max-width: 576px) {
        .qr-container svg {
            width: 160px !important;
            height: 160px !important;
        }
        
        .qr-wrapper {
            padding: 0.75rem !important;
        }
        
        .card-body {
            padding: 1rem !important;
        }
        
        .row.g-2 {
            gap: 0.25rem !important;
        }
        
        .col-6 {
            padding: 0 0.25rem !important;
        }
    }
</style>
@endsection