<style>
    .legal-page {
        padding: 22px 0 48px;
    }

    .legal-shell {
        max-width: 880px;
        margin: 0 auto;
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        padding: 32px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
    }

    .legal-header {
        display: flex;
        align-items: center;
        gap: 18px;
        border-bottom: 1px solid #e5e7eb;
        padding-bottom: 20px;
        margin-bottom: 24px;
    }

    .legal-icon {
        width: 54px;
        height: 54px;
        border-radius: 8px;
        background: #eff6ff;
        color: #0d6efd;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        flex-shrink: 0;
    }

    .legal-header h1 {
        color: #1f2937;
        font-size: 2rem;
        font-weight: 800;
        margin: 0 0 4px;
    }

    .legal-header p,
    .legal-section p {
        color: #6b7280;
        margin: 0;
        line-height: 1.7;
    }

    .legal-section {
        margin-bottom: 24px;
    }

    .legal-section h2 {
        color: #1f2937;
        font-size: 1.05rem;
        font-weight: 700;
        margin: 0 0 8px;
    }

    @media (max-width: 576px) {
        .legal-shell {
            padding: 22px 18px;
        }

        .legal-header {
            align-items: flex-start;
        }

        .legal-header h1 {
            font-size: 1.55rem;
        }
    }
</style>
