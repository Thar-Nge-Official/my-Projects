@extends('layouts.app')

@section('title', 'Terms of Service - ' . (trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System'))

@section('content')
@php
    $systemName = trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System';
    $universityName = trim((string) ($appSettings->university_name ?? ''));
    $departmentName = trim((string) ($appSettings->department_name ?? ''));
    $email = trim((string) ($appSettings->email ?? ''));
    $phone = trim((string) ($appSettings->phone ?? ''));
    $address = trim((string) ($appSettings->address ?? ''));
@endphp

<div class="legal-page">
    <div class="legal-shell">
        <div class="legal-header">
            <div class="legal-icon"><i class="fas fa-file-contract"></i></div>
            <div>
                <h1>Terms of Service</h1>
                <p>{{ $systemName }}</p>
            </div>
        </div>

        <div class="legal-section">
            <h2>Account Use</h2>
            <p>Users must provide accurate account information and use the system only for academic thesis, proposal, chapter, review, certificate, and administrative work.</p>
        </div>

        <div class="legal-section">
            <h2>Role Responsibilities</h2>
            <p>Students are responsible for submitting correct proposal and thesis content. Supervisors are responsible for reviewing assigned work. Administrators are responsible for user approval, system settings, proposal decisions, and final approval workflows.</p>
        </div>

        <div class="legal-section">
            <h2>Content Integrity</h2>
            <p>Uploaded files, thesis chapters, proposal titles, comments, and certificates must not contain false, harmful, unauthorized, or plagiarized material. System records may be used for academic review and audit purposes.</p>
        </div>

        <div class="legal-section">
            <h2>Access Control</h2>
            <p>Access depends on the user's approved role. When the system is in maintenance mode, only administrators may access protected system areas until the system is set back to active.</p>
        </div>

        <div class="legal-section">
            <h2>Contact</h2>
            @if($universityName || $departmentName)
                <p>{{ collect([$universityName, $departmentName])->filter()->implode(' - ') }}</p>
            @endif
            @if($address)<p>{{ $address }}</p>@endif
            @if($email || $phone)<p>{{ collect([$email, $phone])->filter()->implode(' | ') }}</p>@endif
        </div>
    </div>
</div>

@include('legal.partials.styles')
@endsection
