@extends('layouts.app')

@section('title', 'Privacy Policy - ' . (trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System'))

@section('content')
@php
    $systemName = trim((string) ($appSettings->system_name ?? '')) ?: 'Thesis Management System';
    $universityName = trim((string) ($appSettings->university_name ?? ''));
    $departmentName = trim((string) ($appSettings->department_name ?? ''));
    $email = trim((string) ($appSettings->email ?? ''));
    $phone = trim((string) ($appSettings->phone ?? ''));
    $address = trim((string) ($appSettings->address ?? ''));
@endphp

<div class="legal-page">
    <div class="legal-shell">
        <div class="legal-header">
            <div class="legal-icon"><i class="fas fa-shield-alt"></i></div>
            <div>
                <h1>Privacy Policy</h1>
                <p>{{ $systemName }}</p>
            </div>
        </div>

        <div class="legal-section">
            <h2>Information Collected</h2>
            <p>The system stores account details, role information, registration status, thesis proposals, thesis chapters, review records, certificates, QR login data, and uploaded academic files needed to operate the thesis workflow.</p>
        </div>

        <div class="legal-section">
            <h2>How Information Is Used</h2>
            <p>Information is used for account approval, role-based access, proposal review, supervisor assignment, thesis progress tracking, certificate generation, academic reporting, and system administration.</p>
        </div>

        <div class="legal-section">
            <h2>Data Access</h2>
            <p>Students can access their own thesis records. Supervisors can access assigned proposal and thesis records. Administrators can access system records needed for approval, management, reporting, and audit.</p>
        </div>

        <div class="legal-section">
            <h2>Security</h2>
            <p>The system uses authentication, role checks, approval status checks, and maintenance-mode restrictions to protect access. Users should keep passwords and QR login codes private.</p>
        </div>

        <div class="legal-section">
            <h2>Contact</h2>
            @if($universityName || $departmentName)
                <p>{{ collect([$universityName, $departmentName])->filter()->implode(' - ') }}</p>
            @endif
            @if($address)<p>{{ $address }}</p>@endif
            @if($email || $phone)<p>{{ collect([$email, $phone])->filter()->implode(' | ') }}</p>@endif
        </div>
    </div>
</div>

@include('legal.partials.styles')
@endsection
