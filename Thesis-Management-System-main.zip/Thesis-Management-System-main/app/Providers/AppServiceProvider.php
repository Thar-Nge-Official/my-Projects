<?php

namespace App\Providers;

use App\Models\Setting;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\URL;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Force HTTPS only when the configured app URL uses HTTPS.
        if (str_starts_with((string) config('app.url'), 'https://')) {
            URL::forceScheme('https');
        }

        try {
            $appSettings = Setting::first() ?? new Setting([
                'system_name' => 'Thesis Management System',
                'university_name' => 'University of Yangon',
                'department_name' => 'Department of Computer Studies',
            ]);
        } catch (\Throwable $e) {
            $appSettings = new Setting([
                'system_name' => 'Thesis Management System',
                'university_name' => 'University of Yangon',
                'department_name' => 'Department of Computer Studies',
            ]);
        }

        View::share('appSettings', $appSettings);
    }
}
