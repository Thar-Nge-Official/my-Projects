<?php
// app/Models/Certificate.php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Certificate extends Model
{
    use HasFactory;

    protected $fillable = [
        'thesis_id',
        'student_id',
        'certificate_number',
        'title',
        'description',
        'issued_at',
        'issued_by',
        'file_path',
    ];

    protected $casts = [
        'issued_at' => 'datetime',
    ];

    // ============================================
    // RELATIONSHIPS
    // ============================================

    public function thesis()
    {
        return $this->belongsTo(Thesis::class);
    }

    public function student()
    {
        return $this->belongsTo(User::class, 'student_id');
    }

    public function issuer()
    {
        return $this->belongsTo(User::class, 'issued_by');
    }

    // ============================================
    // ACCESSORS
    // ============================================

    public function getCertificateNumberAttribute($value)
    {
        return 'UY-CS-' . str_pad($value, 6, '0', STR_PAD_LEFT);
    }
}