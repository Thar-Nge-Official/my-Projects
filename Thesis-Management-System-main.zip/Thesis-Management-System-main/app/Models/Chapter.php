<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chapter extends Model
{
    use HasFactory;

    protected $fillable = [
        'thesis_id',
        'chapter_number',
        'chapter_title',
        'content',
        'file_path',
        'status',
        'submitted_at',
        'approved_at',
        'approved_by',
        'revision_feedback',
    ];

    protected $casts = [
        'submitted_at' => 'datetime',
        'approved_at' => 'datetime',
    ];

    // ============================================
    // RELATIONSHIPS
    // ============================================

    public function thesis()
    {
        return $this->belongsTo(Thesis::class);
    }

    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    // ============================================
    // ACCESSORS
    // ============================================

    public function getStatusLabelAttribute()
    {
        $labels = [
            'draft' => 'Draft',
            'submitted' => 'Submitted',
            'supervisor_approved' => 'Supervisor Approved',
            'admin_approved' => 'Admin Approved',
            'approved' => 'Admin Approved',
            'revision' => 'Revision Required'
        ];

        return $labels[$this->status] ?? ucfirst(str_replace('_', ' ', $this->status));
    }

    public function getStatusColorAttribute()
    {
        $colors = [
            'draft' => 'secondary',
            'submitted' => 'warning',
            'supervisor_approved' => 'info',
            'admin_approved' => 'success',
            'approved' => 'success',
            'revision' => 'danger'
        ];

        return $colors[$this->status] ?? 'secondary';
    }

    public function getWordCountAttribute()
    {
        $content = strip_tags($this->content ?? '');
        $content = preg_replace('/\s+/', ' ', $content);
        return str_word_count(trim($content));
    }

    // ============================================
    // FORMATTED CONTENT (JSON to HTML)
    // ============================================

    public function getFormattedContentAttribute()
    {
        $content = json_decode($this->content, true);
        
        if ($content && is_array($content)) {
            $html = '';
            foreach ($content as $section) {
                $number = $section['number'] ?? '';
                $title = $section['title'] ?? '';
                $paragraphs = $section['paragraphs'] ?? null;
                $image = $section['image'] ?? '';
                $caption = $section['caption'] ?? '';

                if (is_string($paragraphs)) {
                    $paragraphs = [$paragraphs];
                }

                $html .= '<div class="section-item mb-2">';
                $html .= '<div class="d-flex align-items-start gap-2">';
                $html .= '<span class="fw-bold text-primary" style="min-width: 50px;">' . e($number) . '</span>';
                $html .= '<div>';
                if ($title) {
                    $html .= '<h6 class="fw-semibold mb-1">' . e($title) . '</h6>';
                }

                if (is_array($paragraphs) && count($paragraphs) > 0) {
                    foreach ($paragraphs as $paragraph) {
                        if (!empty($paragraph)) {
                            $html .= '<p class="mb-0 text-muted">' . e($paragraph) . '</p>';
                        }
                    }
                } elseif (!empty($section['content'])) {
                    $html .= '<p class="mb-0 text-muted">' . e($section['content']) . '</p>';
                }

                if (!empty($image)) {
                    $imgUrl = '/storage/' . ltrim($image, '/');
                    $html .= '<div class="mt-2"><img src="' . e($imgUrl) . '" style="max-width:100%; height:auto; border-radius:6px;" /></div>';
                    if (!empty($caption)) {
                        $html .= '<div class="mt-1 text-muted small fst-italic">' . e($caption) . '</div>';
                    }
                }

                $html .= '</div>';
                $html .= '</div>';
                $html .= '</div>';
            }
            return $html;
        }
        
        return nl2br(e($this->content));
    }

    // ============================================
    // CAPABILITY CHECKS
    // ============================================

    public function canStudentEdit()
    {
        return $this->status === 'draft';
    }

    public function canStudentSubmit()
    {
        return $this->status === 'draft';
    }

    public function canReview()
    {
        return $this->status === 'submitted';
    }

    public function isApproved()
    {
        return $this->status === 'approved';
    }

    public function isRevision()
    {
        return $this->status === 'revision';
    }

    // ============================================
    // SCOPES
    // ============================================

    public function scopeDraft($query)
    {
        return $query->where('status', 'draft');
    }

    public function scopeSubmitted($query)
    {
        return $query->where('status', 'submitted');
    }

    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    public function scopeRevision($query)
    {
        return $query->where('status', 'revision');
    }
}