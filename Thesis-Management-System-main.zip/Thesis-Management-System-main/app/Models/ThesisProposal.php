<?php
// app/Models/ThesisProposal.php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ThesisProposal extends Model
{
    use HasFactory;

    protected $fillable = [
        'student_id',
        'title',
        'abstract',
        'keywords',
        'category_id',
        'thesis_type',
        'from_year',
        'to_year',
        'status',
        'is_selected',
        'rejection_reason',
        'submitted_at',
        'approved_at',
        'approved_by',
    ];

    protected $casts = [
        'submitted_at' => 'datetime',
        'approved_at' => 'datetime',
        'is_selected' => 'boolean',
    ];

    // ============================================
    // RELATIONSHIPS
    // ============================================

    public function student()
    {
        return $this->belongsTo(User::class, 'student_id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function thesis()
    {
        return $this->hasOne(Thesis::class, 'proposal_id');
    }

    // ============================================
    // STATUS ACCESSORS
    // ============================================

    public function getStatusLabelAttribute()
    {
        $labels = [
            'draft' => 'Draft',
            'pending' => 'Pending',
            'submitted' => 'Submitted',
            'approved' => 'Approved',
            'rejected' => 'Rejected'
        ];
        return $labels[$this->status] ?? ucfirst($this->status);
    }

    public function getStatusColorAttribute()
    {
        $colors = [
            'draft' => 'secondary',
            'pending' => 'warning',
            'submitted' => 'info',
            'approved' => 'success',
            'rejected' => 'danger'
        ];
        return $colors[$this->status] ?? 'secondary';
    }

    // ============================================
    // SCOPES
    // ============================================

    public function scopeSubmitted($query)
    {
        return $query->where('status', 'submitted');
    }

    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    public function scopeSelected($query)
    {
        return $query->where('is_selected', true);
    }

    public function scopeByStudent($query, $studentId)
    {
        return $query->where('student_id', $studentId);
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeRejected($query)
    {
        return $query->where('status', 'rejected');
    }

    public function scopeDraft($query)
    {
        return $query->where('status', 'draft');
    }
}