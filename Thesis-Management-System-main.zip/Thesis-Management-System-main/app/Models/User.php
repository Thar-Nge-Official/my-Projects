<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'firstname',
        'lastname',
        'roll_no',
        'class',
        'fromY',
        'toY',
        'email',
        'phone',
        'address',
        'password',
        'type',
        'rank',
        'avatar',
        'qr_code',              // QR code value
        'qr_code_generated_at', // QR code generation timestamp
        'registration_status',
        'approved_at',
        'approved_by',
        'rejection_reason',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'approved_at' => 'datetime',
        'qr_code_generated_at' => 'datetime',
    ];

    // Role Check Methods
    public function isAdmin(): bool
    {
        return $this->type === 'admin';
    }

    public function isSupervisor(): bool
    {
        return $this->type === 'supervisor';
    }

    public function isStudent(): bool
    {
        return $this->type === 'student';
    }

    // Relationship: theses supervised by this user
    public function supervisedTheses()
    {
        return $this->hasMany(\App\Models\Thesis::class, 'supervisor_id');
    }

    // Registration Status Methods
    public function isPending(): bool
    {
        return $this->registration_status === 'pending';
    }

    public function isApproved(): bool
    {
        return $this->registration_status === 'approved';
    }

    public function isRejected(): bool
    {
        return $this->registration_status === 'rejected';
    }
}
