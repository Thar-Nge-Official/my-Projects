<?php

namespace App\Models;

use App\Models\Certificate;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Thesis extends Model
{
    use HasFactory;

    protected $fillable = [
        'student_id',
        'supervisor_id',
        'category_id',
        'title',
        'abstract',
        'keywords',
        'status',
        'submission_date',
        'defense_date',
        'thesis_type',
        'from_year',
        'to_year',
        'proposal_submitted_at',
        'proposal_approved_at',
        'proposal_approved_by',
        'proposal_rejection_reason',
        'supervisor_assigned_at',
        'supervisor_assigned_by',
        'proposal_id',  // For proposal relationship
    ];

    protected $casts = [
        'submission_date' => 'date',
        'defense_date' => 'date',
        'proposal_submitted_at' => 'datetime',
        'proposal_approved_at' => 'datetime',
        'supervisor_assigned_at' => 'datetime',
    ];

    // ============================================
    // RELATIONSHIPS
    // ============================================

    public function student()
    {
        return $this->belongsTo(User::class, 'student_id');
    }

    public function supervisor()
    {
        return $this->belongsTo(User::class, 'supervisor_id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function chapters()
    {
        return $this->hasMany(Chapter::class);
    }

    public function feedbacks()
    {
        return $this->hasMany(Feedback::class);
    }

    public function certificate()
    {
        return $this->hasOne(Certificate::class);
    }

    public function proposalApprover()
    {
        return $this->belongsTo(User::class, 'proposal_approved_by');
    }

    public function supervisorAssigner()
    {
        return $this->belongsTo(User::class, 'supervisor_assigned_by');
    }

    // ============================================
    // RELATIONSHIP WITH ThesisProposal
    // ============================================
    
    public function proposal()
    {
        return $this->belongsTo(ThesisProposal::class, 'proposal_id');
    }

    // ============================================
    // STATUS ACCESSORS (ဒီတစ်ခါပဲရေးပါ)
    // ============================================

    public function getStatusLabelAttribute()
    {
        $labels = [
            'proposal_draft' => 'Proposal Draft',
            'proposal_submitted' => 'Proposal Submitted',
            'proposal_rejected' => 'Proposal Rejected',
            'proposal_approved' => 'Proposal Approved',
            'in_progress' => 'In Progress',
            'submitted' => 'Submitted (Pending Review)',
            'under_review' => 'Under Review',
            'supervisor_approved' => 'Supervisor Approved',
            'revision' => 'Revision Required',
            'approved' => 'Approved',
            'rejected' => 'Rejected'
        ];
        return $labels[$this->status] ?? ucfirst($this->status);
    }

    public function getStatusColorAttribute()
    {
        $colors = [
            'proposal_draft' => 'secondary',
            'proposal_submitted' => 'warning',
            'proposal_rejected' => 'danger',
            'proposal_approved' => 'success',
            'in_progress' => 'info',
            'submitted' => 'warning',
            'under_review' => 'info',
            'supervisor_approved' => 'primary',
            'revision' => 'danger',
            'approved' => 'success',
            'rejected' => 'dark'
        ];
        return $colors[$this->status] ?? 'secondary';
    }

    // ============================================
    // CAPABILITY CHECK METHODS
    // ============================================

    public function canStudentEdit()
    {
        return in_array($this->status, ['proposal_draft', 'proposal_rejected']);
    }

    public function canAddChapters()
    {
        return in_array($this->status, ['proposal_approved', 'in_progress', 'revision']);
    }

    public function canSubmit()
    {
        return in_array($this->status, ['proposal_approved', 'in_progress', 'revision']);
    }

    public function canReviewProposal()
    {
        return $this->status === 'proposal_submitted';
    }

    public function isSubmitted()
    {
        return $this->status === 'submitted';
    }

    public function isApproved()
    {
        return $this->status === 'approved';
    }

    public function isInProgress()
    {
        return in_array($this->status, ['in_progress', 'proposal_approved']);
    }

    public function isRevision()
    {
        return $this->status === 'revision';
    }

    public function isSupervisorApproved()
    {
        return $this->status === 'supervisor_approved';
    }

    public function hasSupervisorAssigned()
    {
        return $this->supervisor_id !== null;
    }

    public function canSubmitProposal()
    {
        return $this->hasSupervisorAssigned() && 
               in_array($this->status, ['proposal_draft', 'proposal_rejected']);
    }

    public function canSupervisorReview()
    {
        return $this->status === 'submitted';
    }

    public function canAdminReview()
    {
        return $this->status === 'supervisor_approved';
    }

    // ============================================
    // SCOPES
    // ============================================

    public function scopeProposalSubmitted($query)
    {
        return $query->where('status', 'proposal_submitted');
    }

    public function scopeProposalApproved($query)
    {
        return $query->where('status', 'proposal_approved');
    }

    public function scopeByStudent($query, $studentId)
    {
        return $query->where('student_id', $studentId);
    }

    public function scopeBySupervisor($query, $supervisorId)
    {
        return $query->where('supervisor_id', $supervisorId);
    }

    public function scopeWithoutSupervisor($query)
    {
        return $query->whereNull('supervisor_id');
    }

    public function scopeDraft($query)
    {
        return $query->where('status', 'proposal_draft');
    }

    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'proposal_submitted');
    }

    public function scopeSubmitted($query)
    {
        return $query->where('status', 'submitted');
    }

    public function scopeSupervisorApproved($query)
    {
        return $query->where('status', 'supervisor_approved');
    }

    public function scopeRevision($query)
    {
        return $query->where('status', 'revision');
    }

    public function scopeRejected($query)
    {
        return $query->where('status', 'rejected');
    }
}