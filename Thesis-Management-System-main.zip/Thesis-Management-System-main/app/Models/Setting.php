<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property string $system_name
 * @property string $university_name
 * @property string $department_name
 * @property string|null $email
 * @property string|null $phone
 * @property string|null $address
 * @property string|null $academic_year
 * @property string|null $logo
 * @property string|null $favicon
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting query()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereAcademicYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereAddress($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereDepartmentName($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereFavicon($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereLogo($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting wherePhone($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereSystemName($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereUniversityName($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Setting whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class Setting extends Model
{
    use HasFactory;

    protected $fillable = [
        'system_name',
        'university_name',
        'department_name',
        'email',
        'phone',
        'address',
        'academic_year',
        'student_registration',
        'system_status',
        'logo',
        'favicon',
    ];

    // Get default settings
    public static function getSettings()
    {
        return self::first() ?? new self();
    }
}