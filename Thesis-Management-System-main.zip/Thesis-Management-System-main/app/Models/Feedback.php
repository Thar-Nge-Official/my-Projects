<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Feedback extends Model
{
    use HasFactory;

    protected $table = 'feedbacks';

    protected $fillable = [
        'thesis_id',
        'user_id',
        'type',
        'feedback',
        'rating',
    ];

    public function thesis()
    {
        return $this->belongsTo(Thesis::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}