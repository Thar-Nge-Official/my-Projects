<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class SupervisorMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (Auth::check() && Auth::user()->isSupervisor()) {
            return $next($request);
        }

        return redirect()->route('dashboard')
            ->with('error', 'You do not have supervisor access.');
    }
}