<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\Setting;
use Illuminate\Support\Facades\Auth;

class CheckSystemStatus
{
    /**
     * Handle an incoming request.
     * If system_status == 'maintenance' and user is not admin, show maintenance page.
     */
    public function handle(Request $request, Closure $next)
    {
        try {
            $settings = Setting::first();
            $status = strtolower((string) ($settings->system_status ?? 'active'));

            if ($status !== 'maintenance') {
                return $next($request);
            }

            $user = Auth::user();

            if ($user && method_exists($user, 'isAdmin') && $user->isAdmin()) {
                return $next($request);
            }

            if ($request->expectsJson() || $request->is('api/*')) {
                return response()->json([
                    'message' => 'System is under maintenance.',
                ], 503);
            }

            return response()->view('errors.maintenance', ['settings' => $settings], 503);
        } catch (\Exception $e) {
            return $next($request);
        }
    }
}
