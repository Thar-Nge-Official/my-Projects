<?php

namespace App\Http\Middleware;

use App\Models\ThesisProposal;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckThesisApproval
{
    /**
     * Handle an incoming request.
     * Check whether the student has an approved proposal.
     */
    public function handle(Request $request, Closure $next)
    {
        // Check if student has an approved proposal
        $proposal = ThesisProposal::where('student_id', Auth::id())
            ->where('status', 'approved')
            ->first();

        if (!$proposal) {
            return redirect()->route('student.proposal.index')
                ->with('error', 'You must have an approved thesis proposal to access this section.');
        }

        return $next($request);
    }
}
