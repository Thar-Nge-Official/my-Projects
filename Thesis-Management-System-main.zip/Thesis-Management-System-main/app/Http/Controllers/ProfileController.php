<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class ProfileController extends Controller
{
    /**
     * Show profile page
     */
    public function index()
    {
        $user = Auth::user();
        return view('profile.index', compact('user'));
    }

    /**
     * Update profile
     */
    public function update(Request $request)
    {
        $user = Auth::user();

        $isAvatarOnlyUpdate = $request->hasFile('avatar')
            && !$request->hasAny(['firstname', 'lastname', 'email']);

        $rules = $isAvatarOnlyUpdate
            ? [
                'avatar' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            ]
            : [
                'firstname' => 'required|string|max:255',
                'lastname' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email,' . $user->id,
                'phone' => 'nullable|string|max:20',
                'address' => 'nullable|string|max:500',
                'roll_no' => 'nullable|string|max:255',
                'class' => 'nullable|string|max:255',
                'fromY' => 'nullable|integer|min:1900|max:' . (date('Y') + 10),
                'toY' => 'nullable|integer|min:1900|max:' . (date('Y') + 15),
                'rank' => 'nullable|string|max:255',
                'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        try {
            $data = $isAvatarOnlyUpdate
                ? []
                : $request->only(['firstname', 'lastname', 'email', 'phone', 'address', 'roll_no', 'class', 'fromY', 'toY', 'rank']);

            // Handle avatar upload
            if ($request->hasFile('avatar')) {
                // Delete old avatar if exists
                if ($user->avatar && $user->avatar != 'no-image-available.png') {
                    Storage::disk('public')->delete('avatars/' . $user->avatar);
                }
                
                $avatar = $request->file('avatar');
                $filename = time() . '_' . $avatar->getClientOriginalName();
                $avatar->storeAs('avatars', $filename, 'public');
                $data['avatar'] = $filename;
            }

            if (!empty($data)) {
                $user->update($data);
            }

            return redirect()->route('profile.index')
                ->with('success', 'Profile updated successfully!');

        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to update profile: ' . $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Change password and auto-regenerate QR Code
     */
    public function changePassword(Request $request)
    {
        $user = Auth::user();

        $validator = Validator::make($request->all(), [
            'current_password' => 'required',
            'password' => 'required|min:8|confirmed',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        // Check current password
        if (!Hash::check($request->current_password, $user->password)) {
            return redirect()->back()
                ->withErrors(['current_password' => 'Current password is incorrect.'])
                ->withInput();
        }

        try {
            // Update password
            $newPassword = $request->password;
            $user->update([
                'password' => Hash::make($newPassword)
            ]);

            // ============================================
            // AUTO-REGENERATE QR CODE
            // QR Code will be automatically regenerated
            // ============================================
            QRCodeController::regenerateQRCodeOnPasswordChange($user, $newPassword);

            return redirect()->route('profile.index')
                ->with('success', 'Password changed successfully! QR Code has been auto-regenerated.');

        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to change password: ' . $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Remove avatar
     */
    public function removeAvatar()
    {
        try {
            $user = Auth::user();
            
            if ($user->avatar && $user->avatar != 'no-image-available.png') {
                Storage::disk('public')->delete('avatars/' . $user->avatar);
                $user->avatar = 'no-image-available.png';
                $user->save();
            }

            return redirect()->route('profile.index')
                ->with('success', 'Avatar removed successfully!');

        } catch (\Exception $e) {
            return redirect()->route('profile.index')
                ->with('error', 'Failed to remove avatar: ' . $e->getMessage());
        }
    }
}
