<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class QRCodeController extends Controller
{
    /**
     * Show QR Code Scanner Page (Webcam Scanner)
     */
    public function showScanner()
    {
        return view('auth.qr-scanner');
    }

    /**
     * Show QR Code Page (Profile)
     */
    public function showQRCode(Request $request)
    {
        $user = Auth::user();

        // If password is provided, verify and generate QR Code
        if ($request->isMethod('post')) {
            $request->validate([
                'password' => 'required|min:8',
            ]);

            if (!Hash::check($request->password, $user->password)) {
                return back()->with('error', 'Invalid password. Please try again.');
            }

            // Generate QR Code
            $this->generateQRCodeForUser($user, $request->password);
            
            return redirect()->route('qr.show')->with('success', 'QR Code generated successfully!');
        }

        // Show QR Code if exists
        if ($user->qr_code) {
            $qrCode = $user->qr_code;
            return view('profile.qr-code', compact('qrCode', 'user'));
        }

        // No QR Code yet - show password form
        return view('profile.qr-code', compact('user'));
    }

    /**
     * Generate QR Code for User (with Email & Password)
     */
    private function generateQRCodeForUser($user, $password)
    {
        // Encrypt email and password (No timestamp - Permanent)
        $encryptedData = encrypt(json_encode([
            'email' => $user->email,
            'password' => $password,
        ]));

        // Generate QR Code SVG
        $qrCode = QrCode::size(300)
                        ->backgroundColor(255, 255, 255)
                        ->color(13, 110, 253)
                        ->generate(route('qr.login.scan', ['data' => $encryptedData]));

        // Save to database
        $user->qr_code = $qrCode;
        $user->qr_code_generated_at = now();
        $user->save();
    }

    /**
     * Auto-regenerate QR Code when password changes
     * This method is called from ProfileController when password is updated
     */
    public static function regenerateQRCodeOnPasswordChange($user, $newPassword)
    {
        // Encrypt email and new password
        $encryptedData = encrypt(json_encode([
            'email' => $user->email,
            'password' => $newPassword,
        ]));

        // Generate QR Code SVG
        $qrCode = QrCode::size(300)
                        ->backgroundColor(255, 255, 255)
                        ->color(13, 110, 253)
                        ->generate(route('qr.login.scan', ['data' => $encryptedData]));

        // Save to database
        $user->qr_code = $qrCode;
        $user->qr_code_generated_at = now();
        $user->save();
    }

    /**
     * Download QR Code
     */
    public function downloadQR()
    {
        $user = Auth::user();

        if (!$user->qr_code) {
            return redirect()->route('qr.show')->with('error', 'Please generate QR Code first.');
        }

        // Get QR Code from database
        $qrCode = $user->qr_code;

        return response($qrCode)
                ->header('Content-Type', 'image/svg+xml')
                ->header('Content-Disposition', 'attachment; filename="qr-login-' . $user->email . '.svg"');
    }

    /**
     * Scan QR Code and Login (Decrypt Email & Password)
     */
    public function scanLogin($data)
    {
        try {
            // Decrypt data
            $decrypted = decrypt($data);
            $userData = json_decode($decrypted, true);

            // Find user by email
            $user = User::where('email', $userData['email'])->first();

            if (!$user) {
                return redirect()->route('login')->with('error', 'User not found.');
            }

            // Check password
            if (!Hash::check($userData['password'], $user->password)) {
                return redirect()->route('login')->with('error', 'Invalid credentials.');
            }

            $settings = Setting::first();
            $systemStatus = strtolower((string) ($settings->system_status ?? 'active'));

            if ($systemStatus === 'maintenance' && !$user->isAdmin()) {
                Auth::logout();

                return redirect()->route('login')
                    ->with('error', 'System is under maintenance. Only administrators can sign in until the system is active again.');
            }

            // Login user
            Auth::login($user);

            // Redirect based on role
            if ($user->isAdmin()) {
                return redirect()->route('admin.dashboard')->with('success', 'Welcome Admin! (QR Login)');
            } elseif ($user->isSupervisor()) {
                return redirect()->route('supervisor.dashboard')->with('success', 'Welcome Supervisor! (QR Login)');
            } else {
                return redirect()->route('student.dashboard')->with('success', 'Welcome Student! (QR Login)');
            }

        } catch (\Exception $e) {
            return redirect()->route('login')->with('error', 'Invalid QR Code. Please try again.');
        }
    }

    /**
     * Regenerate QR Code manually
     */
    public function regenerateQRCode(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'password' => 'required|min:8',
        ]);

        if (!Hash::check($request->password, $user->password)) {
            return back()->with('error', 'Invalid password. Please try again.');
        }

        $this->generateQRCodeForUser($user, $request->password);

        return redirect()->route('qr.show')->with('success', 'QR Code regenerated successfully!');
    }
}
