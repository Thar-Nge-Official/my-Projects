<?php
// app/Http/Controllers/RegistrationController.php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class RegistrationController extends Controller
{
    /**
     * Display a listing of pending and rejected registrations.
     */
    public function index(Request $request)
    {
        $query = User::query();

        // 🎯 Filter by status (pending or rejected)
        if ($request->filled('status')) {
            $query->where('registration_status', $request->status);
        } else {
            // Default: show only pending and rejected (not approved)
            $query->whereIn('registration_status', ['pending', 'rejected']);
        }

        // 🔍 Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('firstname', 'LIKE', "%{$search}%")
                  ->orWhere('lastname', 'LIKE', "%{$search}%")
                  ->orWhere('email', 'LIKE', "%{$search}%");
            });
        }

        // 👥 Order by latest
        $registrations = $query->latest()->paginate(10);

        return view('admin.registrations.index', compact('registrations'));
    }

    /**
     * Approve a registration (pending → approved)
     */
    public function approve(User $user)
    {
        if (!in_array($user->registration_status, ['pending', 'rejected'])) {
            return redirect()->route('admin.registrations')
                ->with('error', 'This user is already ' . $user->registration_status . '.');
        }

        $user->update([
            'registration_status' => 'approved',
            'email_verified_at' => now(),
        ]);

        try {
            $settings = Setting::first();
            Mail::send('emails.registration-approved', [
                'user' => $user,
                'settings' => $settings,
            ], function ($message) use ($user, $settings) {
                $message->to($user->email)
                    ->subject('Registration Approved - ' . ($settings->system_name ?? 'Thesis Management System'));
            });
        } catch (\Exception $e) {
            // Do not block registration approval when mail is not configured or SMTP fails.
        }

        return redirect()->route('admin.registrations')
            ->with('success', "User {$user->firstname} {$user->lastname} has been approved successfully!");
    }

    /**
     * Reject a registration (pending → rejected)
     */
    public function reject(Request $request, User $user)
    {
        if ($user->registration_status !== 'pending') {
            return redirect()->route('admin.registrations')
                ->with('error', 'This user is not pending.');
        }

        $reason = $request->rejection_reason ?? 'No reason provided.';

        $user->update([
            'registration_status' => 'rejected',
            'rejection_reason' => $reason,
        ]);

        try {
            $settings = Setting::first();
            Mail::send('emails.registration-rejected', [
                'user' => $user,
                'settings' => $settings,
                'reason' => $reason,
            ], function ($message) use ($user, $settings) {
                $message->to($user->email)
                    ->subject('Registration Rejected - ' . ($settings->system_name ?? 'Thesis Management System'));
            });
        } catch (\Exception $e) {
            // Do not block rejection action when mail is not configured or SMTP fails.
        }

        return redirect()->route('admin.registrations')
            ->with('success', "User {$user->firstname} {$user->lastname} has been rejected.");
    }

    /**
     * Delete a rejected registration
     */
    public function deleteRejected(User $user)
    {
        // Only allow if user is rejected
        if ($user->registration_status !== 'rejected') {
            return redirect()->route('admin.registrations')
                ->with('error', 'Only rejected users can be deleted.');
        }

        $user->delete();

        return redirect()->route('admin.registrations')
            ->with('success', 'Rejected user has been deleted successfully!');
    }
}