<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Carbon\Carbon;

class ForgotPasswordController extends Controller
{
    /**
     * Show forgot password form
     */
    public function showForgotForm()
    {
        return view('auth.forgot-password');
    }

    /**
     * Send password reset link
     */
    public function sendResetLink(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
        ]);

        $user = User::where('email', $request->email)->first();

        // Check if user is approved
        if ($user->registration_status !== 'approved') {
            return back()->with('error', 'Your account is not approved yet. Please contact admin.');
        }

        // Check if user is rejected
        if ($user->registration_status === 'rejected') {
            return back()->with('error', 'Your account has been rejected. Please contact admin.');
        }

        // Generate token
        $token = Str::random(64);

        // Delete old tokens
        DB::table('password_reset_tokens')->where('email', $request->email)->delete();

        // Insert new token
        DB::table('password_reset_tokens')->insert([
            'email' => $request->email,
            'token' => $token,
            'created_at' => Carbon::now()
        ]);

        // Get settings
        $settings = Setting::first();

        // Send email
        try {
            $this->sendResetEmail($request->email, $token, $settings);
            return back()->with('success', 'We have emailed your password reset link!');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to send reset email. Please try again later.');
        }
    }

    /**
     * Send reset email
     */
    private function sendResetEmail($email, $token, $settings)
    {
        $data = [
            'email' => $email,
            'token' => $token,
            'settings' => $settings,
        ];

        Mail::send('emails.password-reset', $data, function($message) use ($email, $settings) {
            $message->to($email)
                    ->subject('Password Reset Request - ' . ($settings->system_name ?? 'Thesis Management System'));
        });
    }

    /**
     * Show reset password form
     */
    public function showResetForm($token)
    {
        return view('auth.reset-password', compact('token'));
    }

    /**
     * Reset password
     */
    public function reset(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
            'password' => 'required|min:8|confirmed',
            'token' => 'required'
        ]);

        // Check token
        $tokenData = DB::table('password_reset_tokens')
                        ->where('email', $request->email)
                        ->where('token', $request->token)
                        ->first();

        if (!$tokenData) {
            return back()->with('error', 'Invalid or expired token.');
        }

        // Check if token is expired (60 minutes)
        $createdAt = Carbon::parse($tokenData->created_at);
        if ($createdAt->diffInMinutes(Carbon::now()) > 60) {
            return back()->with('error', 'Token has expired. Please request a new one.');
        }

        // Update password
        $user = User::where('email', $request->email)->first();
        $user->password = bcrypt($request->password);
        $user->save();

        // Delete token
        DB::table('password_reset_tokens')->where('email', $request->email)->delete();

        return redirect()->route('login')->with('success', 'Password reset successfully! Please login with your new password.');
    }
}