<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Thesis;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\QRCodeController;

class AdminController extends Controller
{
    // ============================================
    // USER MANAGEMENT
    // ============================================

    /**
     * List all users with search and filter
     */
    public function users(Request $request)
    {
        $query = User::query();
        $selectedSupervisor = null;

        if ($request->filled('supervisor_id')) {
            $selectedSupervisor = User::where('type', 'supervisor')->find($request->supervisor_id);

            if ($selectedSupervisor) {
                $query->where('type', 'student')
                    ->whereIn('id', Thesis::where('supervisor_id', $selectedSupervisor->id)
                        ->select('student_id')
                        ->distinct());
            }
        }

        // 🔍 Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('firstname', 'LIKE', "%{$search}%")
                  ->orWhere('lastname', 'LIKE', "%{$search}%")
                  ->orWhere('email', 'LIKE', "%{$search}%")
                  ->orWhere('roll_no', 'LIKE', "%{$search}%")
                  ->orWhere('class', 'LIKE', "%{$search}%");
            });
        }

        // 🎯 Filter by role
        if (!$selectedSupervisor && $request->filled('role')) {
            $role = $request->role;
            $query->where('type', $role);
        }

        // 👥 If filtering by supervisors, include supervised students count (distinct students)
        if ($request->filled('role') && $request->role === 'supervisor') {
            // Add a count of distinct students supervised by each supervisor
            $users = $query->withCount(['supervisedTheses as supervised_students_count' => function ($q) {
                $q->select(DB::raw('COUNT(DISTINCT student_id)'));
            }])->latest()->paginate(10);
        } else {
            // For other roles or no role filter, still include the count (will be 0 for non-supervisors)
            $users = $query->withCount(['supervisedTheses as supervised_students_count' => function ($q) {
                $q->select(DB::raw('COUNT(DISTINCT student_id)'));
            }])->latest()->paginate(10);
        }

        // For AJAX requests (live search)
        if ($request->ajax()) {
            return response()->json([
                'html' => view('admin.users.partials.table', compact('users', 'selectedSupervisor'))->render(),
                'info' => view('admin.users.partials.info', compact('users', 'selectedSupervisor'))->render(),
            ]);
        }

        return view('admin.users.index', compact('users', 'selectedSupervisor'));
    }

    /**
     * Show create user form
     */
    public function createUser()
    {
        return view('admin.users.create');
    }

    /**
     * Store a new user
     */
    public function storeUser(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'firstname' => 'required|string|max:255',
            'lastname' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8|confirmed',
            'type' => 'required|in:student,supervisor,admin',
            'roll_no' => 'nullable|string|max:50',
            'class' => 'nullable|string|max:50',
            'rank' => 'nullable|string|max:50',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        try {
            // Set rank based on role
            $rank = null;
            if ($request->type === 'admin') {
                $rank = $request->rank ?? 'Professor and Head';
            } elseif ($request->type === 'supervisor') {
                $rank = $request->rank;
            }

            $user = User::create([
                'firstname' => $request->firstname,
                'lastname' => $request->lastname,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'type' => $request->type,
                'roll_no' => $request->roll_no,
                'class' => $request->class,
                'rank' => $rank,
                'fromY' => date('Y'),
                'toY' => date('Y') + 1,
                'avatar' => 'no-image-available.png',
            ]);

            return redirect()->route('admin.users')
                ->with('success', 'User created successfully!');
                
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to create user: ' . $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Show edit user form
     */
    public function editUser(User $user)
    {
        return view('admin.users.edit', compact('user'));
    }

    /**
     * Update a user
     */
    public function updateUser(Request $request, User $user)
    {
        $validator = Validator::make($request->all(), [
            'firstname' => 'required|string|max:255',
            'lastname' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $user->id,
            'type' => 'required|in:student,supervisor,admin',
            'roll_no' => 'nullable|string|max:50',
            'class' => 'nullable|string|max:50',
            'rank' => 'nullable|string|max:50',
            'password' => 'nullable|min:8|confirmed',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        try {
            // Get data except password fields
            $data = $request->except(['password', 'password_confirmation']);
            
            // Set rank based on role
            if ($request->type === 'admin') {
                $data['rank'] = $request->rank ?? 'Professor and Head';
            } elseif ($request->type === 'supervisor') {
                $data['rank'] = $request->rank;
            } else {
                // Student - rank should be null
                $data['rank'] = null;
            }
            
            // Update password only if provided
            $passwordPlain = null;
            if ($request->filled('password')) {
                $passwordPlain = $request->password;
                $data['password'] = Hash::make($passwordPlain);
            }

            $user->update($data);

            // If password changed, auto-regenerate QR code using new plaintext password
            if ($passwordPlain) {
                QRCodeController::regenerateQRCodeOnPasswordChange($user, $passwordPlain);
            }

            return redirect()->route('admin.users')
                ->with('success', 'User updated successfully!');
                
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to update user: ' . $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Regenerate QR for a user (admin action). Admin must supply a new temporary password to embed into QR.
     */
    public function regenerateUserQRCode(Request $request, User $user)
    {
        $this->authorize('update', $user);

        $validator = Validator::make($request->all(), [
            'new_password' => 'required|min:8|confirmed',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $newPassword = $request->new_password;

        // Update user's password with hashed value
        $user->password = Hash::make($newPassword);
        $user->save();

        // Regenerate QR code using QRCodeController helper
        QRCodeController::regenerateQRCodeOnPasswordChange($user, $newPassword);

        return redirect()->route('admin.users')->with('success', 'QR Code regenerated and password updated for user ' . $user->email);
    }

    /**
     * Delete a user
     */
    public function deleteUser(User $user)
    {
        if ($user->id === Auth::id()) {
            return redirect()->route('admin.users')
                ->with('error', 'You cannot delete your own account.');
        }

        $user->delete();

        return redirect()->route('admin.users')
            ->with('success', 'User deleted successfully!');
    }

    // ============================================
    // THESIS MANAGEMENT (Admin View)
    // ============================================

    /**
     * List all theses (Admin view)
     */
    public function allTheses(Request $request)
    {
        $query = Thesis::with(['student', 'supervisor', 'category']);

        // 🔍 Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'LIKE', "%{$search}%")
                  ->orWhere('description', 'LIKE', "%{$search}%")
                  ->orWhereHas('student', function ($q2) use ($search) {
                      $q2->where('firstname', 'LIKE', "%{$search}%")
                         ->orWhere('lastname', 'LIKE', "%{$search}%");
                  });
            });
        }

        // 🎯 Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $theses = $query->latest()->paginate(10);

        return view('admin.theses.index', compact('theses'));
    }

    /**
     * View a specific thesis (Admin view)
     */
    public function viewThesis(Thesis $thesis)
    {
        $chapters = $thesis->chapters()->orderBy('chapter_number')->get();
        $feedbacks = $thesis->feedbacks()->with('user')->latest()->get();
        $submissions = $thesis->submissions()->with('user')->latest()->get();
        
        return view('admin.theses.show', compact('thesis', 'chapters', 'feedbacks', 'submissions'));
    }

    /**
     * Delete a thesis (Admin)
     */
    public function deleteThesis(Thesis $thesis)
    {
        $thesis->delete();

        return redirect()->route('admin.theses')
            ->with('success', 'Thesis deleted successfully!');
    }
}
