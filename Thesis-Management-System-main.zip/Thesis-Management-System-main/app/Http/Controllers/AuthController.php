<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    /**
     * Show Login Form
     */
    public function showLoginForm()
    {
        return view('auth.login');
    }

    /**
     * Handle Login
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|min:8',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        // Check if user exists
        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return redirect()->back()
                ->withErrors(['email' => 'No account found with this email.'])
                ->withInput();
        }

        // Check if user is approved
        if ($user->registration_status === 'pending') {
            return redirect()->back()
                ->withErrors(['email' => 'Your account is pending approval. Please wait for admin approval.'])
                ->withInput();
        }

        if ($user->registration_status === 'rejected') {
            return redirect()->back()
                ->withErrors(['email' => 'Your account has been rejected. Please contact admin for more information.'])
                ->withInput();
        }

        // Attempt Login with Remember Me
        $credentials = $request->only('email', 'password');
        $remember = $request->has('remember') ? true : false;
        
        if (Auth::attempt($credentials, $remember)) {
            $request->session()->regenerate();
            
            $user = Auth::user();

            if ($this->systemIsInMaintenance() && !$user->isAdmin()) {
                Auth::logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();

                return redirect()->route('login')
                    ->withErrors(['email' => 'System is under maintenance. Only administrators can sign in until the system is active again.']);
            }
            
            if ($user->isAdmin()) {
                return redirect()->route('admin.dashboard')->with('success', 'Welcome Admin!');
            } elseif ($user->isSupervisor()) {
                return redirect()->route('supervisor.dashboard')->with('success', 'Welcome Supervisor!');
            } else {
                return redirect()->route('student.dashboard')->with('success', 'Welcome Student!');
            }
        }

        return redirect()->back()
            ->withErrors(['password' => 'Invalid password.'])
            ->withInput();
    }

    /**
     * Show Register Form
     */
    public function showRegisterForm()
    {
        $studentRegistrationClosed = $this->studentRegistrationIsClosed();

        return view('auth.register', compact('studentRegistrationClosed'));
    }

    /**
     * Handle Register
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'firstname' => 'required|string|max:255',
            'lastname' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8|confirmed',
            'roll_no' => 'nullable|string|max:50',
            'class' => 'nullable|string|max:50',
            'rank' => 'nullable|string|max:50',
            'type' => 'required|in:student,supervisor,admin',
            'terms' => 'accepted',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        if ($request->type === 'student' && $this->studentRegistrationIsClosed()) {
            return redirect()->back()
                ->withErrors(['type' => 'Student registration is currently closed by the system administrator.'])
                ->withInput();
        }

        // Set rank based on role
        $rank = null;
        if ($request->type === 'admin') {
            $rank = $request->rank ?? 'Professor and Head';
        } elseif ($request->type === 'supervisor') {
            $rank = $request->rank;
        }

        // Create User with pending status
        $user = User::create([
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'type' => $request->type,
            'rank' => $rank,
            'roll_no' => $request->roll_no,
            'class' => $request->class,
            'fromY' => date('Y'),
            'toY' => date('Y') + 1,
            'avatar' => 'no-image-available.png',
            'registration_status' => 'pending',
        ]);

        // Don't login automatically - redirect to login page with message
        return redirect()->route('login')
            ->with('success', 'Registration successful! Your account is pending admin approval. You will be notified once approved.');
    }

    /**
     * Handle Logout
     */
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect()->route('home')->with('success', 'You have been logged out successfully.');
    }

    private function studentRegistrationIsClosed(): bool
    {
        $settings = Setting::first();

        return strtolower((string) ($settings->student_registration ?? 'open')) === 'closed';
    }

    private function systemIsInMaintenance(): bool
    {
        $settings = Setting::first();

        return strtolower((string) ($settings->system_status ?? 'active')) === 'maintenance';
    }
}
