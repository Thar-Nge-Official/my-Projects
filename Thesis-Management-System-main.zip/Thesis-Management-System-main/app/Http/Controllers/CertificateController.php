<?php
// app/Http/Controllers/CertificateController.php

namespace App\Http\Controllers;

use App\Models\Certificate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;

class CertificateController extends Controller
{
    public function show(Certificate $certificate)
    {
        $this->authorizeView($certificate);
        return view('certificates.show', compact('certificate'));
    }

    public function download(Certificate $certificate)
    {
        $this->authorizeView($certificate);
        
        // Load the certificate view for PDF
        $pdf = Pdf::loadView('certificates.pdf', compact('certificate'));
        
        // Set paper to A4 Landscape
        $pdf->setPaper('A4', 'landscape');
        
        // Set PDF options
        $pdf->setOptions([
            'defaultFont' => 'times',
            'isHtml5ParserEnabled' => true,
            'isRemoteEnabled' => true,
        ]);
        
        // Download the PDF directly (no print dialog)
        return $pdf->download('certificate-' . str_replace('/', '-', $certificate->certificate_number) . '.pdf');
    }

    public function print(Certificate $certificate)
    {
        $this->authorizeView($certificate);
        return view('certificates.print', compact('certificate'));
    }

    private function authorizeView($certificate)
    {
        $user = Auth::user();
        if ($user->isAdmin()) return true;
        if ($user->isStudent() && $certificate->student_id == $user->id) return true;
        if ($user->isSupervisor() && $certificate->thesis && $certificate->thesis->supervisor_id == $user->id) return true;
        abort(403, 'Unauthorized access.');
    }
}