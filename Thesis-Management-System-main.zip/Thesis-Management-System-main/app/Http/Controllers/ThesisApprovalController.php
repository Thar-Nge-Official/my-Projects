<?php

namespace App\Http\Controllers;

use App\Models\ThesisProposal;
use App\Models\Thesis;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ThesisApprovalController extends Controller
{
    /**
     * Display all proposals for admin.
     * အက်ဒမင်အတွက် စာတမ်းအဆိုပြုချက်အားလုံးကို ပြသခြင်း
     */
    public function index()
    {
        $proposals = ThesisProposal::with(['student', 'category'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        return view('admin.proposals.index', compact('proposals'));
    }

    /**
     * Display pending proposals.
     * အတည်ပြုဆဲ စာတမ်းအဆိုပြုချက်များကို ပြသခြင်း
     */
    public function pending()
    {
        $proposals = ThesisProposal::with(['student', 'category'])
            ->whereIn('status', ['submitted', 'pending'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        return view('admin.proposals.pending', compact('proposals'));
    }

    /**
     * Display approved proposals.
     * အတည်ပြုပြီးသား စာတမ်းအဆိုပြုချက်များကို ပြသခြင်း
     */
    public function approved()
    {
        $proposals = ThesisProposal::with(['student', 'category'])
            ->where('status', 'approved')
            ->orderBy('approved_at', 'desc')
            ->paginate(20);
        
        return view('admin.proposals.approved', compact('proposals'));
    }

    /**
     * Display rejected proposals.
     * ပယ်ချထားသော စာတမ်းအဆိုပြုချက်များကို ပြသခြင်း
     */
    public function rejected()
    {
        $proposals = ThesisProposal::with(['student', 'category'])
            ->where('status', 'rejected')
            ->orderBy('updated_at', 'desc')
            ->paginate(20);
        
        return view('admin.proposals.rejected', compact('proposals'));
    }

    /**
     * Show the specified proposal details.
     * စာတမ်းအဆိုပြုချက်အသေးစိတ်ကို ပြသခြင်း
     */
    public function show(ThesisProposal $proposal)
    {
       $supervisors = User::where('type', 'supervisor')->get();

       return view('admin.proposals.show', compact('proposal', 'supervisors'));
    }

    /**
     * Approve a thesis proposal. ⭐
     * စာတမ်းအဆိုပြုချက်ကို အတည်ပြုခြင်း
     */
    public function approve(Request $request, ThesisProposal $proposal)
    {
        $request->validate([
            'comments' => 'nullable|string',
            'supervisor_id' => 'required|exists:users,id',
        ]);

        if (!in_array($proposal->status, ['submitted', 'pending'])) {
            return redirect()->back()
                ->with('error', 'This proposal cannot be approved in its current status.');
        }

        // Use transaction to ensure consistency
        DB::transaction(function () use ($proposal, $request, &$thesis) {
            // Mark the selected proposal as approved and selected
            $proposal->status = 'approved';
            $proposal->is_selected = true;
            $proposal->approved_at = now();
            $proposal->approved_by = Auth::id();
            // Do NOT set supervisor_id or admin_comments on the proposal table unless those columns exist
            $proposal->save();

            // Create thesis record for student
            $thesis = Thesis::create([
                'student_id' => $proposal->student_id,
                'supervisor_id' => $request->supervisor_id,
                'title' => $proposal->title,
                'category_id' => $proposal->category_id,
                'abstract' => $proposal->abstract,
                'proposal_id' => $proposal->id,
                'status' => 'proposal_approved',
                                'keywords' => $proposal->keywords,
                                'thesis_type' => $proposal->thesis_type,
                                'from_year' => $proposal->from_year,
                                'to_year' => $proposal->to_year,
                                'proposal_approved_at' => now(),
                                'proposal_approved_by' => Auth::id(),
                            ]);

            // Auto-reject any other proposals from the same student
            ThesisProposal::where('student_id', $proposal->student_id)
                ->where('id', '!=', $proposal->id)
                ->whereIn('status', ['submitted', 'pending', 'changes_requested', 'draft', 'recommended'])
                ->update([
                    'status' => 'rejected',
                    'rejection_reason' => 'Auto-rejected because another proposal was approved.',
                    'is_selected' => false,
                ]);
        });

        return redirect()->route('admin.proposals.show', $proposal)
            ->with('success', 'Proposal approved successfully! Thesis has been created for the student.');
    }

    /**
     * Reject a thesis proposal. ⭐
     * စာတမ်းအဆိုပြုချက်ကို ပယ်ချခြင်း
     */
    public function reject(Request $request, ThesisProposal $proposal)
    {
        $request->validate([
            'rejection_reason' => 'required|string|min:10',
        ]);

        if (!in_array($proposal->status, ['submitted', 'pending'])) {
            return redirect()->back()
                ->with('error', 'This proposal cannot be rejected in its current status.');
        }

        $proposal->status = 'rejected';
        $proposal->rejection_reason = $request->rejection_reason;
        // Avoid setting rejected_date/rejected_by unless those columns exist in the table
        $proposal->save();

        return redirect()->route('admin.proposals.show', $proposal)
            ->with('success', 'Proposal rejected successfully.');
    }

    /**
     * Request changes for a thesis proposal. ⭐
     * စာတမ်းအဆိုပြုချက်ကို ပြင်ဆင်ခိုင်းခြင်း
     */
    public function requestChanges(Request $request, ThesisProposal $proposal)
    {
        $request->validate([
            'feedback' => 'required|string|min:10',
        ]);

        if (!in_array($proposal->status, ['submitted', 'pending'])) {
            return redirect()->back()
                ->with('error', 'This proposal cannot be changed in its current status.');
        }

        $proposal->status = 'changes_requested';
        $proposal->feedback = $request->feedback;
        // Do not set requested_changes_date unless the column exists
        $proposal->save();

        return redirect()->route('admin.proposals.show', $proposal)
            ->with('success', 'Changes requested successfully. Student has been notified.');
    }

    /**
     * Supervisor index - view proposals assigned to supervisor.
     * ကြီးကြပ်ရေးမှူးအတွက် သတ်မှတ်ထားသော စာတမ်းများကို ပြသခြင်း
     */
    public function supervisorIndex()
    {
        // Show all proposals assigned to this supervisor (any status)
        $proposals = ThesisProposal::with(['student', 'category'])
            ->where('supervisor_id', Auth::id())
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        return view('supervisor.proposals.index', compact('proposals'));
    }

    /**
     * Supervisor pending proposals
     */
    public function supervisorPending()
    {
        $proposals = ThesisProposal::with(['student', 'category'])
            ->where('supervisor_id', Auth::id())
            ->whereIn('status', ['submitted', 'pending'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('supervisor.proposals.index', compact('proposals'));
    }

    /**
     * Supervisor approved proposals
     */
    public function supervisorApproved()
    {
        $proposals = ThesisProposal::with(['student', 'category'])
            ->where('supervisor_id', Auth::id())
            ->where('status', 'approved')
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('supervisor.proposals.index', compact('proposals'));
    }

    /**
     * Supervisor rejected proposals
     */
    public function supervisorRejected()
    {
        $proposals = ThesisProposal::with(['student', 'category'])
            ->where('supervisor_id', Auth::id())
            ->where('status', 'rejected')
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('supervisor.proposals.index', compact('proposals'));
    }

    /**
     * Supervisor show - view specific proposal.
     * ကြီးကြပ်ရေးမှူးအတွက် စာတမ်းအသေးစိတ်ကို ပြသခြင်း
     */
    public function supervisorShow(ThesisProposal $proposal)
    {
        if ($proposal->supervisor_id !== Auth::id()) {
            abort(403, 'Unauthorized action.');
        }

        return view('supervisor.proposals.show', compact('proposal'));
    }

    /**
     * Supervisor recommend a proposal.
     * ကြီးကြပ်ရေးမှူးက စာတမ်းကို အကြံပြုခြင်း
     */
    public function recommend(Request $request, ThesisProposal $proposal)
    {
        if ($proposal->supervisor_id !== Auth::id()) {
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'recommendation' => 'required|string|min:10',
            'status' => 'required|in:recommended,not_recommended',
        ]);

        $proposal->supervisor_recommendation = $request->recommendation;
        $proposal->supervisor_status = $request->status;
        $proposal->supervisor_reviewed_date = now();
        $proposal->save();

        return redirect()->route('supervisor.proposals.show', $proposal)
            ->with('success', 'Recommendation submitted successfully!');
    }
}