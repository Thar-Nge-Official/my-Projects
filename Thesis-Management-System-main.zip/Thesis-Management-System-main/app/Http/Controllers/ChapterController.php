<?php

namespace App\Http\Controllers;

use App\Models\Chapter;
use App\Models\Thesis;
use App\Models\Feedback;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ChapterController extends Controller
{
    /**
     * Show the form for creating a new chapter.
     */
    public function create(Thesis $thesis)
    {
        $this->authorizeThesis($thesis);
        
        if ($thesis->status !== 'proposal_approved' && $thesis->status !== 'in_progress' && $thesis->status !== 'revision') {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'You can only add chapters after proposal is approved.');
        }

        $nextChapterNumber = $thesis->chapters()->max('chapter_number') + 1;
        
        return view('chapters.create', compact('thesis', 'nextChapterNumber'));
    }

    /**
     * Store a newly created chapter in storage.
     */
    public function store(Request $request, Thesis $thesis)
    {
        $this->authorizeThesis($thesis);

        if ($thesis->status !== 'proposal_approved' && $thesis->status !== 'in_progress' && $thesis->status !== 'revision') {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'You can only add chapters after proposal is approved.');
        }

        $validator = Validator::make($request->all(), [
            'chapter_number' => 'required|integer|min:1',
            'chapter_title' => 'required|string|max:255',
            'content' => 'nullable|string',
            'file' => 'nullable|file|mimes:zip|max:3072000',
            'section_images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:5120',
            'section_captions.*' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        if ($thesis->chapters()->where('chapter_number', $request->chapter_number)->exists()) {
            return redirect()->back()
                ->with('error', 'Chapter number already exists!')
                ->withInput();
        }

        $chapterData = [
            'thesis_id' => $thesis->id,
            'chapter_number' => $request->chapter_number,
            'chapter_title' => $request->chapter_title,
            // We'll set content after handling section images so we can store files under the chapter id
            'content' => null,
            'status' => 'draft',
        ];

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $fileName = time() . '_' . $file->getClientOriginalName();
            $filePath = $file->storeAs('chapters/' . $thesis->id, $fileName, 'public');
            $chapterData['file_path'] = $filePath;
        }

        try {
            // Create chapter first to get id for storing section images
            $chapter = Chapter::create($chapterData);

            // Process section images and image captions: map uploaded files (section_images[]) to sections in the JSON
            $sections = [];
            if (!empty($request->content)) {
                $sections = json_decode($request->content, true) ?? [];
            }

            $sectionCaptions = $request->input('section_captions', []);

            if ($request->hasFile('section_images')) {
                $images = $request->file('section_images');
                foreach ($images as $idx => $img) {
                    if (!$img) continue;
                    if (!isset($sections[$idx])) continue;

                    $imgName = time() . '_' . $img->getClientOriginalName();
                    $imgPath = $img->storeAs('chapters/' . $thesis->id . '/' . $chapter->id, $imgName, 'public');
                    $sections[$idx]['image'] = $imgPath;

                    if (isset($sectionCaptions[$idx]) && trim($sectionCaptions[$idx]) !== '') {
                        $sections[$idx]['caption'] = trim($sectionCaptions[$idx]);
                    }
                }
            }

            foreach ($sections as $idx => &$section) {
                if (isset($sectionCaptions[$idx]) && trim($sectionCaptions[$idx]) !== '') {
                    $section['caption'] = trim($sectionCaptions[$idx]);
                }
            }
            unset($section);

            // Save JSON content back to chapter
            if (!empty($sections)) {
                $chapter->content = json_encode($sections);
                $chapter->save();
            }

            return redirect()->route('theses.show', $thesis)
                ->with('success', 'Chapter "' . $chapter->chapter_title . '" created successfully!');
        } catch (\Exception $e) {
            // Cleanup files if created
            if (isset($chapter) && $chapter->file_path) {
                Storage::disk('public')->delete($chapter->file_path);
            }
            return redirect()->back()
                ->with('error', 'Failed to create chapter: ' . $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Display the specified chapter.
     */
    public function show(Chapter $chapter)
    {
        $this->authorizeChapter($chapter);

        $user = Auth::user();
        $canViewFeedbacks = $user->isAdmin()
            || ($user->isStudent() && $chapter->thesis->student_id == $user->id)
            || ($user->isSupervisor() && $chapter->thesis->supervisor_id == $user->id);

        $feedbacks = collect();
        if ($canViewFeedbacks) {
            $feedbacks = Feedback::where('thesis_id', $chapter->thesis_id)
                                ->orderBy('created_at', 'desc')
                                ->get();
        }

        return view('chapters.show', compact('chapter', 'feedbacks', 'canViewFeedbacks'));
    }

    /**
     * Download the completed chapter as a PDF.
     */
    public function downloadPdf(Chapter $chapter)
    {
        $this->authorizeChapter($chapter);

        if (!in_array($chapter->status, ['admin_approved', 'approved'], true) || $chapter->thesis->status !== 'approved') {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'Only completed chapters from completed theses can be downloaded as PDF.');
        }

        $pdf = Pdf::loadView('chapters.pdf', compact('chapter'));
        $pdf->setPaper('A4', 'portrait');
        $pdf->setOptions([
            'defaultFont' => 'times',
            'isHtml5ParserEnabled' => true,
            'isRemoteEnabled' => true,
        ]);

        $fileName = 'chapter-' . $chapter->chapter_number . '-' . preg_replace('/[^A-Za-z0-9\-]/', '-', Str::slug($chapter->chapter_title)) . '.pdf';

        return $pdf->download($fileName);
    }

    /**
     * Show the form for editing the specified chapter.
     */
    public function edit(Chapter $chapter)
    {
        $this->authorizeChapter($chapter);

        // Student can only edit if chapter is draft or revision
        if ($chapter->status !== 'draft' && $chapter->status !== 'revision') {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'This chapter cannot be edited. Only draft or revision chapters can be edited.');
        }

        return view('chapters.edit', compact('chapter'));
    }

    /**
     * Update the specified chapter in storage.
     */
    public function update(Request $request, Chapter $chapter)
    {
        $this->authorizeChapter($chapter);

        if ($chapter->status !== 'draft' && $chapter->status !== 'revision') {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'This chapter cannot be edited. Only draft or revision chapters can be edited.');
        }

        $validator = Validator::make($request->all(), [
            'chapter_title' => 'required|string|max:255',
            'content' => 'nullable|string',
            'file' => 'nullable|file|mimes:zip|max:3072000',
            'section_images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:5120',
            'section_captions.*' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $chapterData = [
            'chapter_title' => $request->chapter_title,
            // We'll process section images and update content accordingly below
            'content' => null,
        ];

        if ($request->hasFile('file')) {
            if ($chapter->file_path) {
                Storage::disk('public')->delete($chapter->file_path);
            }
            
            $file = $request->file('file');
            $fileName = time() . '_' . $file->getClientOriginalName();
            $filePath = $file->storeAs('chapters/' . $chapter->thesis_id . '/' . $chapter->id, $fileName, 'public');
            $chapterData['file_path'] = $filePath;
        }

        // Process section images and content
        $sections = [];
        if (!empty($request->content)) {
            $sections = json_decode($request->content, true) ?? [];
        }

        $sectionCaptions = $request->input('section_captions', []);

        // Preserve existing images if the user didn't upload new ones
        $previousSections = json_decode($chapter->content, true) ?? [];
        foreach ($sections as $idx => &$sec) {
            if (empty($sec['image']) && isset($previousSections[$idx]['image']) && !empty($previousSections[$idx]['image'])) {
                $sec['image'] = $previousSections[$idx]['image'];
            }
            if (isset($sectionCaptions[$idx]) && trim($sectionCaptions[$idx]) !== '') {
                $sec['caption'] = trim($sectionCaptions[$idx]);
            } elseif (isset($previousSections[$idx]['caption'])) {
                $sec['caption'] = $previousSections[$idx]['caption'];
            }
        }
        unset($sec);

        if ($request->hasFile('section_images')) {
            $images = $request->file('section_images');
            foreach ($images as $idx => $img) {
                if (!$img) continue;
                // Ensure corresponding section exists
                if (!isset($sections[$idx])) continue;

                // Delete previous image if present
                if (!empty($sections[$idx]['image']) && isset($previousSections[$idx]['image']) && $previousSections[$idx]['image'] === $sections[$idx]['image']) {
                    Storage::disk('public')->delete($previousSections[$idx]['image']);
                }

                $imgName = time() . '_' . $img->getClientOriginalName();
                $imgPath = $img->storeAs('chapters/' . $chapter->thesis_id . '/' . $chapter->id, $imgName, 'public');
                $sections[$idx]['image'] = $imgPath;
                if (isset($sectionCaptions[$idx]) && trim($sectionCaptions[$idx]) !== '') {
                    $sections[$idx]['caption'] = trim($sectionCaptions[$idx]);
                }
            }
        }

        if (!empty($sections)) {
            $chapterData['content'] = json_encode($sections);
        } else {
            $chapterData['content'] = $request->content;
        }

        // If chapter was in revision, reset to draft after editing
        if ($chapter->status === 'revision') {
            $chapterData['status'] = 'draft';
            $chapterData['revision_feedback'] = null;
        }

        $chapter->update($chapterData);

        return redirect()->route('chapters.show', $chapter)
            ->with('success', 'Chapter updated successfully!');
    }

    /**
     * Remove the specified chapter from storage.
     */
    public function destroy(Chapter $chapter)
    {
        $this->authorizeChapter($chapter);

        if ($chapter->status !== 'draft') {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'Only draft chapters can be deleted.');
        }

        if ($chapter->file_path) {
            Storage::disk('public')->delete($chapter->file_path);
        }

        $chapter->delete();

        return redirect()->route('theses.show', $chapter->thesis)
            ->with('success', 'Chapter deleted successfully!');
    }

    /**
     * Student: Submit chapter for review.
     */
    public function submit(Request $request, Chapter $chapter)
    {
        $this->authorizeChapter($chapter);

        // Only draft chapters can be submitted
        if ($chapter->status !== 'draft') {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'This chapter cannot be submitted. Only draft chapters can be submitted.');
        }

        if (empty($chapter->content) && empty($chapter->file_path)) {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'Please add content or upload a file before submitting.');
        }

        $chapter->update([
            'status' => 'submitted',
            'submitted_at' => now(),
        ]);

        return redirect()->route('chapters.show', $chapter)
            ->with('success', 'Chapter submitted for review successfully!');
    }

    /**
     * Supervisor: Approve chapter (moves to admin review).
     */
    public function approveBySupervisor(Request $request, Chapter $chapter)
    {
        $this->authorizeSupervisorReview($chapter);

        if ($chapter->status !== 'submitted') {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'This chapter is not pending review.');
        }

        $request->validate([
            'feedback' => 'required|string|max:1000',
        ]);

        $chapter->update([
            'status' => 'supervisor_approved',
            'approved_at' => now(),
            'approved_by' => Auth::id(),
        ]);

        // Save feedback
        Feedback::create([
            'thesis_id' => $chapter->thesis_id,
            'user_id' => Auth::id(),
            'type' => 'supervisor',
            'feedback' => 'Supervisor approved Chapter ' . $chapter->chapter_number . ': ' . $request->feedback,
            'rating' => null,
        ]);

        return redirect()->route('chapters.show', $chapter)
            ->with('success', 'Chapter approved by supervisor! Waiting for admin review.');
    }

    /**
     * Supervisor: Reject chapter for revision.
     */
    public function rejectBySupervisor(Request $request, Chapter $chapter)
    {
        $this->authorizeSupervisorReview($chapter);

        if ($chapter->status !== 'submitted') {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'This chapter is not pending review.');
        }

        $request->validate([
            'feedback' => 'required|string|max:1000',
        ]);

        $chapter->update([
            'status' => 'revision',
            'revision_feedback' => $request->feedback,
            'approved_at' => null,
            'approved_by' => null,
        ]);

        // Save feedback
        Feedback::create([
            'thesis_id' => $chapter->thesis_id,
            'user_id' => Auth::id(),
            'type' => 'supervisor',
            'feedback' => 'Supervisor rejected Chapter ' . $chapter->chapter_number . ': ' . $request->feedback,
            'rating' => null,
        ]);

        return redirect()->route('chapters.show', $chapter)
            ->with('error', 'Chapter rejected. Student needs to revise and resubmit.');
    }

    /**
     * Admin: Approve chapter (final approval).
     */
    public function approveByAdmin(Request $request, Chapter $chapter)
    {
        $this->authorizeAdminReview($chapter);

        if (!in_array($chapter->status, ['supervisor_approved', 'approved'], true)) {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'This chapter is not pending admin review.');
        }

        $request->validate([
            'feedback' => 'required|string|max:1000',
        ]);

        $chapter->update([
            'status' => 'admin_approved',
            'approved_at' => now(),
            'approved_by' => Auth::id(),
        ]);

        // Save feedback
        Feedback::create([
            'thesis_id' => $chapter->thesis_id,
            'user_id' => Auth::id(),
            'type' => 'examiner',
            'feedback' => 'Admin approved Chapter ' . $chapter->chapter_number . ': ' . $request->feedback,
            'rating' => null,
        ]);

        return redirect()->route('chapters.show', $chapter)
            ->with('success', 'Chapter approved by admin!');
    }

    /**
     * Admin: Reject chapter for revision.
     */
    public function rejectByAdmin(Request $request, Chapter $chapter)
    {
        $this->authorizeAdminReview($chapter);

        if (!in_array($chapter->status, ['supervisor_approved', 'approved'], true)) {
            return redirect()->route('chapters.show', $chapter)
                ->with('error', 'This chapter is not pending admin review.');
        }

        $request->validate([
            'feedback' => 'required|string|max:1000',
        ]);

        $chapter->update([
            'status' => 'revision',
            'revision_feedback' => $request->feedback,
            'approved_at' => null,
            'approved_by' => null,
        ]);

        // Save feedback
        Feedback::create([
            'thesis_id' => $chapter->thesis_id,
            'user_id' => Auth::id(),
            'type' => 'examiner',
            'feedback' => 'Admin rejected Chapter ' . $chapter->chapter_number . ': ' . $request->feedback,
            'rating' => null,
        ]);

        return redirect()->route('chapters.show', $chapter)
            ->with('error', 'Chapter rejected by admin. Student needs to revise and resubmit.');
    }

    // ============================================
    // AUTHORIZATION METHODS
    // ============================================

    private function authorizeThesis($thesis)
    {
        $user = Auth::user();
        if ($user->isAdmin()) return true;
        if ($user->isStudent() && $thesis->student_id == $user->id) return true;
        abort(403, 'Unauthorized access.');
    }

    private function authorizeChapter($chapter)
    {
        $user = Auth::user();
        $thesis = $chapter->thesis;

        if ($user->isAdmin()) return true;
        if ($user->isStudent() && $thesis->student_id == $user->id) return true;
        if ($user->isSupervisor() && $thesis->supervisor_id == $user->id) return true;

        // Allow all authenticated users to view completed chapters from a completed thesis.
        if (in_array($chapter->status, ['admin_approved', 'approved'], true) && $thesis->status === 'approved') {
            return true;
        }

        abort(403, 'Unauthorized access.');
    }

    private function authorizeSupervisorReview($chapter)
    {
        $user = Auth::user();
        $thesis = $chapter->thesis;
        
        if ($user->isAdmin()) return true;
        if ($user->isSupervisor() && $thesis->supervisor_id == $user->id) return true;
        abort(403, 'Only supervisor or admin can review chapters.');
    }

    private function authorizeAdminReview($chapter)
    {
        $user = Auth::user();
        
        if ($user->isAdmin()) return true;
        abort(403, 'Only admin can perform this action.');
    }
}