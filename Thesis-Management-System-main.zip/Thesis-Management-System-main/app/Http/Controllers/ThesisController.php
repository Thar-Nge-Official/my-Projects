<?php
// app/Http/Controllers/ThesisController.php

namespace App\Http\Controllers;

use App\Models\Thesis;
use App\Models\Category;
use App\Models\User;
use App\Models\Feedback;
use App\Models\Chapter;
use App\Models\Certificate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ThesisController extends Controller
{
    // ============================================
    // STUDENT: Create/Edit/Delete Proposal (Draft)
    // ============================================

    /**
     * Display a listing of the theses.
     */
    public function index()
    {
        $user = Auth::user();
        
        if ($user->isStudent()) {
            $theses = Thesis::where('student_id', $user->id)
                            ->with(['supervisor', 'category', 'proposalApprover'])
                            ->latest()
                            ->paginate(10);
        } elseif ($user->isSupervisor()) {
            $theses = Thesis::where('supervisor_id', $user->id)
                            ->with(['student', 'category', 'proposalApprover'])
                            ->latest()
                            ->paginate(10);
        } else {
            $theses = Thesis::with(['student', 'supervisor', 'category', 'proposalApprover'])
                            ->latest()
                            ->paginate(10);
        }

        return view('theses.index', compact('theses'));
    }

    /**
     * Display completed theses for reference.
     */
    public function completed(Request $request)
    {
        $search = trim((string) $request->query('search', ''));

        $theses = Thesis::approved()
                        ->with(['student', 'supervisor', 'category'])
                        ->when($search !== '', function ($query) use ($search) {
                            $query->where(function ($query) use ($search) {
                                $query->where('title', 'like', "%{$search}%")
                                    ->orWhere('abstract', 'like', "%{$search}%")
                                    ->orWhere('keywords', 'like', "%{$search}%")
                                    ->orWhereHas('student', function ($studentQuery) use ($search) {
                                        $studentQuery->where('firstname', 'like', "%{$search}%")
                                            ->orWhere('lastname', 'like', "%{$search}%")
                                            ->orWhere('email', 'like', "%{$search}%")
                                            ->orWhere('roll_no', 'like', "%{$search}%")
                                            ->orWhere('class', 'like', "%{$search}%");
                                    })
                                    ->orWhereHas('supervisor', function ($supervisorQuery) use ($search) {
                                        $supervisorQuery->where('firstname', 'like', "%{$search}%")
                                            ->orWhere('lastname', 'like', "%{$search}%")
                                            ->orWhere('email', 'like', "%{$search}%")
                                            ->orWhere('rank', 'like', "%{$search}%");
                                    })
                                    ->orWhereHas('category', function ($categoryQuery) use ($search) {
                                        $categoryQuery->where('name', 'like', "%{$search}%");
                                    });
                            });
                        })
                        ->latest()
                        ->paginate(10)
                        ->withQueryString();

        return view('theses.completed', compact('theses', 'search'));
    }

    /**
     * Show the form for creating a new thesis.
     */
    public function create()
    {
        // Only students can create proposals.
        if (!Auth::user()->isStudent()) {
            return redirect()->route('dashboard')
                ->with('error', 'Only students can create proposals.');
        }

        // The previous theses.create view posts a single proposal to the
        // multi-proposal endpoint. Send students to the matching form instead.
        return redirect()->route('student.proposals.create');
    }

    /**
     * Store a newly created thesis in storage.
     */
    public function store(Request $request)
    {
        // Only students can create theses
        if (!Auth::user()->isStudent()) {
            return redirect()->route('dashboard')
                ->with('error', 'Only students can create theses.');
        }

        $validator = Validator::make($request->all(), [
            'title' => 'required|string|max:255',
            'abstract' => 'required|string',
            'keywords' => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'thesis_type' => 'required|string|max:100',
            'from_year' => 'required|integer|min:2000',
            'to_year' => 'required|integer|min:2000|gte:from_year',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $thesis = Thesis::create([
            'student_id' => Auth::id(),
            'supervisor_id' => null,
            'category_id' => $request->category_id,
            'title' => $request->title,
            'abstract' => $request->abstract,
            'keywords' => $request->keywords,
            'thesis_type' => $request->thesis_type,
            'from_year' => $request->from_year,
            'to_year' => $request->to_year,
            'status' => 'proposal_draft',
        ]);

        return redirect()->route('theses.show', $thesis)
            ->with('success', 'Thesis proposal created successfully! Waiting for supervisor assignment.');
    }

    /**
     * Display the specified thesis.
     */
    public function show(Thesis $thesis)
    {
        $this->authorizeView($thesis);
        
        $chapters = $thesis->chapters()->orderBy('chapter_number')->get();
        $feedbacks = $thesis->feedbacks()->with('user')->latest()->get();
        
        $supervisors = [];
        if (Auth::user()->isAdmin()) {
            $supervisors = User::where('type', 'supervisor')->get();
        }
        
        // Check if certificate exists for approved thesis
        $certificate = null;
        $canViewCertificate = false;

        if ($thesis->status == 'approved') {
            $certificate = Certificate::where('thesis_id', $thesis->id)->first();
        }

        if ($certificate) {
            $user = Auth::user();
            $canViewCertificate = $user->isAdmin()
                || ($user->isStudent() && $certificate->student_id == $user->id)
                || ($user->isSupervisor() && $thesis->supervisor_id == $user->id);
        }

        return view('theses.show', compact('thesis', 'chapters', 'feedbacks', 'supervisors', 'certificate', 'canViewCertificate'));
    }

    /**
     * Show the form for editing the specified thesis.
     */
    public function edit(Thesis $thesis)
    {
        $this->authorizeEdit($thesis);
        
        if (!$thesis->canStudentEdit()) {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'You cannot edit this thesis at this stage.');
        }

        $categories = Category::all();
        return view('theses.edit', compact('thesis', 'categories'));
    }

    /**
     * Update the specified thesis in storage.
     */
    public function update(Request $request, Thesis $thesis)
    {
        $this->authorizeEdit($thesis);
        
        if (!$thesis->canStudentEdit()) {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'You cannot edit this thesis at this stage.');
        }

        $validator = Validator::make($request->all(), [
            'title' => 'required|string|max:255',
            'abstract' => 'required|string',
            'keywords' => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'thesis_type' => 'required|string|max:100',
            'from_year' => 'required|integer|min:2000',
            'to_year' => 'required|integer|min:2000|gte:from_year',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $thesis->update($request->all());

        return redirect()->route('theses.show', $thesis)
            ->with('success', 'Thesis updated successfully!');
    }

    /**
     * Remove the specified thesis from storage.
     * ADMIN ONLY - Student cannot delete
     */
    public function destroy(Thesis $thesis)
    {
        // Only admin can delete theses
        if (!Auth::user()->isAdmin()) {
            return redirect()->route('theses.index')
                ->with('error', 'Only admin can delete theses.');
        }

        $thesis->delete();

        return redirect()->route('theses.index')
            ->with('success', 'Thesis deleted successfully!');
    }

    // ============================================
    // STUDENT: Submit Proposal for Approval
    // ============================================

    /**
     * Submit thesis proposal for admin approval.
     */
    public function submitProposal(Request $request, Thesis $thesis)
    {
        $this->authorizeEdit($thesis);
        
        // Only draft or rejected proposals can be submitted
        if ($thesis->status !== 'proposal_draft' && $thesis->status !== 'proposal_rejected') {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'This proposal cannot be submitted.');
        }

        // Check if supervisor is assigned
        if (!$thesis->hasSupervisorAssigned()) {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'A supervisor must be assigned before submitting the proposal.');
        }

        $thesis->update([
            'status' => 'proposal_submitted',
            'proposal_submitted_at' => now(),
        ]);

        return redirect()->route('theses.show', $thesis)
            ->with('success', 'Proposal submitted for approval successfully!');
    }

    // ============================================
    // ADMIN: Approve/Reject Proposal
    // ============================================

    /**
     * Admin approves thesis proposal.
     */
    public function approveProposal(Request $request, Thesis $thesis)
    {
        // Only admin can approve proposals
        if (!Auth::user()->isAdmin()) {
            return redirect()->route('theses.index')
                ->with('error', 'Only admin can approve proposals.');
        }

        // Check if proposal is pending approval
        if ($thesis->status !== 'proposal_submitted') {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'This proposal is not pending approval.');
        }

        $thesis->update([
            'status' => 'proposal_approved',
            'proposal_approved_at' => now(),
            'proposal_approved_by' => Auth::id(),
        ]);

        return redirect()->route('theses.show', $thesis)
            ->with('success', 'Proposal approved successfully! Student can now start working on the thesis.');
    }

    /**
     * Admin rejects thesis proposal.
     */
    public function rejectProposal(Request $request, Thesis $thesis)
    {
        // Only admin can reject proposals
        if (!Auth::user()->isAdmin()) {
            return redirect()->route('theses.index')
                ->with('error', 'Only admin can reject proposals.');
        }

        // Check if proposal is pending approval
        if ($thesis->status !== 'proposal_submitted') {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'This proposal is not pending approval.');
        }

        $request->validate([
            'rejection_reason' => 'required|string|max:500',
        ]);

        $thesis->update([
            'status' => 'proposal_rejected',
            'proposal_rejection_reason' => $request->rejection_reason,
        ]);

        return redirect()->route('theses.show', $thesis)
            ->with('error', 'Proposal rejected. Reason: ' . $request->rejection_reason);
    }

    // ============================================
    // ADMIN: Assign Supervisor
    // ============================================

    /**
     * Admin assigns supervisor to thesis.
     */
    public function assignSupervisor(Request $request, Thesis $thesis)
    {
        // Only admin can assign supervisors
        if (!Auth::user()->isAdmin()) {
            return redirect()->route('theses.index')
                ->with('error', 'Only admin can assign supervisors.');
        }

        $request->validate([
            'supervisor_id' => 'required|exists:users,id',
        ]);

        $thesis->update([
            'supervisor_id' => $request->supervisor_id,
            'supervisor_assigned_at' => now(),
            'supervisor_assigned_by' => Auth::id(),
        ]);

        return redirect()->route('theses.show', $thesis)
            ->with('success', 'Supervisor assigned successfully!');
    }

    // ============================================
    // STUDENT: Submit Full Thesis for Review
    // ============================================

    /**
     * Submit full thesis for review after proposal is approved.
     */
    public function submitThesis(Request $request, Thesis $thesis)
    {
        $this->authorizeEdit($thesis);
        
        // Check if proposal is approved, in progress, or revision
        if ($thesis->status !== 'proposal_approved' && $thesis->status !== 'in_progress' && $thesis->status !== 'revision') {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'Your proposal must be approved before submitting the full thesis.');
        }

        // Check if at least one chapter exists
        if ($thesis->chapters()->count() == 0) {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'Please add at least one chapter before submitting.');
        }

        // Check if all chapters are submitted (not draft or revision)
        $notSubmittedChapters = $thesis->chapters()->whereIn('status', ['draft', 'revision'])->count();
        if ($notSubmittedChapters > 0) {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'All chapters must be submitted before submitting the thesis. (' . $notSubmittedChapters . ' chapter(s) are still draft/revision)');
        }

        $thesis->update([
            'status' => 'submitted',
            'submission_date' => now()
        ]);

        return redirect()->route('theses.show', $thesis)
            ->with('success', 'Thesis submitted for review successfully!');
    }

    // ============================================
    // SUPERVISOR: Review Thesis (First Level)
    // ============================================

    /**
     * Supervisor reviews thesis (Level 1 approval).
     */
    public function supervisorReview(Request $request, Thesis $thesis)
    {
        $this->authorizeSupervisorReview($thesis);

        $request->validate([
            'action' => 'required|in:approve,revision',
            'feedback' => 'required|string',
        ]);

        if ($thesis->status !== 'submitted') {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'This thesis is not pending supervisor review.');
        }

        if ($request->action === 'revision') {
            // Reset all chapters to draft
            $thesis->chapters()->update([
                'status' => 'draft',
                'submitted_at' => null,
                'approved_at' => null,
                'approved_by' => null,
                'revision_feedback' => null,
            ]);
            
            $thesis->update([
                'status' => 'revision',
                'submission_date' => null,
            ]);

            Feedback::create([
                'thesis_id' => $thesis->id,
                'user_id' => Auth::id(),
                'type' => 'supervisor',
                'feedback' => 'Supervisor requested revision: ' . $request->feedback,
                'rating' => null,
            ]);

            return redirect()->route('theses.show', $thesis)
                ->with('warning', 'Thesis sent back for revision. Student needs to revise and resubmit.');
        }

        // Supervisor Approve - Send to Admin
        $thesis->update([
            'status' => 'supervisor_approved',
            'submission_date' => now(),
        ]);

        Feedback::create([
            'thesis_id' => $thesis->id,
            'user_id' => Auth::id(),
            'type' => 'supervisor',
            'feedback' => 'Supervisor approved thesis: ' . $request->feedback,
            'rating' => null,
        ]);

        return redirect()->route('theses.show', $thesis)
            ->with('success', 'Thesis approved by supervisor! Waiting for admin final approval.');
    }

    // ============================================
    // ADMIN: Review Thesis (Second Level - Final)
    // ============================================

    /**
     * Admin reviews thesis (Level 2 - Final approval) and generates certificate.
     */
    public function adminReview(Request $request, Thesis $thesis)
    {
        $this->authorizeAdminReview($thesis);

        $request->validate([
            'action' => 'required|in:approve,revision',
            'feedback' => 'required|string',
        ]);

        if ($thesis->status !== 'supervisor_approved') {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'This thesis is not pending admin review.');
        }

        if ($request->action === 'revision') {
            // Reset all chapters to draft
            $thesis->chapters()->update([
                'status' => 'draft',
                'submitted_at' => null,
                'approved_at' => null,
                'approved_by' => null,
                'revision_feedback' => null,
            ]);
            
            $thesis->update([
                'status' => 'revision',
                'submission_date' => null,
            ]);

            Feedback::create([
                'thesis_id' => $thesis->id,
                'user_id' => Auth::id(),
                'type' => 'examiner',
                'feedback' => 'Admin requested revision: ' . $request->feedback,
                'rating' => null,
            ]);

            return redirect()->route('theses.show', $thesis)
                ->with('warning', 'Thesis rejected by admin. Student needs to revise and resubmit.');
        }

        // ============================================
        // ADMIN FINAL APPROVE - Generate Certificate
        // ============================================

        $chapterCount = $thesis->chapters()->count();
        $notAdminApprovedChapters = $thesis->chapters()
            ->whereNotIn('status', ['admin_approved', 'approved'])
            ->count();

        if ($chapterCount === 0 || $notAdminApprovedChapters > 0) {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'This thesis cannot be final approved yet. All chapters must be approved by admin first.');
        }
        
        // Update thesis status
        $thesis->update([
            'status' => 'approved',
            'submission_date' => now(),
        ]);

        // Save feedback
        Feedback::create([
            'thesis_id' => $thesis->id,
            'user_id' => Auth::id(),
            'type' => 'examiner',
            'feedback' => 'Admin final approved thesis: ' . $request->feedback,
            'rating' => null,
        ]);

        // ============================================
        // GENERATE CERTIFICATE
        // ============================================
        $certificate = Certificate::create([
            'thesis_id' => $thesis->id,
            'student_id' => $thesis->student_id,
            'certificate_number' => Certificate::max('id') + 1,
            'title' => 'Certificate of Thesis Completion',
            'description' => 'This certificate is awarded to ' . $thesis->student->firstname . ' ' . $thesis->student->lastname . 
                             ' for successfully completing the thesis titled "' . $thesis->title . '"',
            'issued_at' => now(),
            'issued_by' => Auth::id(),
            'file_path' => null,
        ]);

        return redirect()->route('theses.show', $thesis)
            ->with('success', '🎉 Thesis approved successfully! Certificate has been generated for the student.')
            ->with('certificate', $certificate);
    }

    // ============================================
    // REJECT THESIS (Alternative - Admin only)
    // ============================================

    /**
     * Admin rejects thesis.
     */
    public function rejectThesis(Request $request, Thesis $thesis)
    {
        if (!Auth::user()->isAdmin()) {
            return redirect()->route('theses.index')
                ->with('error', 'Only admin can reject thesis.');
        }

        if ($thesis->status !== 'submitted' && $thesis->status !== 'supervisor_approved') {
            return redirect()->route('theses.show', $thesis)
                ->with('error', 'This thesis is not pending review.');
        }

        $request->validate([
            'rejection_reason' => 'required|string|max:500',
        ]);

        $thesis->update([
            'status' => 'rejected',
            'proposal_rejection_reason' => $request->rejection_reason,
        ]);

        Feedback::create([
            'thesis_id' => $thesis->id,
            'user_id' => Auth::id(),
            'type' => 'examiner',
            'feedback' => 'Thesis rejected: ' . $request->rejection_reason,
            'rating' => null,
        ]);

        return redirect()->route('theses.show', $thesis)
            ->with('error', 'Thesis rejected. Reason: ' . $request->rejection_reason);
    }

    // ============================================
    // AUTHORIZATION METHODS
    // ============================================

    /**
     * Authorize view access to thesis.
     */
    private function authorizeView($thesis)
    {
        $user = Auth::user();

        // Approved theses are available to all authenticated users for reference.
        if ($thesis->status === 'approved') {
            return true;
        }

        if ($user->isAdmin()) return true;
        if ($user->isStudent() && $thesis->student_id == $user->id) return true;
        if ($user->isSupervisor() && $thesis->supervisor_id == $user->id) return true;
        abort(403, 'Unauthorized access.');
    }

    /**
     * Authorize edit access to thesis.
     */
    private function authorizeEdit($thesis)
    {
        $user = Auth::user();
        if ($user->isAdmin()) return true;
        if ($user->isStudent() && $thesis->student_id == $user->id) return true;
        abort(403, 'Unauthorized access.');
    }

    /**
     * Authorize supervisor review access to thesis.
     */
    private function authorizeSupervisorReview($thesis)
    {
        $user = Auth::user();
        if ($user->isAdmin()) return true;
        if ($user->isSupervisor() && $thesis->supervisor_id == $user->id) return true;
        abort(403, 'Only supervisor or admin can review theses.');
    }

    /**
     * Authorize admin review access to thesis.
     */
    private function authorizeAdminReview($thesis)
    {
        $user = Auth::user();
        if ($user->isAdmin()) return true;
        abort(403, 'Only admin can perform this action.');
    }
}
