<?php
// app/Http/Controllers/ThesisProposalController.php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Thesis;
use App\Models\ThesisProposal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ThesisProposalController extends Controller
{
    /**
     * Display student's proposals.
     */
    public function index()
    {
        $user = Auth::user();
        if (!$user || !$user->isStudent()) {
            return redirect()->route('dashboard')
                ->with('error', 'Only students can view thesis proposals.');
        }

        $proposals = ThesisProposal::with('category')
            ->where('student_id', $user->id)
            ->orderBy('created_at', 'desc')
            ->get();

        $hasActiveThesis = $this->hasActiveThesis($user->id);
        $hasOpenProposals = $this->hasOpenProposals($user->id);

        return view('student.proposals.index', compact('proposals', 'hasActiveThesis', 'hasOpenProposals'));
    }

    /**
     * Show form to create new proposals (3 at once).
     */
    public function create()
    {
        $user = Auth::user();
        if (!$user || !$user->isStudent()) {
            return redirect()->route('dashboard')
                ->with('error', 'Only students can create proposals.');
        }

        $hasActiveThesis = $this->hasActiveThesis($user->id);

        if ($hasActiveThesis) {
            return redirect()->route('student.proposals.index')
                ->with('error', 'You already have an active thesis.');
        }

        $hasOpenProposals = $this->hasOpenProposals($user->id);

        if ($hasOpenProposals) {
            return redirect()->route('student.proposals.index')
                ->with('error', 'Please complete or remove your existing proposals before creating a new set.');
        }

        $categories = Category::all();
        return view('student.proposals.create', compact('categories'));
    }

    /**
     * Store 3 proposals at once.
     */
    public function store(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->isStudent()) {
            return redirect()->route('dashboard')
                ->with('error', 'Only students can submit proposals.');
        }

        $hasActiveThesis = $this->hasActiveThesis($user->id);

        if ($hasActiveThesis) {
            return redirect()->route('student.proposals.index')
                ->with('error', 'You already have an active thesis.');
        }

        $hasOpenProposals = $this->hasOpenProposals($user->id);

        if ($hasOpenProposals) {
            return redirect()->route('student.proposals.index')
                ->with('error', 'Please complete or remove your existing proposals before creating a new set.');
        }

        $validator = Validator::make($request->all(), [
            'proposals' => 'required|array|size:3',
            'proposals.*.title' => 'required|string|max:255|distinct',
            'proposals.*.abstract' => 'required|string',
            'proposals.*.keywords' => 'nullable|string|max:500',
            'proposals.*.category_id' => 'required|exists:categories,id',
            'proposals.*.thesis_type' => 'nullable|string|max:100',
            'proposals.*.from_year' => 'nullable|integer|min:1900|max:' . (date('Y') + 10),
            'proposals.*.to_year' => 'nullable|integer|min:1900|max:' . (date('Y') + 15),
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        DB::transaction(function () use ($request, $user) {
            foreach ($request->input('proposals') as $proposal) {
                ThesisProposal::create([
                    'student_id' => $user->id,
                    'title' => $proposal['title'],
                    'abstract' => $proposal['abstract'],
                    'keywords' => $proposal['keywords'] ?? null,
                    'category_id' => $proposal['category_id'],
                    'thesis_type' => $proposal['thesis_type'] ?? null,
                    'from_year' => $proposal['from_year'] ?? null,
                    'to_year' => $proposal['to_year'] ?? null,
                    'status' => 'submitted',
                    'submitted_at' => now(),
                ]);
            }
        });

        return redirect()->route('student.proposals.index')
            ->with('success', 'All three proposals have been submitted for review successfully.');
    }

    /**
     * Display the specified proposal.
     */
    public function show(ThesisProposal $proposal)
    {
        $this->authorizeProposal($proposal);
        return view('student.proposals.show', compact('proposal'));
    }

    /**
     * Show form to edit proposal.
     */
    public function edit(ThesisProposal $proposal)
    {
        $this->authorizeProposal($proposal);

        if ($proposal->status !== 'draft') {
            return redirect()->route('student.proposals.index')
                ->with('error', 'Only draft proposals can be edited.');
        }

        $categories = Category::all();
        return view('student.proposals.edit', compact('proposal', 'categories'));
    }

    /**
     * Update the specified proposal.
     */
    public function update(Request $request, ThesisProposal $proposal)
    {
        $this->authorizeProposal($proposal);

        if ($proposal->status !== 'draft') {
            return redirect()->route('student.proposals.index')
                ->with('error', 'Only draft proposals can be updated.');
        }

        $validator = Validator::make($request->all(), [
            'title' => 'required|string|max:255',
            'abstract' => 'required|string',
            'keywords' => 'nullable|string|max:500',
            'category_id' => 'required|exists:categories,id',
            'thesis_type' => 'nullable|string|max:100',
            'from_year' => 'nullable|integer|min:1900|max:' . (date('Y') + 10),
            'to_year' => 'nullable|integer|min:1900|max:' . (date('Y') + 15),
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $proposal->update([
            'title' => $request->title,
            'abstract' => $request->abstract,
            'keywords' => $request->keywords,
            'category_id' => $request->category_id,
            'thesis_type' => $request->thesis_type,
            'from_year' => $request->from_year,
            'to_year' => $request->to_year,
        ]);

        return redirect()->route('student.proposals.index')
            ->with('success', 'Proposal updated successfully.');
    }

    /**
     * Delete the specified proposal.
     */
    public function destroy(ThesisProposal $proposal)
    {
        $this->authorizeProposal($proposal);

        if ($proposal->status !== 'draft') {
            return redirect()->route('student.proposals.index')
                ->with('error', 'Only draft proposals can be deleted.');
        }

        $proposal->delete();

        return redirect()->route('student.proposals.index')
            ->with('success', 'Proposal deleted successfully.');
    }

    /**
     * Submit all draft proposals for review.
     */
    public function submitAll()
    {
        $user = Auth::user();
        if (!$user || !$user->isStudent()) {
            return redirect()->route('dashboard')
                ->with('error', 'Only students can submit proposals.');
        }

        $hasActiveThesis = $this->hasActiveThesis($user->id);

        if ($hasActiveThesis) {
            return redirect()->route('student.proposals.index')
                ->with('error', 'You already have an active thesis.');
        }

        $draftProposals = ThesisProposal::where('student_id', $user->id)
            ->where('status', 'draft')
            ->get();

        if ($draftProposals->count() < 3) {
            return redirect()->route('student.proposals.index')
                ->with('error', 'You need at least 3 draft proposals before submitting them for review.');
        }

        ThesisProposal::where('student_id', $user->id)
            ->where('status', 'draft')
            ->update([
                'status' => 'submitted',
                'submitted_at' => now(),
            ]);

        return redirect()->route('student.proposals.index')
            ->with('success', 'All proposals have been submitted for review.');
    }

    /**
     * Authorize proposal access.
     */
    protected function authorizeProposal(ThesisProposal $proposal)
    {
        if (Auth::id() !== $proposal->student_id) {
            abort(403, 'Unauthorized action.');
        }
    }

    private function hasActiveThesis(int $studentId): bool
    {
        return Thesis::where('student_id', $studentId)
            ->whereNotIn('status', ['proposal_draft', 'proposal_rejected', 'approved', 'rejected'])
            ->exists();
    }

    private function hasOpenProposals(int $studentId): bool
    {
        return ThesisProposal::where('student_id', $studentId)
            ->whereIn('status', ['draft', 'submitted', 'pending'])
            ->exists();
    }
}
