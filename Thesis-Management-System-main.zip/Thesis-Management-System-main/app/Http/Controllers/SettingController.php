<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Schema;

class SettingController extends Controller
{
    /**
     * Show settings page
     */
    public function index()
    {
        $settings = Setting::first() ?? new Setting();
        return view('admin.settings.index', compact('settings'));
    }

    /**
     * Update settings
     */
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'system_name' => 'required|string|max:255',
            'university_name' => 'nullable|string|max:255',
            'department_name' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string|max:500',
            'academic_year' => 'nullable|string|max:50',
            'student_registration' => 'nullable|in:open,closed',
            'system_status' => 'nullable|in:active,maintenance',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'favicon' => 'nullable|image|mimes:ico,png|max:1024',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        try {
            $settings = Setting::first();

            if (!$settings) {
                $settings = new Setting();
            }

            if ($request->hasFile('logo')) {
                $logoPath = $request->file('logo')->store('settings/logos', 'public');
                $settings->logo = $logoPath;
            }

            if ($request->hasFile('favicon')) {
                $faviconPath = $request->file('favicon')->store('settings/favicons', 'public');
                $settings->favicon = $faviconPath;
            }

            $settings->system_name = $request->system_name;
            $settings->university_name = $request->input('university_name') ?? '';
            $settings->department_name = $request->input('department_name') ?? '';
            $settings->email = $request->input('email') ?? '';
            $settings->phone = $request->input('phone') ?? '';
            $settings->address = $request->input('address') ?? '';
            $settings->academic_year = $request->input('academic_year') ?? '';

            // Only assign these if the columns exist (prevents SQL errors if migration not yet run)
            if (Schema::hasColumn('settings', 'student_registration')) {
                $settings->student_registration = $request->input('student_registration') ?? 'open';
            }
            if (Schema::hasColumn('settings', 'system_status')) {
                $settings->system_status = $request->input('system_status') ?? 'active';
            }

            $settings->save();

            return redirect()->route('admin.settings')
                ->with('success', 'Settings updated successfully!');

        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to update settings: ' . $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Reset settings to default
     */
    public function reset()
    {
        try {
            $settings = Setting::first();
            
            if ($settings) {
                $settings->fill([
                    'system_name' => 'Thesis Management System',
                    'university_name' => 'University of Yangon',
                    'department_name' => 'Department of Computer Studies',
                    'email' => '',
                    'phone' => '',
                    'address' => '',
                    'academic_year' => '',
                ]);

                if (Schema::hasColumn('settings', 'student_registration')) {
                    $settings->student_registration = 'open';
                }
                if (Schema::hasColumn('settings', 'system_status')) {
                    $settings->system_status = 'active';
                }

                $settings->save();
            } else {
                Setting::create([
                    'system_name' => 'Thesis Management System',
                    'university_name' => 'University of Yangon',
                    'department_name' => 'Department of Computer Studies',
                    'email' => '',
                    'phone' => '',
                    'address' => '',
                    'academic_year' => '',
                    'student_registration' => 'open',
                    'system_status' => 'active',
                ]);
            }

            return redirect()->route('admin.settings')
                ->with('success', 'Settings reset to defaults successfully. Existing uploaded files were preserved.');

        } catch (\Exception $e) {
            return redirect()->route('admin.settings')
                ->with('error', 'Failed to reset settings: ' . $e->getMessage());
        }
    }

    /**
     * Remove logo
     */
    public function removeLogo()
    {
        try {
            $settings = Setting::first();
            
            if ($settings && $settings->logo) {
                Storage::disk('public')->delete($settings->logo);
                $settings->logo = null;
                $settings->save();
                return response()->json(['success' => true]);
            }

            return response()->json(['success' => false, 'error' => 'No logo found']);

        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Remove favicon
     */
    public function removeFavicon()
    {
        try {
            $settings = Setting::first();
            
            if ($settings && $settings->favicon) {
                Storage::disk('public')->delete($settings->favicon);
                $settings->favicon = null;
                $settings->save();
                return response()->json(['success' => true]);
            }

            return response()->json(['success' => false, 'error' => 'No favicon found']);

        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }
}
