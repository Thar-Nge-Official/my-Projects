<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Thesis;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    /**
     * Redirect to appropriate dashboard based on role
     */
    public function index()
    {
        $user = Auth::user();
        
        if ($user->isAdmin()) {
            return redirect()->route('admin.dashboard');
        } elseif ($user->isSupervisor()) {
            return redirect()->route('supervisor.dashboard');
        } else {
            return redirect()->route('student.dashboard');
        }
    }

    /**
     * Admin Dashboard
     */
    public function adminDashboard()
    {
        $data = [
            'totalStudents' => User::where('type', 'student')->count(),
            'totalSupervisors' => User::where('type', 'supervisor')->count(),
            'totalTheses' => Thesis::count(),
            'pendingTheses' => Thesis::where('status', 'submitted')->count(),
            'approvedTheses' => Thesis::where('status', 'approved')->count(),
            'recentTheses' => Thesis::with(['student', 'supervisor'])->latest()->take(5)->get(),
        ];
        // Admin Dashboard View
        return view('admin.dashboard', $data);
    }

    /**
     * Supervisor Dashboard
     */
    public function supervisorDashboard()
    {
        $theses = Thesis::where('supervisor_id', Auth::id())->get();
        $data = [
            'totalTheses' => $theses->count(),
            'pendingReview' => $theses->where('status', 'submitted')->count(),
            'approvedTheses' => $theses->where('status', 'approved')->count(),
            'recentTheses' => $theses->take(5),
        ];
        // Supervisor Dashboard View (dashboard/supervisor.blade.php)
        return view('dashboard.supervisor', $data);
    }

    /**
     * Student Dashboard
     */
    public function studentDashboard()
    {
        $theses = Thesis::where('student_id', Auth::id())->get();
        $data = [
            'totalTheses' => $theses->count(),
            'pendingReview' => $theses->where('status', 'submitted')->count(),
            'approvedTheses' => $theses->where('status', 'approved')->count(),
            'revisionTheses' => $theses->where('status', 'revision')->count(),
            'recentTheses' => $theses->take(5),
        ];
        // Student Dashboard View (dashboard/student.blade.php)
        return view('dashboard.student', $data);
    }
}