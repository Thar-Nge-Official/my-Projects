<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class RegistrationRejectedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $settings;
    public $reason;

    public function __construct(User $user, $settings, $reason = null)
    {
        $this->user = $user;
        $this->settings = $settings;
        $this->reason = $reason;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'သင်၏ မှတ်ပုံတင်ခြင်းကို ငြင်းပယ်လိုက်ပါပြီ - ' . ($this->settings->system_name ?? 'Thesis Management System'),
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.registration-rejected',
        );
    }

    public function attachments(): array
    {
        return [];
    }
}