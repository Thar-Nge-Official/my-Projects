<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class RegistrationApprovedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $settings;

    public function __construct(User $user, $settings)
    {
        $this->user = $user;
        $this->settings = $settings;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'သင်၏ မှတ်ပုံတင်ခြင်းကို ခွင့်ပြုလိုက်ပါပြီ - ' . ($this->settings->system_name ?? 'Thesis Management System'),
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.registration-approved',
        );
    }

    public function attachments(): array
    {
        return [];
    }
}