<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->enum('registration_status', ['pending', 'approved', 'rejected'])
                  ->default('pending')
                  ->after('type');
            $table->timestamp('approved_at')->nullable()->after('registration_status');
            $table->foreignId('approved_by')->nullable()->constrained('users')->after('approved_at');
            $table->text('rejection_reason')->nullable()->after('approved_by');
        });
    }

    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['registration_status', 'approved_at', 'approved_by', 'rejection_reason']);
        });
    }
};