<?php
// database/migrations/xxxx_add_proposal_id_to_theses_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('theses', function (Blueprint $table) {
            $table->foreignId('proposal_id')->nullable()->constrained('thesis_proposals')->onDelete('set null');
        });
    }

    public function down()
    {
        Schema::table('theses', function (Blueprint $table) {
            $table->dropForeign(['proposal_id']);
            $table->dropColumn('proposal_id');
        });
    }
};