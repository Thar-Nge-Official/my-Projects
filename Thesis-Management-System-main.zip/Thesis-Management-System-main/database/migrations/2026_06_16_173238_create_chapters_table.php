<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('chapters', function (Blueprint $table) {
            $table->id();
            $table->foreignId('thesis_id')->constrained('theses')->onDelete('cascade');
            $table->integer('chapter_number');
            $table->string('chapter_title');
            $table->longText('content')->nullable();
            $table->string('file_path')->nullable();
            $table->enum('status', [
                'draft',
                'submitted',
                'approved',
                'revision'
            ])->default('draft');
            $table->timestamp('submitted_at')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->foreignId('approved_by')->nullable()->constrained('users');
            $table->text('revision_feedback')->nullable();
            $table->timestamps();
            
            $table->unique(['thesis_id', 'chapter_number']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('chapters');
    }
};