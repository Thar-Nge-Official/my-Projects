<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->text('qr_code')->nullable()->after('password');
            $table->timestamp('qr_code_generated_at')->nullable()->after('qr_code');
        });
    }

    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['qr_code', 'qr_code_generated_at']);
        });
    }
};