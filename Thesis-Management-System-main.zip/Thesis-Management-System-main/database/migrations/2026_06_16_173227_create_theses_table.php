// database/migrations/xxxx_create_theses_table.php

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('theses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('student_id')->constrained('users')->onDelete('cascade');
            
            // ============================================
            // A supervisor is assigned after proposal approval, so this is nullable.
            // ============================================
            $table->foreignId('supervisor_id')->nullable()->constrained('users')->onDelete('set null');
            
            $table->foreignId('category_id')->constrained('categories')->onDelete('cascade');
            $table->string('title');
            $table->text('abstract');
            $table->text('keywords');
            
            $table->enum('status', [
                'proposal_draft',
                'proposal_submitted',
                'proposal_rejected',
                'proposal_approved',
                'in_progress',
                'submitted',
                'under_review',
                'revision',
                'approved',
                'rejected'
            ])->default('proposal_draft');
            
            $table->timestamp('proposal_submitted_at')->nullable();
            $table->timestamp('proposal_approved_at')->nullable();
            $table->foreignId('proposal_approved_by')->nullable()->constrained('users');
            $table->text('proposal_rejection_reason')->nullable();
            
            // ============================================
            // SUPERVISOR ASSIGNMENT
            // ============================================
            $table->timestamp('supervisor_assigned_at')->nullable();
            $table->foreignId('supervisor_assigned_by')->nullable()->constrained('users');
            
            $table->date('submission_date')->nullable();
            $table->date('defense_date')->nullable();
            $table->string('thesis_type')->nullable();
            $table->integer('from_year')->nullable();
            $table->integer('to_year')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('theses');
    }
};
