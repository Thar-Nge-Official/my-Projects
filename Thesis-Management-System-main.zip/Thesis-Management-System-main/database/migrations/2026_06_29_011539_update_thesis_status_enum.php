<?php
// database/migrations/xxxx_update_thesis_status_enum.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        // First, drop the existing status column
        Schema::table('theses', function (Blueprint $table) {
            $table->dropColumn('status');
        });

        // Then add it back with new values
        Schema::table('theses', function (Blueprint $table) {
            $table->enum('status', [
                'proposal_draft',
                'proposal_submitted',
                'proposal_rejected',
                'proposal_approved',
                'in_progress',
                'submitted',
                'under_review',
                'supervisor_approved',  // New: Supervisor approved, waiting for admin
                'revision',
                'approved',
                'rejected'
            ])->default('proposal_draft')->after('keywords');
        });
    }

    public function down()
    {
        Schema::table('theses', function (Blueprint $table) {
            $table->dropColumn('status');
        });

        Schema::table('theses', function (Blueprint $table) {
            $table->enum('status', [
                'proposal_draft',
                'proposal_submitted',
                'proposal_rejected',
                'proposal_approved',
                'in_progress',
                'submitted',
                'under_review',
                'revision',
                'approved',
                'rejected'
            ])->default('proposal_draft')->after('keywords');
        });
    }
};