<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('thesis_proposals', function (Blueprint $table) {
            if (!Schema::hasColumn('thesis_proposals', 'supervisor_id')) {
                $table->foreignId('supervisor_id')->nullable()->constrained('users')->onDelete('set null');
            }

            if (!Schema::hasColumn('thesis_proposals', 'admin_comments')) {
                $table->text('admin_comments')->nullable();
            }

            if (!Schema::hasColumn('thesis_proposals', 'rejected_date')) {
                $table->timestamp('rejected_date')->nullable();
            }

            if (!Schema::hasColumn('thesis_proposals', 'rejected_by')) {
                $table->foreignId('rejected_by')->nullable()->constrained('users')->onDelete('set null');
            }

            if (!Schema::hasColumn('thesis_proposals', 'supervisor_recommendation')) {
                $table->text('supervisor_recommendation')->nullable();
            }

            if (!Schema::hasColumn('thesis_proposals', 'supervisor_status')) {
                $table->string('supervisor_status')->nullable();
            }

            if (!Schema::hasColumn('thesis_proposals', 'supervisor_reviewed_date')) {
                $table->timestamp('supervisor_reviewed_date')->nullable();
            }
        });
    }

    public function down()
    {
        Schema::table('thesis_proposals', function (Blueprint $table) {
            if (Schema::hasColumn('thesis_proposals', 'supervisor_reviewed_date')) {
                $table->dropColumn('supervisor_reviewed_date');
            }
            if (Schema::hasColumn('thesis_proposals', 'supervisor_status')) {
                $table->dropColumn('supervisor_status');
            }
            if (Schema::hasColumn('thesis_proposals', 'supervisor_recommendation')) {
                $table->dropColumn('supervisor_recommendation');
            }
            if (Schema::hasColumn('thesis_proposals', 'rejected_by')) {
                $table->dropForeign(['rejected_by']);
                $table->dropColumn('rejected_by');
            }
            if (Schema::hasColumn('thesis_proposals', 'rejected_date')) {
                $table->dropColumn('rejected_date');
            }
            if (Schema::hasColumn('thesis_proposals', 'admin_comments')) {
                $table->dropColumn('admin_comments');
            }
            if (Schema::hasColumn('thesis_proposals', 'supervisor_id')) {
                $table->dropForeign(['supervisor_id']);
                $table->dropColumn('supervisor_id');
            }
        });
    }
};
