<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('settings')) {
            Schema::table('settings', function (Blueprint $table) {
                if (!Schema::hasColumn('settings', 'student_registration')) {
                    $table->string('student_registration')->nullable()->default('open')->after('academic_year');
                }
                if (!Schema::hasColumn('settings', 'system_status')) {
                    $table->string('system_status')->nullable()->default('active')->after('student_registration');
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('settings')) {
            Schema::table('settings', function (Blueprint $table) {
                if (Schema::hasColumn('settings', 'system_status')) {
                    $table->dropColumn('system_status');
                }
                if (Schema::hasColumn('settings', 'student_registration')) {
                    $table->dropColumn('student_registration');
                }
            });
        }
    }
};
