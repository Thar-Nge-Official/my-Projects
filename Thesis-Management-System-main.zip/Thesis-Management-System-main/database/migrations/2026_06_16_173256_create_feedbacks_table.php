<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('feedbacks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('thesis_id')->constrained('theses')->onDelete('cascade');
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->enum('type', ['supervisor', 'examiner', 'admin'])->default('supervisor');
            $table->text('feedback');
            $table->integer('rating')->nullable();
            $table->timestamps();
        });
    } 

    public function down()
    {
        Schema::dropIfExists('feedbacks');
    }
};