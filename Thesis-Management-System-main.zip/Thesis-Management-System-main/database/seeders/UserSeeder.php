<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run()
    {
        // Admin Users
        User::create([
            'firstname' => 'Admin',
            'lastname' => 'User',
            'email' => 'admin@thesis.com',
            'password' => Hash::make('password'),
            'type' => 'admin',
            'rank' => 'Professor and Head',
            'roll_no' => null,
            'class' => null,
            'fromY' => '2025',
            'toY' => '2026',
            'avatar' => 'no-image-available.png',
            'registration_status' => 'approved',
        ]);

        User::create([
            'firstname' => 'Soe Mya Mya',
            'lastname' => 'Aye',
            'email' => 'smma@gmail.com',
            'password' => Hash::make('password'),
            'type' => 'admin',
            'rank' => 'Professor and Head',
            'roll_no' => null,
            'class' => null,
            'fromY' => '2025',
            'toY' => '2026',
            'avatar' => 'no-image-available.png',
            'registration_status' => 'approved',
        ]);

        // Supervisor Users
        User::create([
            'firstname' => 'Supervisor',
            'lastname' => 'One',
            'email' => 'supervisor@thesis.com',
            'password' => Hash::make('password'),
            'type' => 'supervisor',
            'rank' => 'Professor',
            'roll_no' => null,
            'class' => null,
            'fromY' => '2025',
            'toY' => '2026',
            'avatar' => 'no-image-available.png',
            'registration_status' => 'approved',
        ]);

        User::create([
            'firstname' => 'Supervisor',
            'lastname' => 'Two',
            'email' => 'supervisor2@thesis.com',
            'password' => Hash::make('password'),
            'type' => 'supervisor',
            'rank' => 'Associate Professor',
            'roll_no' => null,
            'class' => null,
            'fromY' => '2025',
            'toY' => '2026',
            'avatar' => 'no-image-available.png',
            'registration_status' => 'approved',
        ]);

        // Student Users
        User::create([
            'firstname' => 'Student',
            'lastname' => 'One',
            'email' => 'student@thesis.com',
            'password' => Hash::make('password'),
            'type' => 'student',
            'rank' => null,
            'roll_no' => 'HCS-001',
            'class' => 'Fourth Year',
            'fromY' => '2025',
            'toY' => '2026',
            'avatar' => 'no-image-available.png',
            'registration_status' => 'approved',
        ]);

        User::create([
            'firstname' => 'Student',
            'lastname' => 'Two',
            'email' => 'student2@thesis.com',
            'password' => Hash::make('password'),
            'type' => 'student',
            'rank' => null,
            'roll_no' => 'HCS-002',
            'class' => 'Fourth Year',
            'fromY' => '2025',
            'toY' => '2026',
            'avatar' => 'no-image-available.png',
            'registration_status' => 'approved',
        ]);

        User::create([
            'firstname' => 'Thar',
            'lastname' => 'Nge',
            'email' => 'tharnge19111999twa@gmail.com',
            'password' => Hash::make('password'),
            'type' => 'student',
            'rank' => null,
            'roll_no' => '2MCS-2',
            'class' => 'Master Second Year',
            'fromY' => '2025',
            'toY' => '2026',
            'avatar' => 'no-image-available.png',
            'registration_status' => 'approved',
        ]);

        User::create([
            'firstname' => 'Kaung Kin',
            'lastname' => 'Htet',
            'email' => 'kk@gmail.com',
            'password' => Hash::make('password'),
            'type' => 'student',
            'rank' => null,
            'roll_no' => '3HCS-2',
            'class' => 'Third Year Honours',
            'fromY' => '2025',
            'toY' => '2026',
            'avatar' => 'no-image-available.png',
            'registration_status' => 'approved',
        ]);

        // Pending User (for testing registration approval)
        User::create([
            'firstname' => 'Pending',
            'lastname' => 'User',
            'email' => 'pending@thesis.com',
            'password' => Hash::make('password'),
            'type' => 'student',
            'rank' => null,
            'roll_no' => 'PENDING-001',
            'class' => 'Pending Class',
            'fromY' => '2025',
            'toY' => '2026',
            'avatar' => 'no-image-available.png',
            'registration_status' => 'pending',
        ]);

        $this->command->info('Users seeded successfully!');
        $this->command->info('Admin: admin@thesis.com / password');
        $this->command->info('Supervisor: supervisor@thesis.com / password');
        $this->command->info('Student: student@thesis.com / password');
        $this->command->info('Pending: pending@thesis.com / password (pending approval)');
    }
}