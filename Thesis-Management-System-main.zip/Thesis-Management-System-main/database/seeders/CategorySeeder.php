<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run()
    {
        $categories = [
            ['name' => 'Computer Science', 'description' => 'Thesis related to computer science, algorithms, programming, and software development'],
            ['name' => 'Data Science', 'description' => 'Thesis focused on data analysis, machine learning, artificial intelligence, and big data'],
            ['name' => 'Information Technology', 'description' => 'Thesis about IT infrastructure, networking, cybersecurity, and system administration'],
            ['name' => 'Software Engineering', 'description' => 'Thesis covering software development methodologies, project management, and quality assurance'],
            ['name' => 'Web Development', 'description' => 'Thesis related to web technologies, frontend/backend development, and web frameworks'],
            ['name' => 'Mobile Development', 'description' => 'Thesis about mobile app development, Android, iOS, and cross-platform development'],
            ['name' => 'Database Systems', 'description' => 'Thesis focused on database design, management, optimization, and NoSQL systems'],
            ['name' => 'Cybersecurity', 'description' => 'Thesis about information security, network security, cryptography, and ethical hacking'],
            ['name' => 'Cloud Computing', 'description' => 'Thesis related to cloud services, virtualization, distributed systems, and DevOps'],
            ['name' => 'Human-Computer Interaction', 'description' => 'Thesis about UI/UX design, user experience, accessibility, and interaction design'],
            ['name' => 'Artificial Intelligence', 'description' => 'Thesis focused on AI, neural networks, natural language processing, and computer vision'],
            ['name' => 'Internet of Things (IoT)', 'description' => 'Thesis about IoT devices, sensors, smart systems, and embedded systems'],
            ['name' => 'Blockchain Technology', 'description' => 'Thesis related to blockchain, cryptocurrency, smart contracts, and decentralized systems'],
            ['name' => 'E-Government', 'description' => 'Thesis about digital government services, e-governance, and public administration systems'],
            ['name' => 'E-Learning', 'description' => 'Thesis focused on educational technology, online learning platforms, and digital education'],
        ];

        foreach ($categories as $category) {
            Category::create($category);
        }

        $this->command->info('Categories seeded successfully!');
    }
}