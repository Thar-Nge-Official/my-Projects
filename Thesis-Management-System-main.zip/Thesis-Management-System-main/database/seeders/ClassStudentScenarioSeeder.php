<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Certificate;
use App\Models\Chapter;
use App\Models\Feedback;
use App\Models\Thesis;
use App\Models\ThesisProposal;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class ClassStudentScenarioSeeder extends Seeder
{
    public function run(): void
    {
        $classes = ['Final Year', 'Master Second Year', 'Second Year Honours'];
        $categories = Category::orderBy('id')->pluck('id')->values();
        $supervisors = User::where('type', 'supervisor')->orderBy('id')->pluck('id')->values();
        $adminId = User::where('type', 'admin')->orderBy('id')->value('id');

        if ($categories->isEmpty() || $supervisors->isEmpty() || !$adminId) {
            $this->command?->warn('Seeder skipped: categories, supervisors, and an admin user are required.');
            return;
        }

        DB::transaction(function () use ($classes, $categories, $supervisors, $adminId) {
            foreach ($classes as $classIndex => $className) {
                for ($studentNumber = 1; $studentNumber <= 10; $studentNumber++) {
                    $isCompleted = $studentNumber <= 5;
                    $student = $this->createStudent($className, $classIndex, $studentNumber);

                    if ($isCompleted) {
                        $this->createCompletedScenario($student, $className, $classIndex, $studentNumber, $categories, $supervisors, $adminId);
                    } else {
                        $this->createIncompleteScenario($student, $className, $classIndex, $studentNumber, $categories, $supervisors, $adminId);
                    }
                }
            }
        });
    }

    private function createStudent(string $className, int $classIndex, int $studentNumber): User
    {
        $classSlug = Str::slug($className);
        $email = "seed.{$classSlug}.student{$studentNumber}@example.test";

        return User::firstOrCreate(
            ['email' => $email],
            [
                'firstname' => $this->firstName($studentNumber),
                'lastname' => $this->lastName($classIndex, $studentNumber),
                'roll_no' => strtoupper(substr(str_replace(' ', '', $className), 0, 4)) . str_pad((string) $studentNumber, 3, '0', STR_PAD_LEFT),
                'class' => $className,
                'fromY' => '2025',
                'toY' => '2026',
                'phone' => '09' . str_pad((string) ($classIndex + 1), 2, '0', STR_PAD_LEFT) . str_pad((string) $studentNumber, 7, '0', STR_PAD_LEFT),
                'address' => "{$className} sample student address {$studentNumber}",
                'password' => Hash::make('Student@12345'),
                'type' => 'student',
                'registration_status' => 'approved',
                'approved_at' => now(),
                'approved_by' => User::where('type', 'admin')->orderBy('id')->value('id'),
                'avatar' => 'no-image-available.png',
            ]
        );
    }

    private function createCompletedScenario(User $student, string $className, int $classIndex, int $studentNumber, $categories, $supervisors, int $adminId): void
    {
        $categoryId = $categories[($studentNumber + $classIndex) % $categories->count()];
        $supervisorId = $supervisors[($studentNumber + $classIndex) % $supervisors->count()];
        $baseTitle = "{$className} Completed Thesis {$studentNumber}";

        [$selectedProposal] = $this->createProposalSet($student, $baseTitle, $categoryId, $supervisorId, $adminId, true);

        $thesis = Thesis::firstOrCreate(
            ['proposal_id' => $selectedProposal->id],
            [
                'student_id' => $student->id,
                'supervisor_id' => $supervisorId,
                'category_id' => $categoryId,
                'title' => $selectedProposal->title,
                'abstract' => $selectedProposal->abstract,
                'keywords' => $selectedProposal->keywords,
                'status' => 'approved',
                'proposal_submitted_at' => now()->subMonths(7),
                'proposal_approved_at' => now()->subMonths(6),
                'proposal_approved_by' => $adminId,
                'supervisor_assigned_at' => now()->subMonths(6),
                'supervisor_assigned_by' => $adminId,
                'submission_date' => now()->subMonth(),
                'thesis_type' => 'System Development',
                'from_year' => 2025,
                'to_year' => 2026,
            ]
        );

        for ($chapterNumber = 1; $chapterNumber <= 3; $chapterNumber++) {
            Chapter::firstOrCreate(
                ['thesis_id' => $thesis->id, 'chapter_number' => $chapterNumber],
                [
                    'chapter_title' => $this->chapterTitle($chapterNumber),
                    'content' => json_encode([
                        [
                            'number' => "{$chapterNumber}.1",
                            'level' => 1,
                            'title' => 'Overview',
                            'paragraphs' => ["Completed sample content for {$baseTitle}, chapter {$chapterNumber}."],
                            'image' => '',
                            'caption' => '',
                        ],
                    ]),
                    'status' => 'admin_approved',
                    'submitted_at' => now()->subMonths(2)->addDays($chapterNumber),
                    'approved_at' => now()->subMonth()->addDays($chapterNumber),
                    'approved_by' => $adminId,
                ]
            );
        }

        Feedback::firstOrCreate(
            ['thesis_id' => $thesis->id, 'user_id' => $adminId, 'type' => 'examiner'],
            ['feedback' => "Completed sample thesis approved for {$student->firstname} {$student->lastname}.", 'rating' => 5]
        );

        Certificate::firstOrCreate(
            ['thesis_id' => $thesis->id],
            [
                'student_id' => $student->id,
                'certificate_number' => (Certificate::max('id') ?? 0) + 1,
                'title' => 'Certificate of Thesis Completion',
                'description' => 'Sample completion certificate for ' . $student->firstname . ' ' . $student->lastname,
                'issued_at' => now()->subWeeks(2),
                'issued_by' => $adminId,
                'file_path' => null,
            ]
        );
    }

    private function createIncompleteScenario(User $student, string $className, int $classIndex, int $studentNumber, $categories, $supervisors, int $adminId): void
    {
        $categoryId = $categories[($studentNumber + $classIndex) % $categories->count()];
        $supervisorId = $supervisors[($studentNumber + $classIndex) % $supervisors->count()];
        $baseTitle = "{$className} Incomplete Thesis {$studentNumber}";
        $case = ($studentNumber - 6) % 5;

        if ($case === 0) {
            $this->createProposalSet($student, $baseTitle, $categoryId, $supervisorId, $adminId, false, 'submitted');
            return;
        }

        [$selectedProposal] = $this->createProposalSet($student, $baseTitle, $categoryId, $supervisorId, $adminId, true);

        $statuses = ['proposal_approved', 'in_progress', 'submitted', 'revision'];
        $thesisStatus = $statuses[$case - 1];

        $thesis = Thesis::firstOrCreate(
            ['proposal_id' => $selectedProposal->id],
            [
                'student_id' => $student->id,
                'supervisor_id' => $supervisorId,
                'category_id' => $categoryId,
                'title' => $selectedProposal->title,
                'abstract' => $selectedProposal->abstract,
                'keywords' => $selectedProposal->keywords,
                'status' => $thesisStatus,
                'proposal_submitted_at' => now()->subMonths(4),
                'proposal_approved_at' => now()->subMonths(3),
                'proposal_approved_by' => $adminId,
                'supervisor_assigned_at' => now()->subMonths(3),
                'supervisor_assigned_by' => $adminId,
                'submission_date' => in_array($thesisStatus, ['submitted', 'revision'], true) ? now()->subWeeks(2) : null,
                'thesis_type' => 'System Development',
                'from_year' => 2025,
                'to_year' => 2026,
            ]
        );

        $chapterStatus = match ($thesisStatus) {
            'proposal_approved' => 'draft',
            'in_progress' => 'draft',
            'submitted' => 'submitted',
            'revision' => 'revision',
            default => 'draft',
        };

        for ($chapterNumber = 1; $chapterNumber <= 2; $chapterNumber++) {
            Chapter::firstOrCreate(
                ['thesis_id' => $thesis->id, 'chapter_number' => $chapterNumber],
                [
                    'chapter_title' => $this->chapterTitle($chapterNumber),
                    'content' => json_encode([
                        [
                            'number' => "{$chapterNumber}.1",
                            'level' => 1,
                            'title' => 'Draft Section',
                            'paragraphs' => ["Incomplete sample content for {$baseTitle}, chapter {$chapterNumber}."],
                            'image' => '',
                            'caption' => '',
                        ],
                    ]),
                    'status' => $chapterStatus,
                    'submitted_at' => in_array($chapterStatus, ['submitted', 'revision'], true) ? now()->subWeeks(3) : null,
                    'approved_at' => null,
                    'approved_by' => null,
                    'revision_feedback' => $chapterStatus === 'revision' ? 'Sample revision required before completion.' : null,
                ]
            );
        }
    }

    private function createProposalSet(User $student, string $baseTitle, int $categoryId, int $supervisorId, int $adminId, bool $approveOne, string $status = 'submitted'): array
    {
        $proposals = [];

        for ($proposalNumber = 1; $proposalNumber <= 3; $proposalNumber++) {
            $isSelected = $approveOne && $proposalNumber === 1;
            $proposalStatus = $approveOne
                ? ($isSelected ? 'approved' : 'rejected')
                : $status;

            $proposals[] = ThesisProposal::firstOrCreate(
                ['student_id' => $student->id, 'title' => "{$baseTitle} Proposal {$proposalNumber}"],
                [
                    'abstract' => "Sample abstract for {$baseTitle} proposal {$proposalNumber}.",
                    'keywords' => 'sample, thesis, management',
                    'category_id' => $categoryId,
                    'thesis_type' => 'System Development',
                    'from_year' => 2025,
                    'to_year' => 2026,
                    'status' => $proposalStatus,
                    'is_selected' => $isSelected,
                    'rejection_reason' => $proposalStatus === 'rejected' ? 'Auto-rejected because another proposal was approved.' : null,
                    'submitted_at' => now()->subMonths($approveOne ? 7 : 1),
                    'approved_at' => $isSelected ? now()->subMonths(6) : null,
                    'approved_by' => $isSelected ? $adminId : null,
                    'supervisor_id' => $supervisorId,
                ]
            );
        }

        return $proposals;
    }

    private function firstName(int $studentNumber): string
    {
        return ['Aye', 'Mya', 'Hla', 'Nilar', 'Khin', 'May', 'Ei', 'Thandar', 'Su', 'Win'][$studentNumber - 1];
    }

    private function lastName(int $classIndex, int $studentNumber): string
    {
        return ['Tun', 'Win', 'Kyaw', 'Htet', 'Zaw', 'Naing', 'Oo', 'Myint', 'Lwin', 'Aung'][$studentNumber - 1] . ' ' . ($classIndex + 1);
    }

    private function chapterTitle(int $chapterNumber): string
    {
        return match ($chapterNumber) {
            1 => 'Introduction',
            2 => 'Literature Review',
            3 => 'Implementation and Results',
            default => 'Chapter ' . $chapterNumber,
        };
    }
}
