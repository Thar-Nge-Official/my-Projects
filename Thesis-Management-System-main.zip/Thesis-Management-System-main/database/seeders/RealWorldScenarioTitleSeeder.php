<?php

namespace Database\Seeders;

use App\Models\Thesis;
use App\Models\ThesisProposal;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class RealWorldScenarioTitleSeeder extends Seeder
{
    public function run(): void
    {
        $scenarioTitles = [
            'Final Year' => [
                'AI-Powered Attendance Monitoring System for University Classrooms',
                'Smart Library Seat Reservation and Occupancy Tracking Platform',
                'Campus Lost-and-Found Management System with Image Search',
                'Online Internship Application and Approval Portal',
                'Student Mental Health Appointment Booking and Case Tracking System',
                'Queue Management System for University Administration Offices',
                'Digital Canteen Ordering and Inventory Management System',
                'Campus Event Registration and QR Check-In Platform',
                'Peer Tutoring Marketplace for Computer Science Students',
                'Hostel Maintenance Request and Work Order Tracking System',
            ],
            'Master Second Year' => [
                'Predictive Analytics Platform for Student Dropout Risk',
                'Natural Language Thesis Topic Recommendation System',
                'Secure Research Data Catalog with Role-Based Access Control',
                'IoT-Based Energy Monitoring Dashboard for Computer Labs',
                'Blockchain-Based Academic Certificate Verification System',
                'Machine Learning Model for Scholarship Eligibility Screening',
                'Research Collaboration Portal for Supervisors and Graduate Students',
                'Plagiarism Similarity Reporting System for Thesis Drafts',
                'Cloud-Based Backup and Recovery Dashboard for Department Servers',
                'Academic Timetable Optimization System Using Genetic Algorithms',
            ],
            'Second Year Honours' => [
                'Mobile Expense Tracker for University Students',
                'Bus Route Finder and Arrival Notification App for Campus Transport',
                'Web-Based Quiz Practice System with Progress Analytics',
                'Personal Study Planner with Deadline Reminders',
                'Online Book Exchange Platform for Students',
                'Simple Clinic Appointment System for Campus Health Services',
                'Food Allergy Alert App for University Canteens',
                'Digital Notice Board for Department Announcements',
                'Student Club Membership and Activity Tracking System',
                'Basic Cybersecurity Awareness Learning Platform',
            ],
        ];

        $proposalAlternatives = [
            'Automated Help Desk Ticket Prioritization for Student Services',
            'Course Feedback Analytics Dashboard for Academic Departments',
            'Computer Lab Equipment Borrowing and Return Management System',
            'Digital Complaint Tracking Portal for University Administration',
            'Exam Hall Seat Allocation and Invigilation Scheduling System',
            'Scholarship Application Screening and Document Verification Portal',
            'Department Asset Inventory and Maintenance Reminder System',
            'Student Attendance Risk Alert Dashboard for Supervisors',
            'Online Research Survey Builder with Response Analytics',
            'Faculty Meeting Minutes and Action Item Tracking System',
        ];

        $counts = [
            'students' => 0,
            'proposals' => 0,
            'theses' => 0,
        ];

        DB::transaction(function () use ($scenarioTitles, $proposalAlternatives, &$counts) {
            foreach ($scenarioTitles as $className => $titles) {
                foreach ($titles as $index => $selectedTitle) {
                    $studentNumber = $index + 1;
                    $student = User::where('email', $this->seedEmail($className, $studentNumber))->first();

                    if (!$student) {
                        continue;
                    }

                    $counts['students']++;
                    $proposals = ThesisProposal::where('student_id', $student->id)
                        ->orderBy('id')
                        ->get();

                    foreach ($proposals as $proposalIndex => $proposal) {
                        $title = $proposalIndex === 0
                            ? $selectedTitle
                            : $proposalAlternatives[($index + $proposalIndex) % count($proposalAlternatives)];

                        if ($proposal->title !== $title) {
                            $proposal->title = $title;
                            $proposal->save();
                            $counts['proposals']++;
                        }
                    }

                    $selectedProposal = $proposals->firstWhere('is_selected', true)
                        ?? $proposals->firstWhere('status', 'approved')
                        ?? $proposals->first();

                    if (!$selectedProposal) {
                        continue;
                    }

                    Thesis::where('student_id', $student->id)
                        ->where('proposal_id', $selectedProposal->id)
                        ->get()
                        ->each(function (Thesis $thesis) use ($selectedProposal, &$counts) {
                            if ($thesis->title === $selectedProposal->title) {
                                return;
                            }

                            $thesis->title = $selectedProposal->title;
                            $thesis->save();
                            $counts['theses']++;
                        });
                }
            }
        });

        $this->command?->info(
            "Real-world titles updated for {$counts['students']} seeded students, "
            . "{$counts['proposals']} proposals, and {$counts['theses']} theses."
        );
    }

    private function seedEmail(string $className, int $studentNumber): string
    {
        return 'seed.' . Str::slug($className) . ".student{$studentNumber}@example.test";
    }
}
