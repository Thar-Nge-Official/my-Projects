<?php
// bootstrap/providers.php

return [
    /*
    |--------------------------------------------------------------------------
    | Autoloaded Service Providers
    |--------------------------------------------------------------------------
    |
    | The service providers listed here will be automatically loaded on the
    | request to your application. Feel free to add your own services to
    | this array to grant expanded functionality to your applications.
    |
    */

    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    // App\Providers\BroadcastServiceProvider::class,
    App\Providers\EventServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
    
    /*
    |--------------------------------------------------------------------------
    | Package Service Providers
    |--------------------------------------------------------------------------
    |
    | Here you can add service providers for packages that you have installed.
    | These will be loaded automatically when the application is bootstrapped.
    |
    */
    
    // ============================================
    // DOMPDF - For PDF Generation
    // ============================================
    Barryvdh\DomPDF\ServiceProvider::class,

];