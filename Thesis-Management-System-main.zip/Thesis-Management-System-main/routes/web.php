<?php
// routes/web.php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\QRCodeController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\RegistrationController;
use App\Http\Controllers\ForgotPasswordController;
use App\Http\Controllers\ResetPasswordController;
use App\Http\Controllers\ThesisController;
use App\Http\Controllers\ThesisApprovalController;
use App\Http\Controllers\ThesisProposalController;  // <-- NEW (student-facing)
use App\Http\Controllers\ChapterController;
use App\Http\Controllers\CertificateController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// ============================================
// PUBLIC ROUTES
// ============================================

Route::get('/', function () {
    return view('welcome');
})->name('home');

Route::view('/terms-of-service', 'legal.terms')->name('legal.terms');
Route::view('/privacy-policy', 'legal.privacy')->name('legal.privacy');

// ============================================
// AUTHENTICATION ROUTES
// ============================================

Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// ============================================
// PASSWORD RESET ROUTES
// ============================================

Route::get('/forgot-password', [ForgotPasswordController::class, 'showForgotForm'])->name('password.request');
Route::post('/forgot-password', [ForgotPasswordController::class, 'sendResetLink'])->name('password.email');
Route::get('/reset-password/{token}', [ForgotPasswordController::class, 'showResetForm'])->name('password.reset');
Route::post('/reset-password', [ForgotPasswordController::class, 'reset'])->name('password.update');

// ============================================
// QR CODE ROUTES
// ============================================

Route::get('/qr-scanner', [QRCodeController::class, 'showScanner'])->name('qr.scanner');
Route::get('/qr-login/scan/{data}', [QRCodeController::class, 'scanLogin'])->name('qr.login.scan');

Route::middleware(['auth', 'system.status'])->prefix('qr')->group(function () {
    Route::match(['get', 'post'], '/show', [QRCodeController::class, 'showQRCode'])->name('qr.show');
    Route::get('/download', [QRCodeController::class, 'downloadQR'])->name('qr.download');
    Route::post('/regenerate', [QRCodeController::class, 'regenerateQRCode'])->name('qr.regenerate');
});

// ============================================
// PROFILE ROUTES (Protected)
// ============================================

Route::middleware(['auth', 'system.status'])->prefix('profile')->group(function () {
    Route::get('/', [ProfileController::class, 'index'])->name('profile.index');
    Route::put('/', [ProfileController::class, 'update'])->name('profile.update');
    Route::post('/change-password', [ProfileController::class, 'changePassword'])->name('profile.change-password');
    Route::delete('/remove-avatar', [ProfileController::class, 'removeAvatar'])->name('profile.remove-avatar');
});

// ============================================
// DASHBOARD ROUTES
// ============================================

Route::middleware(['auth', 'system.status'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
});

// ============================================
// ADMIN ROUTES
// ============================================

Route::middleware(['auth', 'system.status', 'admin'])->prefix('admin')->group(function () {
    
    Route::get('/dashboard', [DashboardController::class, 'adminDashboard'])->name('admin.dashboard');
    
    // ============================================
    // USER MANAGEMENT
    // ============================================
    Route::get('/users', [AdminController::class, 'users'])->name('admin.users');
    Route::get('/users/create', [AdminController::class, 'createUser'])->name('admin.users.create');
    Route::post('/users', [AdminController::class, 'storeUser'])->name('admin.users.store');
    Route::get('/users/{user}/edit', [AdminController::class, 'editUser'])->name('admin.users.edit');
    Route::put('/users/{user}', [AdminController::class, 'updateUser'])->name('admin.users.update');
    Route::delete('/users/{user}', [AdminController::class, 'deleteUser'])->name('admin.users.delete');
    
    // ============================================
    // CATEGORY MANAGEMENT
    // ============================================
    Route::get('/categories', [CategoryController::class, 'index'])->name('admin.categories');
    Route::get('/categories/create', [CategoryController::class, 'create'])->name('admin.categories.create');
    Route::post('/categories', [CategoryController::class, 'store'])->name('admin.categories.store');
    Route::get('/categories/{category}/edit', [CategoryController::class, 'edit'])->name('admin.categories.edit');
    Route::put('/categories/{category}', [CategoryController::class, 'update'])->name('admin.categories.update');
    Route::delete('/categories/{category}', [CategoryController::class, 'destroy'])->name('admin.categories.destroy');
    
    // ============================================
    // REGISTRATION MANAGEMENT
    // ============================================
    Route::get('/registrations', [RegistrationController::class, 'index'])->name('admin.registrations');
    Route::post('/registrations/{user}/approve', [RegistrationController::class, 'approve'])->name('admin.registrations.approve');
    Route::post('/registrations/{user}/reject', [RegistrationController::class, 'reject'])->name('admin.registrations.reject');
    Route::delete('/registrations/{user}/delete-rejected', [RegistrationController::class, 'deleteRejected'])->name('admin.registrations.delete-rejected');
    
    // ============================================
    // SYSTEM SETTINGS
    // ============================================
    Route::get('/settings', [SettingController::class, 'index'])->name('admin.settings');
    Route::put('/settings', [SettingController::class, 'update'])->name('admin.settings.update');
    Route::post('/settings/reset', [SettingController::class, 'reset'])->name('admin.settings.reset');
    Route::delete('/settings/logo', [SettingController::class, 'removeLogo'])->name('admin.settings.remove-logo');
    Route::delete('/settings/favicon', [SettingController::class, 'removeFavicon'])->name('admin.settings.remove-favicon');

    // ============================================
    // SUPERVISOR ASSIGNMENT ROUTE
    // ============================================
    Route::post('/assign-supervisor/{thesis}', [ThesisController::class, 'assignSupervisor'])
        ->name('admin.assign-supervisor');

    // ============================================
    // NEW: ADMIN PROPOSAL ROUTES
    // ============================================
    Route::redirect('proposals/index', 'proposals');
    Route::prefix('proposals')->group(function () {
        Route::get('/', [ThesisApprovalController::class, 'index'])->name('admin.proposals.index');
        Route::get('/pending', [ThesisApprovalController::class, 'pending'])->name('admin.proposals.pending');
        Route::get('/approved', [ThesisApprovalController::class, 'approved'])->name('admin.proposals.approved');
        Route::get('/rejected', [ThesisApprovalController::class, 'rejected'])->name('admin.proposals.rejected');
        Route::get('/{proposal}', [ThesisApprovalController::class, 'show'])->name('admin.proposals.show');
        Route::post('/{proposal}/approve', [ThesisApprovalController::class, 'approve'])->name('admin.proposals.approve');
        Route::post('/{proposal}/reject', [ThesisApprovalController::class, 'reject'])->name('admin.proposals.reject');
    });
});

// ============================================
// SUPERVISOR ROUTES
// ============================================

Route::middleware(['auth', 'system.status', 'supervisor'])->prefix('supervisor')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'supervisorDashboard'])->name('supervisor.dashboard');

    // Supervisor proposal routes (view-only, no approve/reject)
    Route::prefix('proposals')->group(function () {
        Route::get('/', [\App\Http\Controllers\ThesisApprovalController::class, 'supervisorIndex'])->name('supervisor.proposals.index');
        Route::get('/pending', [\App\Http\Controllers\ThesisApprovalController::class, 'supervisorPending'])->name('supervisor.proposals.pending');
        Route::get('/approved', [\App\Http\Controllers\ThesisApprovalController::class, 'supervisorApproved'])->name('supervisor.proposals.approved');
        Route::get('/rejected', [\App\Http\Controllers\ThesisApprovalController::class, 'supervisorRejected'])->name('supervisor.proposals.rejected');
        Route::get('/{proposal}', [\App\Http\Controllers\ThesisApprovalController::class, 'supervisorShow'])->name('supervisor.proposals.show');
        Route::post('/{proposal}/recommend', [\App\Http\Controllers\ThesisApprovalController::class, 'recommend'])->name('supervisor.proposals.recommend');
    });
});

// ============================================
// STUDENT ROUTES
// ============================================

Route::middleware(['auth', 'system.status', 'student'])->prefix('student')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'studentDashboard'])->name('student.dashboard');
    
    // ============================================
    // NEW: STUDENT PROPOSAL ROUTES
    // ============================================
    Route::prefix('proposals')->group(function () {
        Route::get('/', [ThesisProposalController::class, 'index'])->name('student.proposals.index');
        Route::get('/create', [ThesisProposalController::class, 'create'])->name('student.proposals.create');
        Route::post('/', [ThesisProposalController::class, 'store'])->name('student.proposals.store');
        Route::get('/{proposal}', [ThesisProposalController::class, 'show'])->name('student.proposals.show');
        Route::get('/{proposal}/edit', [ThesisProposalController::class, 'edit'])->name('student.proposals.edit');
        Route::put('/{proposal}', [ThesisProposalController::class, 'update'])->name('student.proposals.update');
        Route::delete('/{proposal}', [ThesisProposalController::class, 'destroy'])->name('student.proposals.destroy');
        Route::post('/submit-all', [ThesisProposalController::class, 'submitAll'])->name('student.proposals.submit-all');
    });
});

// ============================================
// THESIS ROUTES
// ============================================

Route::middleware(['auth', 'system.status'])->prefix('theses')->group(function () {
    
    // ============================================
    // THESIS LISTS / FILTERS
    // ============================================
    // Completed theses (public reference for authenticated users)
    Route::get('/completed', [ThesisController::class, 'completed'])->name('theses.completed');

    // ============================================
    // THESIS CRUD
    // ============================================
    Route::get('/', [ThesisController::class, 'index'])->name('theses.index');
    Route::get('/create', [ThesisController::class, 'create'])->name('theses.create');
    Route::post('/', [ThesisController::class, 'store'])->name('theses.store');
    Route::get('/{thesis}', [ThesisController::class, 'show'])->name('theses.show');
    Route::get('/{thesis}/edit', [ThesisController::class, 'edit'])->name('theses.edit');
    Route::put('/{thesis}', [ThesisController::class, 'update'])->name('theses.update');
    Route::delete('/{thesis}', [ThesisController::class, 'destroy'])->name('theses.destroy');
    
    // ============================================
    // PROPOSAL ROUTES
    // ============================================
    Route::post('/{thesis}/submit-proposal', [ThesisController::class, 'submitProposal'])->name('theses.submit-proposal');
    Route::post('/{thesis}/approve-proposal', [ThesisController::class, 'approveProposal'])->name('theses.approve-proposal');
    Route::post('/{thesis}/reject-proposal', [ThesisController::class, 'rejectProposal'])->name('theses.reject-proposal');
    
    // ============================================
    // THESIS SUBMISSION ROUTES
    // ============================================
    Route::post('/{thesis}/submit-thesis', [ThesisController::class, 'submitThesis'])->name('theses.submit-thesis');
    Route::post('/{thesis}/reject-thesis', [ThesisController::class, 'rejectThesis'])->name('theses.reject-thesis');
    
    // ============================================
    // TWO-LEVEL REVIEW ROUTES
    // ============================================
    // Supervisor Review (Level 1)
    Route::post('/{thesis}/supervisor-review', [ThesisController::class, 'supervisorReview'])->name('theses.supervisor-review');
    
    // Admin Review (Level 2 - Final)
    Route::post('/{thesis}/admin-review', [ThesisController::class, 'adminReview'])->name('theses.admin-review');

// ============================================
// CHAPTER DOWNLOAD (PDF) - needed by chapters.show view
// ============================================
Route::get('/chapters/{chapter}/download-pdf', [\App\Http\Controllers\ChapterController::class, 'downloadPdf'])->name('chapters.download-pdf');
});

// ============================================
// CHAPTER ROUTES
// ============================================

Route::middleware(['auth', 'system.status'])->prefix('chapters')->group(function () {
    
    // ============================================
    // STUDENT: Chapter CRUD
    // ============================================
    Route::get('/create/{thesis}', [ChapterController::class, 'create'])->name('chapters.create');
    Route::post('/store/{thesis}', [ChapterController::class, 'store'])->name('chapters.store');
    Route::get('/{chapter}', [ChapterController::class, 'show'])->name('chapters.show');
    Route::get('/{chapter}/edit', [ChapterController::class, 'edit'])->name('chapters.edit');
    Route::put('/{chapter}', [ChapterController::class, 'update'])->name('chapters.update');
    Route::delete('/{chapter}', [ChapterController::class, 'destroy'])->name('chapters.destroy');
    
    // ============================================
    // STUDENT: Submit Chapter
    // ============================================
    Route::post('/{chapter}/submit', [ChapterController::class, 'submit'])->name('chapters.submit');
    
    // ============================================
    // SUPERVISOR: Review Chapter
    // ============================================
    Route::post('/{chapter}/approve-supervisor', [ChapterController::class, 'approveBySupervisor'])->name('chapters.approve-supervisor');
    Route::post('/{chapter}/reject-supervisor', [ChapterController::class, 'rejectBySupervisor'])->name('chapters.reject-supervisor');
    
    // ============================================
    // ADMIN: Review Chapter
    // ============================================
    Route::post('/{chapter}/approve-admin', [ChapterController::class, 'approveByAdmin'])->name('chapters.approve-admin');
    Route::post('/{chapter}/reject-admin', [ChapterController::class, 'rejectByAdmin'])->name('chapters.reject-admin');
});

// ============================================
// CERTIFICATE ROUTES
// ============================================

Route::middleware(['auth', 'system.status'])->prefix('certificates')->group(function () {
    Route::get('/{certificate}', [CertificateController::class, 'show'])->name('certificates.show');
    Route::get('/{certificate}/download', [CertificateController::class, 'download'])->name('certificates.download');
    Route::get('/{certificate}/print', [CertificateController::class, 'print'])->name('certificates.print');
});

// ============================================
// FALLBACK ROUTE (404 Page)
// ============================================

Route::fallback(function () {
    return view('errors.404');
});
